<?php
if (!defined('ABSPATH')) exit;

// ============================================================
// PÁGINA UNIFICADA: Entidades
// Combina Post Types + Taxonomías + Campos Dinámicos en tabs
// ============================================================
function wpsheets_page_entities() {
    $active_tab = isset($_GET['entity_tab']) ? sanitize_key($_GET['entity_tab']) : 'cpts';

    // ── Procesar guardado de tipos nativos ───────────────────
    if ($active_tab === 'natives' && isset($_POST['wpsheets_save_natives']) && check_admin_referer('wpsheets_save_natives')) {
        $native_sheets_raw = isset($_POST['native_sheets']) ? $_POST['native_sheets'] : [];
        $native_sheets_clean = [];
        foreach ($native_sheets_raw as $slug => $sheet) {
            $clean_slug  = sanitize_key($slug);
            $clean_sheet = sanitize_text_field($sheet);
            if ($clean_slug && $clean_sheet) {
                $native_sheets_clean[$clean_slug] = $clean_sheet;
                // Auto-mapear al guardar si hay hoja vinculada
                if (strpos($clean_slug, 'tax_') === 0) {
                    $tax_slug = substr($clean_slug, 4);
                    wpsheets_auto_map_taxonomy($tax_slug, $clean_sheet);
                } else {
                    wpsheets_auto_map_cpt($clean_slug, $clean_sheet);
                }
            }
        }
        update_option('wpsheets_native_cpts', $native_sheets_clean);
        $alert = '<div class="ws-alert ws-alert-success">✅ Configuración de tipos nativos guardada. Auto-mapeo aplicado.</div>';
    }
    $base_url   = admin_url('admin.php?page=wpsheets-entities');
    $tabs       = get_option('wpsheets_spreadsheet_id') ? WPSheets_Google_API::get_spreadsheet_tabs(get_option('wpsheets_spreadsheet_id')) : [];

    // ── Procesar acciones POST / GET antes de renderizar ────
    $alert = '';

    // --- CPTs ---
    if ($active_tab === 'cpts') {
        $cpts = get_option('wpsheets_cpts', []);
        if (isset($_POST['wpsheets_add_cpt']) && check_admin_referer('wpsheets_save_cpt')) {
            $id      = sanitize_text_field($_POST['cpt_id']);
            $new_cpt = [
                'id'       => $id ?: uniqid(),
                'singular' => sanitize_text_field($_POST['singular']),
                'plural'   => sanitize_text_field($_POST['plural']),
                'slug'     => sanitize_title($_POST['slug']),
                'icon'     => sanitize_text_field($_POST['icon']),
                'sheet'    => sanitize_text_field($_POST['sheet']),
            ];
            if ($id) {
                foreach ($cpts as $k => $c) { if ($c['id'] === $id) $cpts[$k] = $new_cpt; }
                $action_label = 'actualizado';
            } else {
                $cpts[]       = $new_cpt;
                $action_label = 'creado';
            }
            update_option('wpsheets_cpts', $cpts);
            update_option('wpsheets_needs_sync', '1');
            $auto_msg = '';
            if (!empty($new_cpt['sheet'])) {
                $mapped = wpsheets_auto_map_cpt($new_cpt['slug'], $new_cpt['sheet']);
                if ($mapped !== false) {
                    $exported  = wpsheets_bulk_export_cpt($new_cpt['slug'], $new_cpt['sheet'], $new_cpt['slug']);
                    $auto_msg  = " Auto-mapeado ({$mapped} columnas).";
                    if ($exported > 0) $auto_msg .= " {$exported} registros exportados.";
                } else {
                    $auto_msg = ' <em>Hoja no encontrada — se mapeará al crearla.</em>';
                }
            }
            $alert = '<div class="ws-alert ws-alert-success">Post Type ' . $action_label . '.' . $auto_msg . '</div>';
        }
        if (isset($_GET['delete_cpt'])) {
            $cpts  = array_values(array_filter($cpts, fn($c) => $c['id'] !== $_GET['delete_cpt']));
            update_option('wpsheets_cpts', $cpts);
            $alert = '<div class="ws-alert ws-alert-success">Post Type eliminado.</div>';
        }
        $cpts = get_option('wpsheets_cpts', []);
    }

    // --- Taxonomías ---
    if ($active_tab === 'taxonomies') {
        $taxs = get_option('wpsheets_taxonomies', []);
        if (isset($_POST['wpsheets_add_tax']) && check_admin_referer('wpsheets_save_tax')) {
            $id      = sanitize_text_field($_POST['tax_id']);
            $new_tax = [
                'id'         => $id ?: uniqid(),
                'singular'   => sanitize_text_field($_POST['singular']),
                'plural'     => sanitize_text_field($_POST['plural']),
                'slug'       => sanitize_title($_POST['slug']),
                'post_types' => isset($_POST['post_types']) ? array_map('sanitize_title', $_POST['post_types']) : [],
                'sheet'      => sanitize_text_field($_POST['sheet']),
            ];
            if ($id) {
                foreach ($taxs as $k => $t) { if ($t['id'] === $id) $taxs[$k] = $new_tax; }
                $tax_action = 'actualizada';
            } else {
                $taxs[]     = $new_tax;
                $tax_action = 'creada';
            }
            update_option('wpsheets_taxonomies', $taxs);
            update_option('wpsheets_needs_sync', '1');
            if (!empty($new_tax['post_types'])) {
                register_taxonomy($new_tax['slug'], $new_tax['post_types'], [
                    'label' => $new_tax['plural'], 'public' => true,
                    'hierarchical' => true, 'show_in_rest' => true,
                ]);
            }
            $tax_auto_msg = '';
            if (!empty($new_tax['sheet'])) {
                $mapped = wpsheets_auto_map_taxonomy($new_tax['slug'], $new_tax['sheet']);
                if ($mapped !== false) {
                    $exported_t   = wpsheets_bulk_export_taxonomy($new_tax['slug'], $new_tax['sheet'], 'tax_' . $new_tax['slug']);
                    $tax_auto_msg = " Auto-mapeado ({$mapped} columnas).";
                    if ($exported_t > 0) $tax_auto_msg .= " {$exported_t} términos exportados.";
                } else {
                    $tax_auto_msg = ' <em>Hoja no encontrada — se mapeará al crearla.</em>';
                }
            }
            $alert = '<div class="ws-alert ws-alert-success">Taxonomía ' . $tax_action . '.' . $tax_auto_msg . '</div>';
        }
        if (isset($_GET['delete_tax'])) {
            $taxs  = array_values(array_filter($taxs, fn($t) => $t['id'] !== $_GET['delete_tax']));
            update_option('wpsheets_taxonomies', $taxs);
            $alert = '<div class="ws-alert ws-alert-success">Taxonomía eliminada.</div>';
        }
        $taxs = get_option('wpsheets_taxonomies', []);
        $cpts = get_option('wpsheets_cpts', []);
    }
    ?>
    <div class="wpsheets-wrap">

        <!-- Header -->
        <div class="wpsheets-header">
            <div class="wpsheets-header-title">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#2563EB" stroke-width="2">
                    <rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/>
                </svg>
                <div>
                    <h1>Entidades</h1>
                    <div class="wpsheets-subtitle">Administra Post Types, Taxonomías y sus mapeos de columnas.</div>
                </div>
            </div>
            <?php if ($active_tab === 'cpts'): ?>
                <button class="ws-btn ws-btn-primary" onclick="jQuery('#cpt-form-container').toggle();">+ Añadir Post Type</button>
            <?php elseif ($active_tab === 'taxonomies'): ?>
                <button class="ws-btn ws-btn-primary" onclick="jQuery('#tax-form-container').toggle();">+ Añadir Taxonomía</button>
            <?php endif; ?>
        </div>

        <?php echo $alert; ?>

        <!-- Tab Navigation -->
        <div style="display:flex; gap:4px; margin-bottom:20px; border-bottom:2px solid #E2E8F0; padding-bottom:0;">
            <?php
            $nav_tabs = [
                'cpts'       => ['🗂️ Post Types',        $base_url . '&entity_tab=cpts'],
                'taxonomies' => ['🏷️ Taxonomías',        $base_url . '&entity_tab=taxonomies'],
                'natives'    => ['🌐 Nativos',            $base_url . '&entity_tab=natives'],
                'fields'     => ['⚙️ Campos Dinámicos',  $base_url . '&entity_tab=fields'],
            ];
            foreach ($nav_tabs as $slug => [$label, $url]):
                $is_active = ($active_tab === $slug);
                $style = $is_active
                    ? 'background:#fff; border:2px solid #E2E8F0; border-bottom:2px solid #fff; color:#2563EB; font-weight:600; margin-bottom:-2px;'
                    : 'background:transparent; border:none; color:#64748B;';
            ?>
                <a href="<?php echo esc_url($url); ?>"
                   style="padding:10px 20px; border-radius:6px 6px 0 0; text-decoration:none; font-size:14px; <?php echo $style; ?>">
                    <?php echo $label; ?>
                </a>
            <?php endforeach; ?>
        </div>

        <!-- ══ TAB: POST TYPES ══════════════════════════════════════ -->
        <?php if ($active_tab === 'cpts'): ?>
            <div id="cpt-form-container" class="ws-card" style="display:none; border-top:4px solid var(--ws-accent);">
                <h3 id="cpt-form-title" style="margin-top:0;">Añadir Nuevo Post Type</h3>
                <form method="post" id="add-cpt-form">
                    <?php wp_nonce_field('wpsheets_save_cpt'); ?>
                    <input type="hidden" name="cpt_id" id="cpt_id" value="">
                    <div style="display:flex; gap:20px; flex-wrap:wrap;">
                        <div class="ws-form-group" style="flex:1; min-width:180px;"><label class="ws-label">Nombre Plural</label><input type="text" name="plural" id="cpt_plural" required class="ws-input"></div>
                        <div class="ws-form-group" style="flex:1; min-width:180px;"><label class="ws-label">Nombre Singular</label><input type="text" name="singular" id="cpt_singular" required class="ws-input"></div>
                        <div class="ws-form-group" style="flex:1; min-width:140px;"><label class="ws-label">Slug</label><input type="text" name="slug" id="cpt_slug" required class="ws-input"></div>
                        <div class="ws-form-group" style="flex:1; min-width:140px;"><label class="ws-label">Icono Dashicon</label><input type="text" name="icon" id="cpt_icon" value="dashicons-admin-post" class="ws-input"></div>
                    </div>
                    <div class="ws-form-group">
                        <label class="ws-label">Pestaña de Google Sheets Vinculada</label>
                        <select name="sheet" id="cpt_sheet" class="ws-select" style="max-width:320px;">
                            <?php if (!empty($tabs) && !is_wp_error($tabs)): foreach ($tabs as $t) echo "<option value='".esc_attr($t)."'>".esc_html($t)."</option>"; endif; ?>
                        </select>
                    </div>
                    <div style="display:flex; gap:10px;">
                        <button type="submit" name="wpsheets_add_cpt" class="ws-btn ws-btn-primary">Guardar Post Type</button>
                        <button type="button" class="ws-btn ws-btn-secondary" onclick="jQuery('#cpt-form-container').hide();">Cancelar</button>
                    </div>
                </form>
            </div>

            <div class="ws-table-wrapper">
                <table class="ws-table">
                    <thead><tr><th>Nombre</th><th>Slug</th><th>Hoja vinculada</th><th>Icono</th><th>Acciones</th></tr></thead>
                    <tbody>
                    <?php if (empty($cpts)): ?>
                        <tr><td colspan="5" style="text-align:center; color:#94A3B8;">No hay Post Types registrados. Crea el primero.</td></tr>
                    <?php else: foreach ($cpts as $c): ?>
                        <tr>
                            <td><strong><?php echo esc_html($c['plural']); ?></strong><br><small style="color:#94A3B8;"><?php echo esc_html($c['singular']); ?></small></td>
                            <td><span class="ws-badge"><?php echo esc_html($c['slug']); ?></span></td>
                            <td><?php echo $c['sheet'] ? '<span class="ws-badge ws-badge-success">'.esc_html($c['sheet']).'</span>' : '<span style="color:#EF4444; font-size:12px;">⚠️ Sin hoja</span>'; ?></td>
                            <td><span class="dashicons <?php echo esc_attr($c['icon']); ?>"></span></td>
                            <td style="text-align:right;">
                                <button class="ws-btn ws-btn-secondary edit-cpt-btn"
                                    data-id="<?php echo esc_attr($c['id']); ?>"
                                    data-plural="<?php echo esc_attr($c['plural']); ?>"
                                    data-singular="<?php echo esc_attr($c['singular']); ?>"
                                    data-slug="<?php echo esc_attr($c['slug']); ?>"
                                    data-icon="<?php echo esc_attr($c['icon']); ?>"
                                    data-sheet="<?php echo esc_attr($c['sheet']); ?>"
                                    style="padding:6px 12px; margin-right:5px;">Editar</button>
                                <a href="?page=wpsheets-entities&entity_tab=cpts&delete_cpt=<?php echo $c['id']; ?>"
                                   class="ws-btn ws-btn-danger" style="padding:6px 12px;"
                                   onclick="return confirm('¿Eliminar este Post Type?');">Eliminar</a>
                            </td>
                        </tr>
                    <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
            <script>
            jQuery('.edit-cpt-btn').on('click', function() {
                var d = jQuery(this).data();
                jQuery('#cpt_id').val(d.id); jQuery('#cpt_plural').val(d.plural);
                jQuery('#cpt_singular').val(d.singular); jQuery('#cpt_slug').val(d.slug);
                jQuery('#cpt_icon').val(d.icon); jQuery('#cpt_sheet').val(d.sheet);
                jQuery('#cpt-form-title').text('Editar Post Type');
                jQuery('#cpt-form-container').show();
                window.scrollTo(0, 0);
            });
            </script>

        <!-- ══ TAB: TAXONOMÍAS ══════════════════════════════════════ -->
        <?php elseif ($active_tab === 'taxonomies'): ?>
            <div id="tax-form-container" class="ws-card" style="display:none; border-top:4px solid var(--ws-accent);">
                <h3 id="tax-form-title" style="margin-top:0;">Añadir Nueva Taxonomía</h3>
                <form method="post" id="add-tax-form">
                    <?php wp_nonce_field('wpsheets_save_tax'); ?>
                    <input type="hidden" name="tax_id" id="tax_id" value="">
                    <div style="display:flex; gap:20px; flex-wrap:wrap;">
                        <div class="ws-form-group" style="flex:1; min-width:160px;"><label class="ws-label">Nombre Plural</label><input type="text" name="plural" id="tax_plural" required class="ws-input"></div>
                        <div class="ws-form-group" style="flex:1; min-width:160px;"><label class="ws-label">Nombre Singular</label><input type="text" name="singular" id="tax_singular" required class="ws-input"></div>
                        <div class="ws-form-group" style="flex:1; min-width:140px;"><label class="ws-label">Slug</label><input type="text" name="slug" id="tax_slug" required class="ws-input"></div>
                    </div>
                    <div class="ws-form-group">
                        <label class="ws-label">Asignar a Post Types</label>
                        <div style="background:var(--ws-bg); padding:15px; border-radius:6px; border:1px solid var(--ws-border); display:flex; flex-wrap:wrap; gap:12px;">
                            <?php foreach ($cpts as $c): ?>
                                <label style="display:flex; align-items:center; gap:6px; cursor:pointer;">
                                    <input type="checkbox" name="post_types[]" value="<?php echo esc_attr($c['slug']); ?>" class="tax-pt-checkbox">
                                    <?php echo esc_html($c['plural']); ?>
                                </label>
                            <?php endforeach; ?>
                            <label style="display:flex; align-items:center; gap:6px; cursor:pointer;">
                                <input type="checkbox" name="post_types[]" value="post" class="tax-pt-checkbox"> Posts nativos
                            </label>
                        </div>
                    </div>
                    <div class="ws-form-group">
                        <label class="ws-label">Pestaña de Google Sheets Vinculada</label>
                        <select name="sheet" id="tax_sheet" class="ws-select" style="max-width:320px;">
                            <?php if (!empty($tabs) && !is_wp_error($tabs)): foreach ($tabs as $t) echo "<option value='".esc_attr($t)."'>".esc_html($t)."</option>"; endif; ?>
                        </select>
                    </div>
                    <div style="display:flex; gap:10px;">
                        <button type="submit" name="wpsheets_add_tax" class="ws-btn ws-btn-primary">Guardar Taxonomía</button>
                        <button type="button" class="ws-btn ws-btn-secondary" onclick="jQuery('#tax-form-container').hide();">Cancelar</button>
                    </div>
                </form>
            </div>

            <div class="ws-table-wrapper">
                <table class="ws-table">
                    <thead><tr><th>Nombre</th><th>Slug</th><th>Vinculada a</th><th>Hoja</th><th>Acciones</th></tr></thead>
                    <tbody>
                    <?php if (empty($taxs)): ?>
                        <tr><td colspan="5" style="text-align:center; color:#94A3B8;">No hay Taxonomías registradas. Crea la primera.</td></tr>
                    <?php else: foreach ($taxs as $t): ?>
                        <tr>
                            <td><strong><?php echo esc_html($t['plural']); ?></strong><br><small style="color:#94A3B8;"><?php echo esc_html($t['singular']); ?></small></td>
                            <td><span class="ws-badge"><?php echo esc_html($t['slug']); ?></span></td>
                            <td><?php foreach ($t['post_types'] as $pt) echo '<span class="ws-badge" style="margin-right:4px; margin-bottom:2px;">'.esc_html($pt).'</span>'; ?></td>
                            <td><?php echo $t['sheet'] ? '<span class="ws-badge ws-badge-success">'.esc_html($t['sheet']).'</span>' : '<span style="color:#EF4444; font-size:12px;">⚠️ Sin hoja</span>'; ?></td>
                            <td style="text-align:right;">
                                <button class="ws-btn ws-btn-secondary edit-tax-btn"
                                    data-id="<?php echo esc_attr($t['id']); ?>"
                                    data-plural="<?php echo esc_attr($t['plural']); ?>"
                                    data-singular="<?php echo esc_attr($t['singular']); ?>"
                                    data-slug="<?php echo esc_attr($t['slug']); ?>"
                                    data-sheet="<?php echo esc_attr($t['sheet']); ?>"
                                    data-pts='<?php echo json_encode($t['post_types']); ?>'
                                    style="padding:6px 12px; margin-right:5px;">Editar</button>
                                <a href="?page=wpsheets-entities&entity_tab=taxonomies&delete_tax=<?php echo $t['id']; ?>"
                                   class="ws-btn ws-btn-danger" style="padding:6px 12px;"
                                   onclick="return confirm('¿Eliminar esta Taxonomía?');">Eliminar</a>
                            </td>
                        </tr>
                    <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
            <script>
            jQuery('.edit-tax-btn').on('click', function() {
                var d = jQuery(this).data();
                jQuery('#tax_id').val(d.id); jQuery('#tax_plural').val(d.plural);
                jQuery('#tax_singular').val(d.singular); jQuery('#tax_slug').val(d.slug);
                jQuery('#tax_sheet').val(d.sheet);
                jQuery('.tax-pt-checkbox').prop('checked', false);
                var pts = d.pts || [];
                pts.forEach(function(pt) { jQuery('input[value="'+pt+'"]').prop('checked', true); });
                jQuery('#tax-form-title').text('Editar Taxonomía');
                jQuery('#tax-form-container').show();
                window.scrollTo(0, 0);
            });
            </script>

        <!-- ══ TAB: NATIVOS ═════════════════════════════════════════ -->
        <?php elseif ($active_tab === 'natives'):
            $native_nonce  = wp_create_nonce('wpsheets_ajax_nonce');
            $has_woo       = class_exists('WooCommerce');
            $native_sheets = get_option('wpsheets_native_cpts', []);

            // Detectar CPT de proyectos
            $project_slugs = ['jetpack-portfolio','jetpack_portfolio','portfolio','project',
                              'projects','avada_portfolio','portfolio_page','work','case_study'];
            $engine_slugs  = array_column(get_option('wpsheets_cpts', []) ?: [], 'slug');
            $project_cpt   = null;
            foreach ($project_slugs as $ps) {
                if (post_type_exists($ps) && !in_array($ps, $engine_slugs)) {
                    $project_cpt = get_post_type_object($ps); break;
                }
            }

            // Estado Blog
            $blog_active     = !empty($native_sheets['post']);
            $blog_cat_active = !empty($native_sheets['tax_category']);
            $blog_tag_active = !empty($native_sheets['tax_post_tag']);

            // Estado Projects
            $proj_active = $project_cpt && !empty($native_sheets[$project_cpt->name]);
            $proj_taxs_active = [];
            if ($project_cpt) {
                foreach (get_object_taxonomies($project_cpt->name, 'objects') as $pt) {
                    if ($pt->public && $pt->name !== 'post_format') {
                        $proj_taxs_active[$pt->name] = [
                            'label'  => $pt->label,
                            'active' => !empty($native_sheets['tax_' . $pt->name]),
                            'sheet'  => $native_sheets['tax_' . $pt->name] ?? '',
                        ];
                    }
                }
            }

            // Estado WooCommerce
            $woo_mapping = get_option('wpsheets_fields_mapping', []);
            $woo_sheets  = [
                'Products_Woo'    => ['label' => 'Productos',   'mapped' => isset($woo_mapping['product'])],
                'Categories_Woo'  => ['label' => 'Categorías',  'mapped' => isset($woo_mapping['tax_product_cat'])],
                'Tags_Woo'        => ['label' => 'Etiquetas',   'mapped' => isset($woo_mapping['tax_product_tag'])],
                'Brands_Woo'      => ['label' => 'Marcas',      'mapped' => (function() use ($woo_mapping) {
                    foreach (['tax_brands_woo','tax_product_brands','tax_pwb-brand','tax_yith_product_brand','tax_product_brand'] as $bk) {
                        if (isset($woo_mapping[$bk])) return true;
                    }
                    return false;
                })()],
                'Attributes_Woo'  => ['label' => 'Atributos',   'mapped' => isset($woo_mapping['tax_woo_attributes'])],
                'Orders_Woo'      => ['label' => 'Órdenes',     'mapped' => isset($woo_mapping['shop_order'])],
                'Coupons_Woo'     => ['label' => 'Cupones',     'mapped' => isset($woo_mapping['shop_coupon'])],
            ];
        ?>
            <div style="display:grid; gap:20px;">

                <!-- ── BLOG ──────────────────────────────────────────────── -->
                <div class="ws-card" style="border-left:4px solid <?php echo $blog_active ? '#10B981' : '#3B82F6'; ?>;">
                    <div style="display:flex; gap:14px; align-items:flex-start; flex-wrap:wrap;">
                        <div style="font-size:32px;">📝</div>
                        <div style="flex:1; min-width:200px;">
                            <h3 style="margin:0 0 6px; font-size:16px;">Blog (Entradas)</h3>
                            <p style="color:#64748B; font-size:13px; margin:0 0 10px;">
                                Hojas: <strong>Posts_WP</strong>, <strong>Posts_Category_WP</strong>, <strong>Posts_Tags_WP</strong>.
                            </p>
                            <!-- Estado de sub-hojas -->
                            <div style="display:flex; flex-wrap:wrap; gap:6px; margin-bottom:10px;">
                                <?php foreach ([
                                    'post'          => ['Posts_WP',       $blog_active],
                                    'tax_category'  => ['Posts_Category_WP',  $blog_cat_active],
                                    'tax_post_tag'  => ['Posts_Tags_WP',        $blog_tag_active],
                                ] as $k => [$label, $active]): ?>
                                    <span style="font-size:11px; padding:3px 8px; border-radius:20px; font-weight:600;
                                        background:<?php echo $active ? '#D1FAE5' : '#F1F5F9'; ?>;
                                        color:<?php echo $active ? '#065F46' : '#94A3B8'; ?>;">
                                        <?php echo $active ? '✅' : '○'; ?> <?php echo $label; ?>
                                        <?php if ($active && !empty($native_sheets[$k])): ?>
                                            <em style="font-weight:400;">(<?php echo esc_html($native_sheets[$k]); ?>)</em>
                                        <?php endif; ?>
                                    </span>
                                <?php endforeach; ?>
                            </div>
                            <!-- Selector de exportación parcial -->
                            <?php if ($blog_active): ?>
                            <div style="display:flex; gap:8px; align-items:center; flex-wrap:wrap;">
                                <select class="ws-select native-export-select" data-type="blog" style="max-width:220px; font-size:12px;">
                                    <option value="all">📦 Exportar todo</option>
                                    <option value="posts">📝 Solo entradas</option>
                                    <option value="categories">📂 Solo categorías</option>
                                    <option value="tags">🏷️ Solo etiquetas</option>
                                </select>
                                <button class="ws-btn ws-btn-secondary btn-export-native" data-type="blog" style="font-size:12px; padding:6px 12px;">
                                    ⬆️ Exportar
                                </button>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div style="display:flex; flex-direction:column; gap:8px; min-width:180px;">
                            <button class="ws-btn ws-btn-primary btn-init-native" data-type="blog"
                                style="background:#3B82F6; border-color:#3B82F6;">
                                🚀 Inicializar Blog
                            </button>
                        </div>
                    </div>
                    <div class="native-result native-result-blog ws-alert" style="display:none; margin-top:12px;"></div>
                </div>

                <!-- ── PROJECTS ───────────────────────────────────────────── -->
                <?php if ($project_cpt): ?>
                <div class="ws-card" style="border-left:4px solid <?php echo $proj_active ? '#10B981' : '#8B5CF6'; ?>;">
                    <div style="display:flex; gap:14px; align-items:flex-start; flex-wrap:wrap;">
                        <div style="font-size:32px;">🗂️</div>
                        <div style="flex:1; min-width:200px;">
                            <h3 style="margin:0 0 6px; font-size:16px;">
                                <?php echo esc_html($project_cpt->label); ?>
                                <span class="ws-badge" style="font-size:11px;"><?php echo esc_html($project_cpt->name); ?></span>
                            </h3>
                            <p style="color:#64748B; font-size:13px; margin:0 0 10px;">
                                Hoja principal: <strong>Projects_WP</strong>.
                                <?php if (!empty($proj_taxs_active)): ?>
                                    También sus taxonomías: <?php echo implode(', ', array_map(fn($t) => '<strong>'.$t['label'].'</strong>', $proj_taxs_active)); ?>.
                                <?php endif; ?>
                            </p>
                            <!-- Estado sub-hojas -->
                            <div style="display:flex; flex-wrap:wrap; gap:6px; margin-bottom:10px;">
                                <span style="font-size:11px; padding:3px 8px; border-radius:20px; font-weight:600;
                                    background:<?php echo $proj_active ? '#D1FAE5' : '#F1F5F9'; ?>;
                                    color:<?php echo $proj_active ? '#065F46' : '#94A3B8'; ?>;">
                                    <?php echo $proj_active ? '✅' : '○'; ?> Projects
                                    <?php if ($proj_active): ?><em style="font-weight:400;">(<?php echo esc_html($native_sheets[$project_cpt->name]); ?>)</em><?php endif; ?>
                                </span>
                                <?php foreach ($proj_taxs_active as $tslug => $tinfo): ?>
                                <span style="font-size:11px; padding:3px 8px; border-radius:20px; font-weight:600;
                                    background:<?php echo $tinfo['active'] ? '#D1FAE5' : '#F1F5F9'; ?>;
                                    color:<?php echo $tinfo['active'] ? '#065F46' : '#94A3B8'; ?>;">
                                    <?php echo $tinfo['active'] ? '✅' : '○'; ?> <?php echo esc_html($tinfo['label']); ?>
                                    <?php if ($tinfo['active']): ?><em style="font-weight:400;">(<?php echo esc_html($tinfo['sheet']); ?>)</em><?php endif; ?>
                                </span>
                                <?php endforeach; ?>
                            </div>
                            <!-- Selector exportación parcial -->
                            <?php if ($proj_active): ?>
                            <div style="display:flex; gap:8px; align-items:center; flex-wrap:wrap;">
                                <select class="ws-select native-export-select" data-type="projects" style="max-width:220px; font-size:12px;">
                                    <option value="all">📦 Exportar todo</option>
                                    <option value="posts">🗂️ Solo proyectos</option>
                                    <?php foreach ($proj_taxs_active as $tslug => $tinfo): ?>
                                    <option value="tax_<?php echo esc_attr($tslug); ?>">
                                        📂 Solo <?php echo esc_html($tinfo['label']); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                                <button class="ws-btn ws-btn-secondary btn-export-native"
                                    data-type="projects" data-slug="<?php echo esc_attr($project_cpt->name); ?>"
                                    style="font-size:12px; padding:6px 12px;">
                                    ⬆️ Exportar
                                </button>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div style="display:flex; flex-direction:column; gap:8px; min-width:180px;">
                            <button class="ws-btn ws-btn-primary btn-init-native"
                                data-type="projects" data-slug="<?php echo esc_attr($project_cpt->name); ?>"
                                style="background:#8B5CF6; border-color:#8B5CF6;">
                                🚀 Inicializar <?php echo esc_html($project_cpt->label); ?>
                            </button>
                        </div>
                    </div>
                    <div class="native-result native-result-projects ws-alert" style="display:none; margin-top:12px;"></div>
                </div>
                <?php else: ?>
                <div class="ws-card" style="background:#FFFBEB; border-left:4px solid #F59E0B;">
                    <p style="margin:0; font-size:13px; color:#92400E;">
                        <strong>🔧 Proyectos:</strong> No se detectó ningún CPT de proyectos activo.
                        Instala Jetpack Portfolio, Elementor Portfolio u otro plugin que registre
                        slugs como <code>portfolio</code>, <code>project</code>, etc.
                    </p>
                </div>
                <?php endif; ?>

                <!-- ── PÁGINAS ───────────────────────────────────────────────── -->
                <?php
                $page_sheet  = $native_sheets['page'] ?? '';
                $page_active = !empty($page_sheet);
                ?>
                <div class="ws-card" style="border-left:4px solid <?php echo $page_active ? '#10B981' : '#64748B'; ?>;">
                    <div style="display:flex; gap:14px; align-items:flex-start; flex-wrap:wrap;">
                        <div style="font-size:32px;">📄</div>
                        <div style="flex:1; min-width:200px;">
                            <h3 style="margin:0 0 6px; font-size:16px;">Páginas</h3>
                            <p style="color:#64748B; font-size:13px; margin:0 0 10px;">
                                Hoja: <strong>Pages_WP</strong>. Útil para mantener el contenido de páginas estáticas sincronizado.
                            </p>
                            <div style="display:flex; flex-wrap:wrap; gap:6px; margin-bottom:10px;">
                                <span style="font-size:11px; padding:3px 8px; border-radius:20px; font-weight:600;
                                    background:<?php echo $page_active ? '#D1FAE5' : '#F1F5F9'; ?>;
                                    color:<?php echo $page_active ? '#065F46' : '#94A3B8'; ?>;">
                                    <?php echo $page_active ? '✅' : '○'; ?> Pages_WP
                                    <?php if ($page_active): ?><em style="font-weight:400;">(<?php echo esc_html($page_sheet); ?>)</em><?php endif; ?>
                                </span>
                            </div>
                            <?php if ($page_active): ?>
                            <div style="display:flex; gap:8px; align-items:center;">
                                <button class="ws-btn ws-btn-secondary btn-export-native" data-type="pages"
                                    style="font-size:12px; padding:6px 12px;">
                                    ⬆️ Re-exportar páginas
                                </button>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div style="min-width:180px;">
                            <button class="ws-btn ws-btn-primary btn-init-native" data-type="pages"
                                style="background:#64748B; border-color:#64748B;">
                                🚀 Inicializar Páginas
                            </button>
                        </div>
                    </div>
                    <div class="native-result native-result-pages ws-alert" style="display:none; margin-top:12px;"></div>
                </div>

                <!-- ── WOOCOMMERCE ─────────────────────────────────────────── -->
                <?php if ($has_woo): ?>
                <div class="ws-card" style="border-left:4px solid #8B5CF6; background:#FAFAFA;">
                    <div style="display:flex; gap:14px; align-items:flex-start; flex-wrap:wrap;">
                        <div style="font-size:32px;">🛒</div>
                        <div style="flex:1; min-width:200px;">
                            <h3 style="margin:0 0 6px; font-size:16px;">WooCommerce</h3>
                            <p style="color:#64748B; font-size:13px; margin:0 0 10px;">
                                Productos, Categorías, Etiquetas, Marcas, Atributos, Órdenes y Cupones.
                            </p>
                            <!-- Estado sub-hojas Woo -->
                            <div style="display:flex; flex-wrap:wrap; gap:6px; margin-bottom:10px;">
                                <?php foreach ($woo_sheets as $sheet_name => $woo_info): ?>
                                <span style="font-size:11px; padding:3px 8px; border-radius:20px; font-weight:600;
                                    background:<?php echo $woo_info['mapped'] ? '#EDE9FE' : '#F1F5F9'; ?>;
                                    color:<?php echo $woo_info['mapped'] ? '#4C1D95' : '#94A3B8'; ?>;">
                                    <?php echo $woo_info['mapped'] ? '✅' : '○'; ?>
                                    <?php echo esc_html($woo_info['label']); ?>
                                    <?php if ($woo_info['mapped']): ?><em style="font-weight:400;">(<?php echo $sheet_name; ?>)</em><?php endif; ?>
                                </span>
                                <?php endforeach; ?>
                            </div>
                            <!-- Selector exportación parcial -->
                            <div style="display:flex; gap:8px; align-items:center; flex-wrap:wrap;">
                                <select id="woo-export-entity-native" class="ws-select" style="max-width:220px; font-size:12px;">
                                    <option value="all">📦 Exportar todo</option>
                                    <option value="product">🛍️ Solo Productos</option>
                                    <option value="product_cat">📂 Solo Categorías</option>
                                    <option value="product_tag">🏷️ Solo Etiquetas</option>
                                    <?php
                                    $brand_slugs = ['product_brands','pwb-brand','yith_product_brand','product_brand'];
                                    $has_brand   = false;
                                    foreach (get_taxonomies([], 'objects') as $wt) {
                                        foreach ($brand_slugs as $bs) {
                                            if (strpos($wt->name, $bs) !== false) { $has_brand = true; break 2; }
                                        }
                                    }
                                    if ($has_brand) echo '<option value="brands">⭐ Solo Marcas</option>';
                                    if (function_exists('wc_get_attribute_taxonomies') && !empty(wc_get_attribute_taxonomies()))
                                        echo '<option value="attributes">⚙️ Solo Atributos</option>';
                                    echo '<option value="orders">📦 Solo Órdenes</option>';
                                    echo '<option value="coupons">🎟️ Solo Cupones</option>';
                                    ?>
                                </select>
                                <button id="btn-woo-export-native" class="ws-btn ws-btn-secondary"
                                    style="border-color:#8B5CF6; color:#6D28D9; font-size:12px; padding:6px 12px;">
                                    ⬆️ Exportar
                                </button>
                            </div>
                        </div>
                        <div style="display:flex; flex-direction:column; gap:8px; min-width:180px;">
                            <button id="btn-woo-init-native" class="ws-btn ws-btn-primary"
                                style="background:#8B5CF6; border-color:#8B5CF6;">
                                🔧 Inicializar / Restaurar
                            </button>
                        </div>
                    </div>
                    <div id="woo-native-result" class="ws-alert" style="display:none; margin-top:12px;"></div>
                </div>
                <?php endif; ?>

            </div>

            <script>
            jQuery(function($) {
                var nonce = '<?php echo $native_nonce; ?>';

                // ── Inicializar Blog / Projects ──────────────────────────
                $('.btn-init-native').on('click', function(e) {
                    e.preventDefault();
                    var btn    = $(this);
                    var type   = btn.data('type');
                    var slug   = btn.data('slug') || '';
                    var result = $('.native-result-' + type);
                    var orig   = btn.html();
                    btn.html('⏳ Inicializando...').prop('disabled', true);
                    result.hide();
                    $.post(wpSheets.ajax_url, {
                        action: 'wpsheets_init_native', nonce: nonce,
                        native_type: type, cpt_slug: slug
                    }, function(res) {
                        result.removeClass('ws-alert-error ws-alert-success');
                        if (res.success) {
                            result.addClass('ws-alert-success').html(res.data).show();
                            setTimeout(function() { location.reload(); }, 2500);
                        } else {
                            result.addClass('ws-alert-error').html(res.data).show();
                            btn.html(orig).prop('disabled', false);
                        }
                    });
                });

                // ── Exportar Blog / Projects ─────────────────────────────
                $('.btn-export-native').on('click', function(e) {
                    e.preventDefault();
                    var btn    = $(this);
                    var type   = btn.data('type');
                    var slug   = btn.data('slug') || '';
                    var entity = btn.closest('div').find('.native-export-select').val() || 'all';
                    var result = $('.native-result-' + type);
                    var orig   = btn.html();
                    btn.html('⏳ Exportando...').prop('disabled', true);
                    result.hide();
                    $.post(wpSheets.ajax_url, {
                        action: 'wpsheets_export_native', nonce: nonce,
                        native_type: type, cpt_slug: slug, entity: entity
                    }, function(res) {
                        result.removeClass('ws-alert-error ws-alert-success');
                        if (res.success) result.addClass('ws-alert-success').html(res.data).show();
                        else             result.addClass('ws-alert-error').html(res.data).show();
                    }).always(function() { btn.html(orig).prop('disabled', false); });
                });

                // ── WooCommerce: Inicializar ─────────────────────────────
                $('#btn-woo-init-native').on('click', function(e) {
                    e.preventDefault();
                    var btn = $(this), orig = btn.html();
                    btn.html('⏳ Procesando...').prop('disabled', true);
                    $('#woo-native-result').hide();
                    $.post(wpSheets.ajax_url, { action: 'wpsheets_init_woocommerce', nonce: wpSheets.nonce },
                    function(res) {
                        var box = $('#woo-native-result').removeClass('ws-alert-error ws-alert-success');
                        if (res.success) { box.addClass('ws-alert-success').html(res.data).show(); setTimeout(function(){ location.reload(); }, 2500); }
                        else             { box.addClass('ws-alert-error').html(res.data).show(); btn.html(orig).prop('disabled', false); }
                    });
                });

                // ── WooCommerce: Exportar ────────────────────────────────
                $('#btn-woo-export-native').on('click', function(e) {
                    e.preventDefault();
                    var btn    = $(this), orig = btn.html();
                    var entity = $('#woo-export-entity-native').val();
                    btn.html('⏳ Exportando...').prop('disabled', true);
                    $('#woo-native-result').hide();
                    $.post(wpSheets.ajax_url, {
                        action: 'wpsheets_woo_export_entity',
                        nonce: '<?php echo wp_create_nonce('wpsheets_ajax_nonce'); ?>',
                        entity: entity
                    }, function(res) {
                        var box = $('#woo-native-result').removeClass('ws-alert-error ws-alert-success');
                        if (res.success) box.addClass('ws-alert-success').html(res.data).show();
                        else             box.addClass('ws-alert-error').html(res.data).show();
                    }).always(function() { btn.html(orig).prop('disabled', false); });
                });
            });
            </script>

        <!-- ══ TAB: CAMPOS DINÁMICOS ════════════════════════════════ -->
        <?php elseif ($active_tab === 'fields'): ?>
            <div class="ws-card">
                <div class="ws-form-group" style="margin-bottom:0;">
                    <label class="ws-label">Selecciona qué deseas mapear:</label>
                    <select id="ws-field-object-select" class="ws-select" style="max-width:400px;">
                        <?php echo wpsheets_get_grouped_options_html(); ?>
                    </select>
                </div>
            </div>
            <div id="ws-fields-container" class="ws-card" style="display:none; border-top:4px solid var(--ws-accent);">
                <h3 id="ws-fields-title" style="margin-top:0;">Mapeo de Columnas</h3>
                <div id="ws-fields-loading" style="display:none;"><div class="ws-skeleton" style="margin-bottom:10px;"></div><div class="ws-skeleton" style="width:80%;"></div></div>
                <form id="ws-fields-form" style="display:none;">
                    <input type="hidden" name="object_id" id="ws-fields-object-id">
                    <input type="hidden" name="object_type" id="ws-fields-object-type">
                    <div class="ws-table-wrapper">
                        <table class="ws-table">
                            <thead><tr><th style="width:35%;">Columna (Google Sheets)</th><th>Configuración en WordPress</th></tr></thead>
                            <tbody id="ws-fields-body"></tbody>
                        </table>
                    </div>
                    <div style="margin-top:24px; display:flex; align-items:center;">
                        <button type="submit" class="ws-btn ws-btn-primary">Guardar Configuración</button>
                        <span id="ws-fields-save-status" style="margin-left:15px; font-weight:500;"></span>
                    </div>
                </form>
            </div>
        <?php endif; ?>

    </div>
    <?php
}


// ============================================================
// AJAX: Inicializar Blog o Projects (como WooCommerce)
// Crea la hoja, configura encabezados, mapea y exporta
// ============================================================
add_action('wp_ajax_wpsheets_init_native', function() {
    check_ajax_referer('wpsheets_ajax_nonce', 'nonce');
    $native_type = sanitize_key($_POST['native_type'] ?? '');
    $cpt_slug    = sanitize_key($_POST['cpt_slug'] ?? '');
    $sid         = get_option('wpsheets_spreadsheet_id');
    if (empty($sid)) wp_send_json_error('No hay Spreadsheet ID configurado.');

    $native_sheets = get_option('wpsheets_native_cpts', []);
    $mapping_all   = get_option('wpsheets_fields_mapping', []);
    $existing_tabs = WPSheets_Google_API::get_spreadsheet_tabs($sid) ?: [];
    $results       = [];

    // Helper: crear hoja si no existe
    $create_sheet = function($sheet_name, $headers) use ($sid, $existing_tabs, &$results) {
        if (!in_array($sheet_name, $existing_tabs)) {
            WPSheets_Google_API::add_sheet_with_headers($sid, $sheet_name, $headers);
            $results[] = "Hoja <strong>{$sheet_name}</strong> creada";
        } else {
            $results[] = "Hoja <strong>{$sheet_name}</strong> ya existía";
        }
    };

    if ($native_type === 'blog') {
        // ── BLOG ──────────────────────────────────────────
        $sheet_name = 'Posts_WP';
        $headers    = ['_ws_import_id', 'wp_status_wordpress', 'view_display',
                       'post_title', 'post_excerpt', 'post_name', 'image_url',
                       'category', 'post_tag', 'post_content'];

        // Crear hoja si no existe
        $create_sheet($sheet_name, $headers);
        $native_sheets['post'] = $sheet_name;
        $mapping_all['post'] = [
            '_ws_import_id'       => ['type' => 'id',           'required' => 0, 'options' => []],
            'wp_status_wordpress' => ['type' => 'wp_status',    'required' => 0, 'options' => []],
            'view_display'        => ['type' => 'text',         'required' => 0, 'options' => []],
            'post_title'          => ['type' => 'wp_title',     'required' => 1, 'options' => []],
            'post_excerpt'        => ['type' => 'wp_excerpt',   'required' => 0, 'options' => []],
            'post_name'           => ['type' => 'wp_slug',      'required' => 0, 'options' => []],
            'image_url'           => ['type' => 'wp_thumbnail', 'required' => 0, 'options' => []],
            'category'            => ['type' => 'taxonomy',     'required' => 0, 'options' => ['tax_target' => 'category',  'tax_autocreate' => '1']],
            'post_tag'            => ['type' => 'taxonomy',     'required' => 0, 'options' => ['tax_target' => 'post_tag', 'tax_autocreate' => '1']],
            'post_content'        => ['type' => 'wp_content',   'required' => 0, 'options' => []],
        ];
        update_option('wpsheets_fields_mapping', $mapping_all);
        $results[] = 'Mapeo configurado (10 columnas)';

        // Categorías del blog
        $cat_sheet = 'Posts_Category_WP';
        $create_sheet($cat_sheet, ['_ws_import_id', 'wp_status_wordpress', 'view_display',
                                   'tax_name', 'tax_slug', 'tax_desc', 'parent', 'image_url']);
        $native_sheets['tax_category'] = $cat_sheet;
        $mapping_all['tax_category'] = [
            '_ws_import_id'       => ['type' => 'id',         'required' => 0, 'options' => []],
            'wp_status_wordpress' => ['type' => 'wp_status',  'required' => 0, 'options' => []],
            'view_display'        => ['type' => 'text',       'required' => 0, 'options' => []],
            'tax_name'            => ['type' => 'tax_name',   'required' => 1, 'options' => []],
            'tax_slug'            => ['type' => 'tax_slug',   'required' => 0, 'options' => []],
            'tax_desc'            => ['type' => 'tax_desc',   'required' => 0, 'options' => []],
            'parent'              => ['type' => 'tax_parent', 'required' => 0, 'options' => []],
            'image_url'           => ['type' => 'image_url',  'required' => 0, 'options' => []],
        ];
        update_option('wpsheets_fields_mapping', $mapping_all);

        // Etiquetas del blog
        $tag_sheet = 'Posts_Tags_WP';
        $create_sheet($tag_sheet, ['_ws_import_id', 'wp_status_wordpress', 'view_display',
                                   'tax_name', 'tax_slug', 'tax_desc']);
        $native_sheets['tax_post_tag'] = $tag_sheet;
        $mapping_all['tax_post_tag'] = [
            '_ws_import_id'       => ['type' => 'id',        'required' => 0, 'options' => []],
            'wp_status_wordpress' => ['type' => 'wp_status', 'required' => 0, 'options' => []],
            'view_display'        => ['type' => 'text',      'required' => 0, 'options' => []],
            'tax_name'            => ['type' => 'tax_name',  'required' => 1, 'options' => []],
            'tax_slug'            => ['type' => 'tax_slug',  'required' => 0, 'options' => []],
            'tax_desc'            => ['type' => 'tax_desc',  'required' => 0, 'options' => []],
        ];
        update_option('wpsheets_fields_mapping', $mapping_all);

        // Guardar todo
        update_option('wpsheets_native_cpts', $native_sheets);
        update_option('wpsheets_fields_mapping', $mapping_all);

        // Exportar entradas existentes
        $exported = wpsheets_bulk_export_cpt('post', $sheet_name, 'post');
        if ($exported > 0) $results[] = "<strong>{$exported} entradas</strong> exportadas";

        // Exportar categorías y etiquetas
        $exp_cats = wpsheets_bulk_export_taxonomy('category', $cat_sheet, 'tax_category');
        if ($exp_cats > 0) $results[] = "<strong>{$exp_cats} categorías</strong> exportadas";

        $exp_tags = wpsheets_bulk_export_taxonomy('post_tag', $tag_sheet, 'tax_post_tag');
        if ($exp_tags > 0) $results[] = "<strong>{$exp_tags} etiquetas</strong> exportadas";

    } elseif ($native_type === 'projects' && !empty($cpt_slug)) {
        // ── PROJECTS ──────────────────────────────────────
        $cpt_obj = get_post_type_object($cpt_slug);
        if (!$cpt_obj) wp_send_json_error("CPT '{$cpt_slug}' no encontrado.");

        // Hoja principal de proyectos
        $sheet_name = 'Projects_WP';
        $headers    = ['_ws_import_id', 'wp_status_wordpress', 'view_display',
                       'post_title', 'post_excerpt', 'post_name', 'image_url', 'post_content'];
        $create_sheet($sheet_name, $headers);
        $native_sheets[$cpt_slug] = $sheet_name;

        // Mapeo manual para los campos conocidos
        $mapping_all[$cpt_slug] = [
            '_ws_import_id'       => ['type' => 'id',           'required' => 0, 'options' => []],
            'wp_status_wordpress' => ['type' => 'wp_status',    'required' => 0, 'options' => []],
            'view_display'        => ['type' => 'text',         'required' => 0, 'options' => []],
            'post_title'          => ['type' => 'wp_title',     'required' => 1, 'options' => []],
            'post_excerpt'        => ['type' => 'wp_excerpt',   'required' => 0, 'options' => []],
            'post_name'           => ['type' => 'wp_slug',      'required' => 0, 'options' => []],
            'image_url'           => ['type' => 'wp_thumbnail', 'required' => 0, 'options' => []],
            'post_content'        => ['type' => 'wp_content',   'required' => 0, 'options' => []],
        ];
        $results[] = 'Mapeo de Projects configurado';

        // Hojas de taxonomías asociadas al CPT
        $cpt_taxs = get_object_taxonomies($cpt_slug, 'objects');
        foreach ($cpt_taxs as $ct) {
            if (!$ct->public || $ct->name === 'post_format') continue;
            // Nombre de hoja: Projects_NombreTax
            $tax_sheet_name = 'Projects_WP_' . ucfirst(str_replace(['pa_','-'], ['','_'], $ct->name));
            $tax_headers    = ['_ws_import_id', 'wp_status_wordpress', 'view_display',
                               'tax_name', 'tax_slug', 'tax_desc', 'parent', 'image_url'];
            $create_sheet($tax_sheet_name, $tax_headers);
            $native_sheets['tax_' . $ct->name] = $tax_sheet_name;
            // Mapeo de la taxonomía
            $mapping_all['tax_' . $ct->name] = [
                '_ws_import_id'       => ['type' => 'id',         'required' => 0, 'options' => []],
                'wp_status_wordpress' => ['type' => 'wp_status',  'required' => 0, 'options' => []],
                'view_display'        => ['type' => 'text',       'required' => 0, 'options' => []],
                'tax_name'            => ['type' => 'tax_name',   'required' => 1, 'options' => []],
                'tax_slug'            => ['type' => 'tax_slug',   'required' => 0, 'options' => []],
                'tax_desc'            => ['type' => 'tax_desc',   'required' => 0, 'options' => []],
                'parent'              => ['type' => 'tax_parent', 'required' => 0, 'options' => []],
                'image_url'           => ['type' => 'image_url',  'required' => 0, 'options' => []],
            ];
            // Exportar términos existentes
            $exp_tax = wpsheets_bulk_export_taxonomy($ct->name, $tax_sheet_name, 'tax_' . $ct->name);
            if ($exp_tax > 0) $results[] = "<strong>{$exp_tax} términos</strong> de {$ct->label} exportados";
        }

        update_option('wpsheets_native_cpts', $native_sheets);
        update_option('wpsheets_fields_mapping', $mapping_all);

        // Exportar proyectos existentes
        $exported = wpsheets_bulk_export_cpt($cpt_slug, $sheet_name, $cpt_slug);
        if ($exported > 0) $results[] = "<strong>{$exported} proyectos</strong> exportados";
        else $results[] = 'Sin proyectos existentes (las hojas están listas)';

    } elseif ($native_type === 'pages') {
        // ── PÁGINAS ──────────────────────────────────────────
        $sheet_name = 'Pages_WP';
        $headers    = ['_ws_import_id', 'wp_status_wordpress', 'view_display',
                       'post_title', 'post_excerpt', 'post_name', 'image_url', 'post_content'];
        $create_sheet($sheet_name, $headers);
        $native_sheets['page'] = $sheet_name;
        $mapping_all['page'] = [
            '_ws_import_id'       => ['type' => 'id',           'required' => 0, 'options' => []],
            'wp_status_wordpress' => ['type' => 'wp_status',    'required' => 0, 'options' => []],
            'view_display'        => ['type' => 'text',         'required' => 0, 'options' => []],
            'post_title'          => ['type' => 'wp_title',     'required' => 1, 'options' => []],
            'post_excerpt'        => ['type' => 'wp_excerpt',   'required' => 0, 'options' => []],
            'post_name'           => ['type' => 'wp_slug',      'required' => 0, 'options' => []],
            'image_url'           => ['type' => 'wp_thumbnail', 'required' => 0, 'options' => []],
            'post_content'        => ['type' => 'wp_content',   'required' => 0, 'options' => []],
        ];
        update_option('wpsheets_native_cpts', $native_sheets);
        update_option('wpsheets_fields_mapping', $mapping_all);
        $results[] = 'Mapeo de Páginas configurado';
        $exported = wpsheets_bulk_export_cpt('page', $sheet_name, 'page');
        if ($exported > 0) $results[] = "<strong>{$exported} páginas</strong> exportadas";
        else $results[] = 'Sin páginas para exportar (hoja lista)';

    } else {
        wp_send_json_error('Tipo no reconocido.');
    }

    wp_send_json_success('✅ Inicialización completada:<br>' . implode('<br>', $results));
});

// ============================================================
// AJAX: Exportar Blog o Projects (con selector de entidad)
// ============================================================
add_action('wp_ajax_wpsheets_export_native', function() {
    check_ajax_referer('wpsheets_ajax_nonce', 'nonce');
    $native_type   = sanitize_key($_POST['native_type'] ?? '');
    $cpt_slug      = sanitize_key($_POST['cpt_slug'] ?? '');
    $entity        = sanitize_key($_POST['entity'] ?? 'all');
    $native_sheets = get_option('wpsheets_native_cpts', []);
    $results       = [];

    if ($native_type === 'blog') {
        if (in_array($entity, ['all', 'posts'])) {
            $sheet = $native_sheets['post'] ?? 'Posts_WP';
            $n     = wpsheets_bulk_export_cpt('post', $sheet, 'post');
            if ($n > 0) $results[] = "<strong>{$n} entradas</strong> → {$sheet}";
        }
        if (in_array($entity, ['all', 'categories'])) {
            $sheet = $native_sheets['tax_category'] ?? 'Posts_Category_WP';
            $n     = wpsheets_bulk_export_taxonomy('category', $sheet, 'tax_category');
            if ($n > 0) $results[] = "<strong>{$n} categorías</strong> → {$sheet}";
        }
        if (in_array($entity, ['all', 'tags'])) {
            $sheet = $native_sheets['tax_post_tag'] ?? 'Posts_Tags_WP';
            $n     = wpsheets_bulk_export_taxonomy('post_tag', $sheet, 'tax_post_tag');
            if ($n > 0) $results[] = "<strong>{$n} etiquetas</strong> → {$sheet}";
        }
    } elseif ($native_type === 'projects' && !empty($cpt_slug)) {
        if (in_array($entity, ['all', 'posts'])) {
            $sheet = $native_sheets[$cpt_slug] ?? 'Projects_WP';
            $n     = wpsheets_bulk_export_cpt($cpt_slug, $sheet, $cpt_slug);
            if ($n > 0) $results[] = "<strong>{$n} proyectos</strong> → {$sheet}";
        }
        // Taxonomías: entity = 'tax_category_slug'
        if ($entity === 'all' || strpos($entity, 'tax_') === 0) {
            $cpt_taxs = get_object_taxonomies($cpt_slug, 'objects');
            foreach ($cpt_taxs as $ct) {
                if (!$ct->public || $ct->name === 'post_format') continue;
                $tax_key = 'tax_' . $ct->name;
                if ($entity !== 'all' && $entity !== $tax_key) continue;
                $sheet = $native_sheets[$tax_key] ?? '';
                if (empty($sheet)) continue;
                $n = wpsheets_bulk_export_taxonomy($ct->name, $sheet, $tax_key);
                if ($n > 0) $results[] = "<strong>{$n} {$ct->label}</strong> → {$sheet}";
            }
        }
    } elseif ($native_type === 'pages') {
        $sheet = $native_sheets['page'] ?? 'Pages_WP';
        $n     = wpsheets_bulk_export_cpt('page', $sheet, 'page');
        if ($n > 0) $results[] = "<strong>{$n} páginas</strong> → {$sheet}";
    } else {
        wp_send_json_error('Tipo no válido.');
    }

    if (empty($results)) {
        wp_send_json_success('Sin datos para exportar (las hojas ya están actualizadas).');
    }
    wp_send_json_success('✅ ' . implode(', ', $results));
});

