<?php
if (!defined('ABSPATH')) exit;

add_action('et_builder_ready', 'wpsheets_register_divi_module');
function wpsheets_register_divi_module() {
    // Solo registrar si el módulo está habilitado en Configuración
    if (!get_option('wpsheets_divi_enabled', 0)) return;
    if (!class_exists('ET_Builder_Module')) return;
    if (class_exists('WPSheets_Divi_Module')) return;

    class WPSheets_Divi_Module extends ET_Builder_Module {
        public $slug       = 'et_pb_wpsheets_data';
        public $vb_support = 'on';

        public function init() {
            $this->name = esc_html__('WP Sheets Data', 'wpsheets');
            $this->icon = 'C'; 
            $this->settings_modal_toggles = [
                'general' => [
                    'toggles' => [
                        'main_content'   => esc_html__('Configuración Principal', 'wpsheets'),
                        'gallery_layout' => esc_html__('Estructura de Galería', 'wpsheets'),
                        'gallery_pagination'=>esc_html__('Paginación y UI', 'wpsheets'),
                        'gallery_slider' => esc_html__('Controles de Carrusel', 'wpsheets'),
                        'gallery_effects'=> esc_html__('Efectos y Overlay', 'wpsheets'),
                        'gallery_shadow' => esc_html__('Sombra de Imagen', 'wpsheets'),
                        'gallery_modal'  => esc_html__('Visor Lightbox', 'wpsheets'),
                    ],
                ],
            ];
        }

        public function get_fields() {
            $mapping = get_option('wpsheets_fields_mapping', []);
            $cpts = get_option('wpsheets_cpts', []);
            $taxs = get_option('wpsheets_taxonomies', []);

            $cpt_label = (is_array($cpts) && !empty($cpts) && isset($cpts[0]['plural'])) ? $cpts[0]['plural'] : 'Platillo';
            $tax_label = (is_array($taxs) && !empty($taxs) && isset($taxs[0]['plural'])) ? $taxs[0]['plural'] : 'Categoría';

            $col_post_options = ['' => '-- Elige una columna --', 'wp_title' => 'Título Nativo', 'wp_content' => 'Contenido Nativo', 'visibilidad' => 'Visibilidad'];
            $col_tax_options = ['' => '-- Elige una columna --', 'tax_name' => 'Nombre', 'tax_desc' => 'Descripción', 'view_display' => 'Visibilidad (view_display)'];

            if (is_array($mapping)) {
                foreach($mapping as $obj => $cols) {
                    if (is_array($cols)) {
                        if(strpos($obj, 'tax_') === false) { foreach($cols as $col_key => $cfg) $col_post_options[$col_key] = $col_key; } 
                        else { foreach($cols as $col_key => $cfg) $col_tax_options[$col_key] = $col_key; }
                    }
                }
            }

            global $wpdb;

            // OPTIMIZACIÓN 1: Caché de consultas y JOIN directo en SQL para evitar cientos de llamadas a get_the_title() y get_term()
            $post_ids = get_transient('ws_divi_post_options');
            if (false === $post_ids) {
                $post_ids = ['current' => '🌍 GLOBAL (Post/Plantilla Actual)', '' => '-- Selecciona un Platillo Específico --'];
                $res_p = $wpdb->get_results("
                    SELECT p.ID, p.post_title, m.meta_value 
                    FROM {$wpdb->posts} p 
                    INNER JOIN {$wpdb->postmeta} m ON p.ID = m.post_id 
                    WHERE m.meta_key = '_ws_import_id' AND p.post_status IN ('publish', 'draft', 'private')
                    LIMIT 300
                ");
                if (is_array($res_p)) {
                    foreach($res_p as $p) {
                        if(!empty($p->meta_value)) {
                            if (strlen($p->meta_value) > 50 || strpos($p->meta_value, 'http') !== false) continue;
                            $post_ids[$p->meta_value] = "ID: {$p->meta_value} - " . ($p->post_title ? $p->post_title : 'Sin título');
                        }
                    }
                }
                set_transient('ws_divi_post_options', $post_ids, 2 * HOUR_IN_SECONDS);
            }

            $tax_ids = get_transient('ws_divi_tax_options');
            if (false === $tax_ids) {
                $tax_ids = ['current' => '🌍 GLOBAL (Categoría/Plantilla Actual)', '' => '-- Selecciona una Categoría Específica --'];
                $res_t = $wpdb->get_results("
                    SELECT t.term_id, t.name, m.meta_value 
                    FROM {$wpdb->terms} t
                    INNER JOIN {$wpdb->termmeta} m ON t.term_id = m.term_id
                    WHERE m.meta_key = '_ws_import_id'
                    LIMIT 200
                ");
                if (is_array($res_t)) {
                    foreach($res_t as $t) {
                        if(!empty($t->meta_value)) {
                            if (strlen($t->meta_value) > 50 || strpos($t->meta_value, 'http') !== false) continue;
                            $tax_ids[$t->meta_value] = "ID: {$t->meta_value} - {$t->name}";
                        }
                    }
                }
                set_transient('ws_divi_tax_options', $tax_ids, 2 * HOUR_IN_SECONDS);
            }

            return [
                'ws_type' => ['label' => '1. ¿Qué vas a mostrar?', 'type' => 'select', 'options' => ['post' => $cpt_label, 'tax'  => $tax_label], 'default' => 'post', 'tab_slug' => 'general', 'toggle_slug' => 'main_content'],
                'ws_key_post' => ['label' => '2. Dato del Platillo', 'type' => 'select', 'options' => $col_post_options, 'tab_slug' => 'general', 'toggle_slug' => 'main_content', 'show_if' => ['ws_type' => 'post']],
                'ws_id_post' => ['label' => '3. Selecciona el Platillo', 'type' => 'select', 'options' => $post_ids, 'default' => 'current', 'tab_slug' => 'general', 'toggle_slug' => 'main_content', 'show_if' => ['ws_type' => 'post']],
                'ws_key_tax' => ['label' => '2. Dato de la Categoría', 'type' => 'select', 'options' => $col_tax_options, 'tab_slug' => 'general', 'toggle_slug' => 'main_content', 'show_if' => ['ws_type' => 'tax']],
                'ws_id_tax' => ['label' => '3. Selecciona la Categoría', 'type' => 'select', 'options' => $tax_ids, 'default' => 'current', 'tab_slug' => 'general', 'toggle_slug' => 'main_content', 'show_if' => ['ws_type' => 'tax']],

                'ws_is_gallery' => ['label' => '¿Es una Galería de Imágenes?', 'type' => 'yes_no_button', 'options' => ['off' => 'No', 'on'  => 'Sí'], 'default' => 'off', 'tab_slug' => 'general', 'toggle_slug' => 'gallery_layout'],
                
                'ws_gal_random' => ['label' => '¿Orden Aleatorio (Mezclar al cargar)?', 'type' => 'yes_no_button', 'options' => ['off' => 'No', 'on'  => 'Sí'], 'default' => 'off', 'tab_slug' => 'general', 'toggle_slug' => 'gallery_layout', 'show_if' => ['ws_is_gallery' => 'on']],

                'ws_gallery_layout' => ['label' => 'Diseño de la Galería', 'type' => 'select', 'options' => ['grid' => 'Cuadrícula Estricta', 'masonry' => 'Mosaico Clásico', 'metro' => 'Bento Grid (Mosaico Moderno)', 'slider' => 'Carrusel Fluido (Slider)'], 'default' => 'metro', 'tab_slug' => 'general', 'toggle_slug' => 'gallery_layout', 'show_if' => ['ws_is_gallery' => 'on']],
                
                // BENTO SETTINGS
                'ws_gal_bento_style' => ['label' => 'Preset de Diseño Bento', 'type' => 'select', 'options' => ['1'=>'Estilo 1 (1ra gigante)', '2'=>'Estilo 2 (2da y 5ta grandes)', '3'=>'Estilo 3 (Toda la 1ra fila ancha)', '4'=>'Estilo 4 (Ajedrez grande)', '5'=>'Estilo 5 (Pares anchas)', '6'=>'Estilo 6 (Impares altas)', '7'=>'Estilo 7 (1ra Gigante Central)', '8'=>'Estilo 8 (Aleatorio estructurado)', '9'=>'Estilo 9 (Centro Destacado)', '10'=>'Estilo 10 (Muro asimétrico)'], 'default' => '1', 'tab_slug' => 'general', 'toggle_slug' => 'gallery_layout', 'show_if' => ['ws_is_gallery' => 'on', 'ws_gallery_layout' => 'metro']],
                'ws_gal_bento_row_h' => ['label' => 'Altura Base de Fila Bento (px)', 'type' => 'range', 'default' => '200', 'range_settings' => ['min'=>'100','max'=>'500','step'=>'10'], 'tab_slug' => 'general', 'toggle_slug' => 'gallery_layout', 'show_if' => ['ws_is_gallery' => 'on', 'ws_gallery_layout' => 'metro']],
                'ws_gal_bento_rows'  => ['label' => 'Forzar Número de Filas (0 = Automático)', 'type' => 'range', 'default' => '0', 'range_settings' => ['min'=>'0','max'=>'10','step'=>'1'], 'tab_slug' => 'general', 'toggle_slug' => 'gallery_layout', 'show_if' => ['ws_is_gallery' => 'on', 'ws_gallery_layout' => 'metro']],
                'ws_gal_bento_fill'  => ['label' => 'Smart Fill (Rellenar huecos con IA)', 'type' => 'select', 'options' => ['off'=>'Apagado', 'hor'=>'Prioridad Horizontal (Ancho)', 'ver'=>'Prioridad Vertical (Alto)', 'both'=>'Inteligente Bidireccional'], 'default' => 'both', 'tab_slug' => 'general', 'toggle_slug' => 'gallery_layout', 'show_if' => ['ws_is_gallery' => 'on', 'ws_gallery_layout' => 'metro']],

                'ws_gal_cols_desktop' => ['label' => 'Columnas (Escritorio)', 'type' => 'range', 'default' => '4', 'range_settings' => ['min'=>'1','max'=>'8','step'=>'1'], 'tab_slug' => 'general', 'toggle_slug' => 'gallery_layout', 'show_if' => ['ws_is_gallery' => 'on']],
                'ws_gal_cols_tablet'  => ['label' => 'Columnas (Tablet)', 'type' => 'range', 'default' => '2', 'range_settings' => ['min'=>'1','max'=>'8','step'=>'1'], 'tab_slug' => 'general', 'toggle_slug' => 'gallery_layout', 'show_if' => ['ws_is_gallery' => 'on']],
                'ws_gal_cols_mobile'  => ['label' => 'Columnas (Móvil)', 'type' => 'range', 'default' => '1', 'range_settings' => ['min'=>'1','max'=>'8','step'=>'1'], 'tab_slug' => 'general', 'toggle_slug' => 'gallery_layout', 'show_if' => ['ws_is_gallery' => 'on']],
                'ws_gal_gap'          => ['label' => 'Espaciado (px)', 'type' => 'range', 'default' => '15', 'range_settings' => ['min'=>'0','max'=>'100','step'=>'1'], 'tab_slug' => 'general', 'toggle_slug' => 'gallery_layout', 'show_if' => ['ws_is_gallery' => 'on']],
                
                // SLIDER MAX WIDTH
                'ws_gal_slider_max_w' => ['label' => 'Ancho Máximo de la Imagen (0 = Automático)', 'type' => 'range', 'default' => '0', 'range_settings' => ['min'=>'0','max'=>'800','step'=>'10'], 'description' => 'Evita que las imágenes se vean gigantes en pantallas grandes cuando hay pocas columnas.', 'tab_slug' => 'general', 'toggle_slug' => 'gallery_slider', 'show_if' => ['ws_is_gallery' => 'on', 'ws_gallery_layout' => 'slider']],

                // PAGINACIÓN AVANZADA
                'ws_gal_pagination'   => ['label' => 'Tipo de Paginación', 'type' => 'select', 'options' => ['none'=>'Mostrar todas', 'btn'=>'Botón de "Ver Más"', 'numbers'=>'Números de Página (1, 2, 3...)', 'scroll'=>'Scroll Infinito'], 'default' => 'none', 'tab_slug' => 'general', 'toggle_slug' => 'gallery_pagination', 'show_if' => ['ws_is_gallery' => 'on']],
                'ws_gal_pag_pos'      => ['label' => 'Posición', 'type' => 'select', 'options' => ['bottom'=>'Abajo de la galería', 'top'=>'Arriba de la galería'], 'default' => 'bottom', 'tab_slug' => 'general', 'toggle_slug' => 'gallery_pagination', 'show_if' => ['ws_gal_pagination' => ['btn', 'numbers']]],
                'ws_gal_pag_align'    => ['label' => 'Alineación', 'type' => 'select', 'options' => ['flex-start'=>'Izquierda', 'center'=>'Centro', 'flex-end'=>'Derecha'], 'default' => 'center', 'tab_slug' => 'general', 'toggle_slug' => 'gallery_pagination', 'show_if' => ['ws_gal_pagination' => ['btn', 'numbers', 'scroll']]],
                'ws_gal_per_page'     => ['label' => 'Imágenes a mostrar por página', 'type' => 'range', 'default' => '6', 'range_settings' => ['min'=>'1','max'=>'50','step'=>'1'], 'tab_slug' => 'general', 'toggle_slug' => 'gallery_pagination', 'show_if' => ['ws_gal_pagination' => ['btn', 'scroll', 'numbers']]],
                'ws_gal_pag_size'     => ['label' => 'Tamaño de Texto (px)', 'type' => 'range', 'default' => '16', 'range_settings' => ['min'=>'10','max'=>'40','step'=>'1'], 'tab_slug' => 'general', 'toggle_slug' => 'gallery_pagination', 'show_if' => ['ws_gal_pagination' => ['btn', 'numbers']]],
                'ws_gal_pag_pad'      => ['label' => 'Relleno / Padding (px)', 'type' => 'range', 'default' => '12', 'range_settings' => ['min'=>'4','max'=>'40','step'=>'1'], 'tab_slug' => 'general', 'toggle_slug' => 'gallery_pagination', 'show_if' => ['ws_gal_pagination' => ['btn', 'numbers']]],
                'ws_gal_pag_rad'      => ['label' => 'Bordes Redondeados (px)', 'type' => 'range', 'default' => '50', 'range_settings' => ['min'=>'0','max'=>'100','step'=>'1'], 'description' => '0 es cuadrado, 50 es círculo.', 'tab_slug' => 'general', 'toggle_slug' => 'gallery_pagination', 'show_if' => ['ws_gal_pagination' => ['btn', 'numbers']]],
                
                'ws_gal_btn_text'     => ['label' => 'Texto del Botón', 'type' => 'text', 'default' => 'Cargar Más Imágenes', 'tab_slug' => 'general', 'toggle_slug' => 'gallery_pagination', 'show_if' => ['ws_gal_pagination' => 'btn']],
                'ws_gal_btn_bg'       => ['label' => 'Color Principal (Fondo/Activo)', 'type' => 'color-alpha', 'default' => '#2563EB', 'tab_slug' => 'general', 'toggle_slug' => 'gallery_pagination', 'show_if' => ['ws_gal_pagination' => ['btn', 'numbers']]],
                'ws_gal_btn_color'    => ['label' => 'Color de Texto (Activo)', 'type' => 'color-alpha', 'default' => '#ffffff', 'tab_slug' => 'general', 'toggle_slug' => 'gallery_pagination', 'show_if' => ['ws_gal_pagination' => ['btn', 'numbers']]],

                // Efectos y Overlay
                'ws_gal_radius'       => ['label' => 'Bordes redondeados (px)', 'type' => 'range', 'default' => '8', 'range_settings' => ['min'=>'0','max'=>'100','step'=>'1'], 'tab_slug' => 'general', 'toggle_slug' => 'gallery_effects', 'show_if' => ['ws_is_gallery' => 'on']],
                'ws_gal_ratio'        => ['label' => 'Proporción', 'type' => 'select', 'options' => ['auto'=>'Original', '1/1'=>'Cuadrado (1:1)', '4/5'=>'Vertical IG (4:5)', '9/16'=>'Stories (9:16)', '16/9'=>'Horizontal (16:9)'], 'default' => 'auto', 'tab_slug' => 'general', 'toggle_slug' => 'gallery_effects', 'show_if' => ['ws_is_gallery' => 'on']],
                'ws_gal_fit'          => ['label' => 'Ajuste (Object-fit)', 'type' => 'select', 'options' => ['cover'=>'Cubrir espacio', 'contain'=>'Contener entera'], 'default' => 'cover', 'tab_slug' => 'general', 'toggle_slug' => 'gallery_effects', 'show_if' => ['ws_is_gallery' => 'on']],
                'ws_gal_hover'        => ['label' => 'Efecto de Imagen (Hover)', 'type' => 'select', 'options' => ['none'=>'Ninguno', 'zoom'=>'Zoom interior', 'bw'=>'Blanco y Negro a Color', 'blur'=>'Desenfocar a Claro', 'sepia'=>'Sepia a Color', 'rotate'=>'Giro Ligero'], 'default' => 'zoom', 'tab_slug' => 'general', 'toggle_slug' => 'gallery_effects', 'show_if' => ['ws_is_gallery' => 'on']],
                
                'ws_gal_overlay'      => ['label' => 'Activar Capa de Color (Overlay)', 'type' => 'yes_no_button', 'options' => ['off'=>'No', 'on'=>'Sí'], 'default' => 'off', 'tab_slug' => 'general', 'toggle_slug' => 'gallery_effects', 'show_if' => ['ws_is_gallery' => 'on']],
                'ws_gal_overlay_color'=> ['label' => 'Color del Overlay', 'type' => 'color-alpha', 'default' => 'rgba(0,0,0,0.4)', 'tab_slug' => 'general', 'toggle_slug' => 'gallery_effects', 'show_if' => ['ws_gal_overlay' => 'on']],
                'ws_gal_overlay_icon' => ['label' => 'Mostrar Ícono de Lupa en Overlay', 'type' => 'yes_no_button', 'options' => ['off'=>'No', 'on'=>'Sí'], 'default' => 'on', 'tab_slug' => 'general', 'toggle_slug' => 'gallery_effects', 'show_if' => ['ws_gal_overlay' => 'on']],

                // Sombra Personalizada
                'ws_gal_shadow_x'     => ['label' => 'Posición Horizontal (X)', 'type' => 'range', 'default' => '0', 'range_settings' => ['min'=>'-50','max'=>'50','step'=>'1'], 'tab_slug' => 'general', 'toggle_slug' => 'gallery_shadow', 'show_if' => ['ws_is_gallery' => 'on']],
                'ws_gal_shadow_y'     => ['label' => 'Posición Vertical (Y)', 'type' => 'range', 'default' => '10', 'range_settings' => ['min'=>'-50','max'=>'50','step'=>'1'], 'tab_slug' => 'general', 'toggle_slug' => 'gallery_shadow', 'show_if' => ['ws_is_gallery' => 'on']],
                'ws_gal_shadow_blur'  => ['label' => 'Fuerza de Desenfoque (Blur)', 'type' => 'range', 'default' => '20', 'range_settings' => ['min'=>'0','max'=>'100','step'=>'1'], 'tab_slug' => 'general', 'toggle_slug' => 'gallery_shadow', 'show_if' => ['ws_is_gallery' => 'on']],
                'ws_gal_shadow_spread'=> ['label' => 'Fuerza de Expansión (Spread)', 'type' => 'range', 'default' => '0', 'range_settings' => ['min'=>'-50','max'=>'50','step'=>'1'], 'tab_slug' => 'general', 'toggle_slug' => 'gallery_shadow', 'show_if' => ['ws_is_gallery' => 'on']],
                'ws_gal_shadow_color' => ['label' => 'Color de la Sombra', 'type' => 'color-alpha', 'default' => 'rgba(0,0,0,0.3)', 'tab_slug' => 'general', 'toggle_slug' => 'gallery_shadow', 'show_if' => ['ws_is_gallery' => 'on']],

                // Modal Personalizable
                'ws_gal_lightbox'     => ['label' => 'Activar Lightbox Fullscreen', 'type' => 'yes_no_button', 'options' => ['off'=>'No', 'on'=>'Sí'], 'default' => 'on', 'tab_slug' => 'general', 'toggle_slug' => 'gallery_modal', 'show_if' => ['ws_is_gallery' => 'on']],
                'ws_gal_modal_bg'     => ['label' => 'Color y Transparencia de Fondo', 'type' => 'color-alpha', 'default' => 'rgba(0,0,0,0.95)', 'tab_slug' => 'general', 'toggle_slug' => 'gallery_modal', 'show_if' => ['ws_gal_lightbox' => 'on']],
                'ws_gal_modal_text'   => ['label' => 'Mostrar Texto debajo de la imagen', 'type' => 'select', 'options' => ['none'=>'Sin texto', 'filename'=>'Nombre del archivo', 'alt'=>'Texto Alternativo (Alt)', 'caption'=>'Leyenda de la Imagen'], 'default' => 'none', 'tab_slug' => 'general', 'toggle_slug' => 'gallery_modal', 'show_if' => ['ws_gal_lightbox' => 'on']],
                'ws_gal_modal_arr_mob'=> ['label' => 'Mostrar Flechas en Móvil/Tablet', 'type' => 'yes_no_button', 'options' => ['off'=>'No', 'on'=>'Sí'], 'default' => 'on', 'description' => 'Si lo apagas, en pantallas pequeñas solo se podrá cambiar de foto deslizando el dedo (Swipe).', 'tab_slug' => 'general', 'toggle_slug' => 'gallery_modal', 'show_if' => ['ws_gal_lightbox' => 'on']],

                // Controles Carrusel
                'ws_gal_slider_center'=> ['label' => 'Modo Centrado (Destacar imagen media)', 'type' => 'yes_no_button', 'options' => ['off'=>'No', 'on'=>'Sí'], 'default' => 'off', 'tab_slug' => 'general', 'toggle_slug' => 'gallery_slider', 'show_if' => ['ws_gallery_layout' => 'slider']],
                'ws_gal_slider_loop'  => ['label' => 'Loop Infinito Fluido', 'type' => 'yes_no_button', 'options' => ['off'=>'No', 'on'=>'Sí'], 'default' => 'on', 'tab_slug' => 'general', 'toggle_slug' => 'gallery_slider', 'show_if' => ['ws_gallery_layout' => 'slider']],
                'ws_gal_autoplay'     => ['label' => 'Autoplay', 'type' => 'yes_no_button', 'options' => ['off'=>'No', 'on'=>'Sí'], 'default' => 'off', 'tab_slug' => 'general', 'toggle_slug' => 'gallery_slider', 'show_if' => ['ws_gallery_layout' => 'slider']],
                'ws_gal_auto_delay'   => ['label' => 'Velocidad Autoplay (ms)', 'type' => 'range', 'default' => '3000', 'range_settings' => ['min'=>'1000','max'=>'10000','step'=>'500'], 'tab_slug' => 'general', 'toggle_slug' => 'gallery_slider', 'show_if' => ['ws_gal_autoplay' => 'on']],
                'ws_gal_arrows'       => ['label' => 'Mostrar Flechas', 'type' => 'yes_no_button', 'options' => ['off'=>'No', 'on'=>'Sí'], 'default' => 'on', 'tab_slug' => 'general', 'toggle_slug' => 'gallery_slider', 'show_if' => ['ws_gallery_layout' => 'slider']],
                'ws_gal_arrow_pos'    => ['label' => 'Posición', 'type' => 'select', 'options' => ['inside'=>'Adentro de la imagen', 'outside'=>'Afuera (Flotantes)'], 'default' => 'outside', 'tab_slug' => 'general', 'toggle_slug' => 'gallery_slider', 'show_if' => ['ws_gal_arrows' => 'on']],
                'ws_gal_arrow_bg'     => ['label' => 'Color Fondo Flechas', 'type' => 'color-alpha', 'default' => '#ffffff', 'tab_slug' => 'general', 'toggle_slug' => 'gallery_slider', 'show_if' => ['ws_gal_arrows' => 'on']],
                'ws_gal_arrow_color'  => ['label' => 'Color Ícono Flechas', 'type' => 'color-alpha', 'default' => '#000000', 'tab_slug' => 'general', 'toggle_slug' => 'gallery_slider', 'show_if' => ['ws_gal_arrows' => 'on']],
                'ws_gal_dots'         => ['label' => 'Mostrar Puntos (Dots)', 'type' => 'yes_no_button', 'options' => ['off'=>'No', 'on'=>'Sí'], 'default' => 'on', 'tab_slug' => 'general', 'toggle_slug' => 'gallery_slider', 'show_if' => ['ws_gallery_layout' => 'slider']],
                'ws_gal_dot_active'   => ['label' => 'Color Punto Activo', 'type' => 'color-alpha', 'default' => '#2563EB', 'tab_slug' => 'general', 'toggle_slug' => 'gallery_slider', 'show_if' => ['ws_gal_dots' => 'on']],
            ];
        }

        public function render($attrs, $content = null, $render_slug = null) {
            $type = $this->props['ws_type'] ?? 'post';
            $id   = $this->props[$type === 'tax' ? 'ws_id_tax' : 'ws_id_post'] ?? '';
            $key  = $this->props[$type === 'tax' ? 'ws_key_tax' : 'ws_key_post'] ?? '';

            if (empty($id) || empty($key)) return '<span style="padding:10px; background:#fee2e2; border-radius:4px;">[WP Sheets: Configura las opciones en el panel]</span>';

            $val = '';
            
            // LÓGICA DINÁMICA (MÁGICA) PARA POSTS ACTUALES EN DIVI
            if ($type === 'tax') {
                if ($id === 'current') {
                    $current_term = get_queried_object();
                    if ($current_term && isset($current_term->term_id)) {
                        if ($key === 'tax_name') $val = $current_term->name;
                        elseif ($key === 'tax_desc') $val = $current_term->description;
                        else $val = get_term_meta($current_term->term_id, $key, true);
                    }
                } else {
                    $terms = get_terms(['hide_empty' => false, 'meta_query' => [['key' => '_ws_import_id', 'value' => $id]], 'number' => 1]);
                    if (!empty($terms) && !is_wp_error($terms)) { $val = $key === 'tax_name' ? $terms[0]->name : ($key === 'tax_desc' ? $terms[0]->description : get_term_meta($terms[0]->term_id, $key, true)); }
                }
            } else {
                if ($id === 'current') {
                    $current_post_id = get_the_ID();
                    if ($current_post_id) {
                        if ($key === 'wp_title') $val = get_the_title($current_post_id);
                        elseif ($key === 'wp_content') {
                            $post_obj = get_post($current_post_id);
                            $val = $post_obj ? apply_filters('the_content', $post_obj->post_content) : '';
                        }
                        else $val = get_post_meta($current_post_id, $key, true);
                    }
                } else {
                    $posts = get_posts(['post_type' => 'any', 'meta_key' => '_ws_import_id', 'meta_value' => $id, 'posts_per_page' => 1, 'post_status' => 'any']);
                    if (!empty($posts)) { $val = $key === 'wp_title' ? get_the_title($posts[0]->ID) : ($key === 'wp_content' ? apply_filters('the_content', $posts[0]->post_content) : get_post_meta($posts[0]->ID, $key, true)); }
                }
            }

            if(empty($val) && $val !== '0' && $val !== 0) return "<span style='color:#ef4444; font-size:12px;'>[El campo '{$key}' está vacío o la plantilla dinámica no tiene datos]</span>";

            if (($this->props['ws_is_gallery'] ?? 'off') !== 'on') return sprintf('<span class="wpsheets-divi-wrapper">%s</span>', $val);

            $urls = array_filter(array_map('trim', explode(',', $val)), function($u){ return filter_var($u, FILTER_VALIDATE_URL); });
            if(empty($urls)) return "<span style='color:#ef4444; font-size:12px;'>[No hay URLs válidas]</span>";

            if (($this->props['ws_gal_random'] ?? 'off') === 'on') { shuffle($urls); }

            $uid          = uniqid('ws_gal_');
            $layout       = $this->props['ws_gallery_layout'] ?? 'metro';
            $bento_style  = $this->props['ws_gal_bento_style'] ?? '1';
            $bento_fill   = $this->props['ws_gal_bento_fill'] ?? 'both';
            $bento_row_h  = intval($this->props['ws_gal_bento_row_h'] ?? 200);
            $bento_rows   = intval($this->props['ws_gal_bento_rows'] ?? 0);
            $cols_d       = intval($this->props['ws_gal_cols_desktop'] ?? 4);
            $cols_t       = intval($this->props['ws_gal_cols_tablet'] ?? 2);
            $cols_m       = intval($this->props['ws_gal_cols_mobile'] ?? 1);
            $gap          = intval($this->props['ws_gal_gap'] ?? 15);
            $radius       = intval($this->props['ws_gal_radius'] ?? 8);
            $ratio        = $this->props['ws_gal_ratio'] ?? 'auto';
            $fit          = $this->props['ws_gal_fit'] ?? 'cover';
            $hover        = $this->props['ws_gal_hover'] ?? 'zoom';
            
            $slider_max_w = intval($this->props['ws_gal_slider_max_w'] ?? 0);

            // Lightbox Modal
            $lightbox     = $this->props['ws_gal_lightbox'] ?? 'on';
            $modal_bg     = $this->props['ws_gal_modal_bg'] ?? 'rgba(0,0,0,0.95)';
            $modal_text   = $this->props['ws_gal_modal_text'] ?? 'none';
            $modal_arr_mob= $this->props['ws_gal_modal_arr_mob'] ?? 'on';

            $pag_type     = $layout === 'slider' ? 'none' : ($this->props['ws_gal_pagination'] ?? 'none');
            $pag_pos      = $this->props['ws_gal_pag_pos'] ?? 'bottom';
            $pag_align    = $this->props['ws_gal_pag_align'] ?? 'center';
            $per_page     = intval($this->props['ws_gal_per_page'] ?? 6);
            $pag_size     = intval($this->props['ws_gal_pag_size'] ?? 16);
            $pag_pad      = intval($this->props['ws_gal_pag_pad'] ?? 12);
            $pag_rad      = intval($this->props['ws_gal_pag_rad'] ?? 50);
            $btn_text     = $this->props['ws_gal_btn_text'] ?? 'Cargar Más Imágenes';
            $btn_bg       = $this->props['ws_gal_btn_bg'] ?? '#2563EB';
            $btn_col      = $this->props['ws_gal_btn_color'] ?? '#ffffff';

            $s_x = $this->props['ws_gal_shadow_x'] ?? '0'; $s_y = $this->props['ws_gal_shadow_y'] ?? '10'; $s_b = $this->props['ws_gal_shadow_blur'] ?? '20'; $s_s = $this->props['ws_gal_shadow_spread'] ?? '0'; $s_c = $this->props['ws_gal_shadow_color'] ?? 'rgba(0,0,0,0.3)';
            $overlay   = $this->props['ws_gal_overlay'] ?? 'off'; $over_c    = $this->props['ws_gal_overlay_color'] ?? 'rgba(0,0,0,0.4)'; $over_icon = $this->props['ws_gal_overlay_icon'] ?? 'on';
            $center   = $this->props['ws_gal_slider_center'] ?? 'off'; $arrows   = $this->props['ws_gal_arrows'] ?? 'on'; $arr_pos  = $this->props['ws_gal_arrow_pos'] ?? 'outside'; $arr_bg   = $this->props['ws_gal_arrow_bg'] ?? '#ffffff'; $arr_col  = $this->props['ws_gal_arrow_color'] ?? '#000000'; $dots     = $this->props['ws_gal_dots'] ?? 'on'; $dot_act  = $this->props['ws_gal_dot_active'] ?? '#2563EB';

            // PREPARAR DATOS DE IMÁGENES
            $img_data = [];
            foreach($urls as $u) {
                $safe_u = esc_url($u);
                $display_text = '';
                
                if ($modal_text !== 'none') {
                    $attachment_id = attachment_url_to_postid($safe_u);
                    if ($modal_text === 'filename') {
                        $display_text = ucfirst(pathinfo(parse_url($safe_u, PHP_URL_PATH), PATHINFO_FILENAME));
                        $display_text = str_replace(['-', '_'], ' ', $display_text);
                    } elseif ($modal_text === 'alt' && $attachment_id) {
                        $display_text = get_post_meta($attachment_id, '_wp_attachment_image_alt', true);
                    } elseif ($modal_text === 'caption' && $attachment_id) {
                        $display_text = wp_get_attachment_caption($attachment_id);
                    }
                    
                    if (empty($display_text)) {
                        $display_text = ucfirst(pathinfo(parse_url($safe_u, PHP_URL_PATH), PATHINFO_FILENAME));
                        $display_text = str_replace(['-', '_'], ' ', $display_text);
                    }
                }
                $img_data[] = ['src' => $safe_u, 'txt' => esc_attr($display_text)];
            }

            // CSS Core
            $css = "
            #{$uid}-wrap { position: relative; width: 100%; max-width: 100%; }
            #{$uid} { box-sizing: border-box; margin: 0; padding: 0; list-style: none; transition: height 0.3s ease; }
            #{$uid} .ws-item-wrap { display: block; overflow: hidden; border-radius: {$radius}px; position: relative; cursor: pointer; transition: all 0.4s ease; background: #f3f4f6; }
            #{$uid} img.ws-img-item { width: 100%; height: 100%; object-fit: {$fit}; transition: transform 0.5s ease, filter 0.4s ease; display: block; }
            #{$uid} .ws-item-hidden { display: none !important; }
            ";
            
            if ($ratio !== 'auto') { $aspect = str_replace('/', ' / ', $ratio); $css .= "#{$uid} img.ws-img-item { aspect-ratio: {$aspect}; } "; }
            $css .= "#{$uid} .ws-item-wrap:hover { box-shadow: {$s_x}px {$s_y}px {$s_b}px {$s_s}px {$s_c}; transform: translateY(-4px); z-index: 2; }";

            if ($overlay === 'on') {
                $css .= "
                #{$uid} .ws-item-overlay { position: absolute; top:0; left:0; width:100%; height:100%; background: {$over_c}; opacity: 0; transition: opacity 0.3s; display: flex; align-items: center; justify-content: center; color: #fff; }
                #{$uid} .ws-item-wrap:hover .ws-item-overlay { opacity: 1; }
                #{$uid} .ws-item-overlay svg { width: 32px; height: 32px; stroke: #fff; transform: scale(0.5); transition: transform 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275); }
                #{$uid} .ws-item-wrap:hover .ws-item-overlay svg { transform: scale(1); }
                ";
            }

            if ($hover === 'bw') { $css .= "#{$uid} img.ws-img-item { filter: grayscale(100%); } #{$uid} .ws-item-wrap:hover img.ws-img-item { filter: grayscale(0%); }"; }
            elseif ($hover === 'zoom') { $css .= "#{$uid} .ws-item-wrap:hover img.ws-img-item { transform: scale(1.1); }"; }
            elseif ($hover === 'blur') { $css .= "#{$uid} img.ws-img-item { filter: blur(3px); opacity: 0.8; } #{$uid} .ws-item-wrap:hover img.ws-img-item { filter: blur(0px); opacity: 1; transform: scale(1.05); }"; }
            elseif ($hover === 'sepia') { $css .= "#{$uid} img.ws-img-item { filter: sepia(80%); } #{$uid} .ws-item-wrap:hover img.ws-img-item { filter: sepia(0%); }"; }
            elseif ($hover === 'rotate') { $css .= "#{$uid} .ws-item-wrap:hover img.ws-img-item { transform: scale(1.1) rotate(2deg); }"; }

            // CSS PAGINACIÓN CUSTOMIZADA MILIMETRICA
            if ($pag_type !== 'none') {
                $css .= "
                #{$uid}-pagination-wrap { display: flex; justify-content: {$pag_align}; gap: 8px; flex-wrap: wrap; margin: 20px 0; }
                .ws-load-more-btn { background: {$btn_bg}; color: {$btn_col}; border: none; padding: {$pag_pad}px calc({$pag_pad}px * 2); font-size: {$pag_size}px; font-weight: bold; border-radius: {$pag_rad}px; cursor: pointer; transition: transform 0.2s, opacity 0.2s; box-shadow: 0 4px 10px rgba(0,0,0,0.15); line-height: 1; }
                .ws-load-more-btn:hover { transform: translateY(-2px); opacity: 0.9; }
                .ws-page-num { min-width: calc({$pag_size}px + ({$pag_pad}px * 2)); height: calc({$pag_size}px + ({$pag_pad}px * 2)); display: flex; align-items: center; justify-content: center; border-radius: {$pag_rad}px; background: #e2e8f0; color: #475569; cursor: pointer; font-size: {$pag_size}px; font-weight: bold; transition: 0.2s; user-select: none; padding: 0 {$pag_pad}px; box-sizing: border-box; }
                .ws-page-num:hover { background: #cbd5e1; }
                .ws-page-num.ws-active { background: {$btn_bg}; color: {$btn_col}; box-shadow: 0 4px 8px rgba(0,0,0,0.15); transform: scale(1.1); }
                .ws-infinite-loader { width: 40px; height: 40px; border: 4px solid #f3f3f3; border-top: 4px solid {$btn_bg}; border-radius: 50%; animation: ws-spin 1s linear infinite; margin: 20px auto; display: none; }
                @keyframes ws-spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
                ";
            }

            // Layout CSS
            if ($layout === 'masonry') {
                $css .= "
                #{$uid} { column-count: {$cols_d}; column-gap: {$gap}px; }
                #{$uid} .ws-item-wrap { width: 100%; display: inline-block; margin-bottom: {$gap}px; }
                @media(max-width: 980px) { #{$uid} { column-count: {$cols_t}; } }
                @media(max-width: 767px) { #{$uid} { column-count: {$cols_m}; } }";
            } elseif ($layout === 'grid') {
                $css .= "
                #{$uid} { display: grid; gap: {$gap}px; grid-template-columns: repeat({$cols_d}, 1fr); }
                @media(max-width: 980px) { #{$uid} { grid-template-columns: repeat({$cols_t}, 1fr); } }
                @media(max-width: 767px) { #{$uid} { grid-template-columns: repeat({$cols_m}, 1fr); } }";
            } elseif ($layout === 'metro') {
                $css .= "
                #{$uid} { display: grid; gap: {$gap}px; grid-template-columns: repeat({$cols_d}, 1fr); grid-auto-flow: dense; ";
                if ($bento_rows > 0) { $css .= "grid-template-rows: repeat({$bento_rows}, {$bento_row_h}px); overflow: hidden; }"; } 
                else { $css .= "grid-auto-rows: {$bento_row_h}px; }"; }

                $css .= "
                #{$uid} .ws-item-wrap { 
                    --c-span: 1; --r-span: 1; 
                    --dynamic-c-span: var(--c-span);
                    --dynamic-r-span: var(--r-span);
                    grid-column: span min(var(--dynamic-c-span), {$cols_d}); 
                    grid-row: span var(--dynamic-r-span); 
                }";

                if($bento_style === '1') $css .= "#{$uid} .ws-item-wrap:nth-child(5n+1) { --c-span: 2; --r-span: 2; }";
                if($bento_style === '2') $css .= "#{$uid} .ws-item-wrap:nth-child(4n+2) { --c-span: 2; --r-span: 2; }";
                if($bento_style === '3') $css .= "#{$uid} .ws-item-wrap:nth-child(3n+1) { --c-span: 2; }";
                if($bento_style === '4') $css .= "#{$uid} .ws-item-wrap:nth-child(6n+1), #{$uid} .ws-item-wrap:nth-child(6n+5) { --c-span: 2; --r-span: 2; }";
                if($bento_style === '5') $css .= "#{$uid} .ws-item-wrap:nth-child(even) { --c-span: 2; }";
                if($bento_style === '6') $css .= "#{$uid} .ws-item-wrap:nth-child(odd) { --r-span: 2; }";
                if($bento_style === '7') $css .= "#{$uid} .ws-item-wrap:first-child { --c-span: 3; --r-span: 2; }";
                if($bento_style === '8') $css .= "#{$uid} .ws-item-wrap:nth-child(7n+1) { --c-span: 2; --r-span: 2; } #{$uid} .ws-item-wrap:nth-child(7n+4) { --c-span: 2; }";
                if($bento_style === '9') $css .= "#{$uid} .ws-item-wrap:nth-child(3n+2) { --c-span: 2; --r-span: 2; }";
                if($bento_style === '10') $css .= "#{$uid} .ws-item-wrap:nth-child(4n+1) { --r-span: 2; } #{$uid} .ws-item-wrap:nth-child(4n+4) { --c-span: 2; }";
                
                $css .= "
                @media(max-width: 980px) { 
                    #{$uid} { grid-template-columns: repeat({$cols_t}, 1fr); } 
                    #{$uid} .ws-item-wrap { grid-column: span min(var(--dynamic-c-span), {$cols_t}) !important; } 
                }
                @media(max-width: 767px) { 
                    #{$uid} { grid-template-columns: repeat({$cols_m}, 1fr); grid-auto-rows: auto; } 
                    #{$uid} .ws-item-wrap { grid-column: span min(var(--dynamic-c-span), {$cols_m}) !important; grid-row: span 1 !important; } 
                }";

            } elseif ($layout === 'slider') {
                $css .= "
                #{$uid} { overflow: hidden; padding: 20px 0; width: 100%; position: relative; box-sizing: border-box; }
                #{$uid} .ws-slider-track { display: flex; flex-wrap: nowrap; gap: {$gap}px; align-items: center; width: 100%; margin: 0; padding: 0; }
                #{$uid} .ws-item-wrap { flex: 0 0 calc((100% - ({$cols_d} - 1) * {$gap}px) / {$cols_d}); width: calc((100% - ({$cols_d} - 1) * {$gap}px) / {$cols_d}); margin: 0 auto; }
                ";

                if ($slider_max_w > 0) { $css .= "#{$uid} .ws-item-wrap { max-width: {$slider_max_w}px !important; }"; }

                if ($center === 'on') {
                    $css .= "
                    #{$uid} .ws-item-wrap { opacity: 0.4; transform: scale(0.85); box-shadow: none !important; transition: opacity 0.5s ease, transform 0.5s ease; }
                    #{$uid} .ws-item-wrap.ws-slide-center { opacity: 1; transform: scale(1); box-shadow: 0 10px 30px rgba(0,0,0,0.15) !important; z-index: 3; }
                    ";
                }
                $css .= "
                @media(max-width: 980px) { #{$uid} .ws-item-wrap { flex: 0 0 calc((100% - ({$cols_t} - 1) * {$gap}px) / {$cols_t}); width: calc((100% - ({$cols_t} - 1) * {$gap}px) / {$cols_t}); } }
                @media(max-width: 767px) { #{$uid} .ws-item-wrap { flex: 0 0 calc((100% - ({$cols_m} - 1) * {$gap}px) / {$cols_m}); width: calc((100% - ({$cols_m} - 1) * {$gap}px) / {$cols_m}); } }
                .ws-slider-nav-wrap { position: absolute; z-index: 5; display: flex; gap: 10px; pointer-events: none; width: 100%; top: 50%; transform: translateY(-50%); }
                .ws-slider-nav { pointer-events: auto; width: 44px; height: 44px; border-radius: 50%; border: none; cursor: pointer; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 12px rgba(0,0,0,0.15); transition: transform 0.2s; padding: 0; }
                .ws-slider-nav svg { width: 20px; height: 20px; stroke: {$arr_col}; fill: none; }
                .ws-slider-nav:hover { transform: scale(1.1); }
                ";
                if($arr_pos === 'inside') { $css .= ".ws-slider-nav-wrap { padding: 0 15px; justify-content: space-between; left: 0; box-sizing: border-box; }"; } 
                elseif($arr_pos === 'outside') { $css .= ".ws-slider-nav-wrap { justify-content: space-between; left: -22px; width: calc(100% + 44px); }"; }
                $css .= "
                .ws-slider-dots { display: flex; justify-content: center; gap: 8px; margin-top: 15px; }
                .ws-slider-dot { width: 10px; height: 10px; border-radius: 50%; background: #CBD5E1; cursor: pointer; transition: 0.3s; }
                .ws-slider-dot.ws-dot-active { background: {$dot_act}; transform: scale(1.3); }
                ";
            }

            // CSS LIGHTBOX MODAL
            if ($lightbox === 'on') {
                $css .= "
                .ws-modal-overlay { position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background: {$modal_bg}; z-index: 2147483647 !important; display: flex; align-items: center; justify-content: center; opacity: 0; pointer-events: none; transition: opacity 0.3s ease; }
                .ws-modal-overlay.ws-show { opacity: 1; pointer-events: auto; }
                .ws-modal-content { max-width: 90%; max-height: 85vh; text-align: center; position: relative; display: flex; flex-direction: column; align-items: center; justify-content: center; }
                .ws-modal-content img { max-width: 100%; max-height: 80vh; border-radius: 8px; box-shadow: 0 10px 40px rgba(0,0,0,0.5); display: none; object-fit: contain; user-select: none; }
                .ws-modal-content img.ws-show { display: block; animation: wsFadeIn 0.3s ease-out; }
                .ws-modal-caption { color: #ffffff; font-size: 16px; margin-top: 12px; font-weight: 500; min-height: 24px; text-shadow: 0 2px 4px rgba(0,0,0,0.5); }
                .ws-modal-close { position: absolute; top: 20px; right: 30px; color: #fff; font-size: 45px; cursor: pointer; z-index: 10; font-family: sans-serif; line-height: 1; transition: transform 0.2s; }
                .ws-modal-close:hover { transform: scale(1.2); }
                .ws-modal-nav { position: absolute; top: 50%; transform: translateY(-50%); color: #fff; font-size: 60px; cursor: pointer; padding: 20px; user-select: none; transition: transform 0.2s; z-index: 5; }
                .ws-modal-nav:hover { transform: translateY(-50%) scale(1.2); }
                .ws-modal-prev { left: 10px; } .ws-modal-next { right: 10px; }
                
                @media(max-width: 980px) {
                    .ws-modal-nav { font-size: 40px; padding: 10px; }
                    .ws-modal-prev { left: 0px; } .ws-modal-next { right: 0px; }
                    .ws-modal-close { top: 10px; right: 15px; font-size: 35px; }
                    .ws-modal-content { max-width: 95%; max-height: 90vh; }
                ";
                
                if ($modal_arr_mob === 'off') {
                    $css .= " .ws-modal-nav { display: none !important; } ";
                }
                
                $css .= "
                }
                @keyframes wsFadeIn { from { opacity: 0; transform: scale(0.95); } to { opacity: 1; transform: scale(1); } }
                ";
            }

            $html = "<style>{$css}</style>";
            $html .= "<div id=\"{$uid}-wrap\">";
            
            // Paginación TOP
            $pagination_html = "";
            if ($pag_type !== 'none' && count($img_data) > $per_page) {
                $pagination_html .= "<div id='{$uid}-pagination-wrap' class='ws-pagination-wrap'>";
                if ($pag_type === 'btn') {
                    $pagination_html .= "<button id='{$uid}-load-more' class='ws-load-more-btn'>{$btn_text}</button>";
                } elseif ($pag_type === 'numbers') {
                    $total_pages = ceil(count($img_data) / $per_page);
                    for($i = 1; $i <= $total_pages; $i++) {
                        $active = $i === 1 ? 'ws-active' : '';
                        $pagination_html .= "<div class='ws-page-num {$active}' data-page='{$i}'>{$i}</div>";
                    }
                } elseif ($pag_type === 'scroll') {
                    $pagination_html .= "<div id='{$uid}-infinite-loader' class='ws-infinite-loader'></div>";
                    $pagination_html .= "<div id='{$uid}-infinite-trigger' style='height: 1px; width: 100%;'></div>";
                }
                $pagination_html .= "</div>";
            }

            if ($pag_pos === 'top') { $html .= $pagination_html; }

            // GALERÍA
            $html .= "<div id=\"{$uid}\" class=\"ws-gallery-wrapper ws-layout-{$layout}\">";
            
            if ($layout === 'slider') { $html .= "<div class='ws-slider-track'>"; }

            foreach($img_data as $idx => $img) { 
                $hidden_class = ($pag_type !== 'none' && $idx >= $per_page) ? 'ws-item-hidden' : '';

                $html .= "<div class='ws-item-wrap {$hidden_class}' data-index='{$idx}'>";
                $html .= "<img src='{$img['src']}' class='ws-img-item' alt='Imagen' loading='lazy'>";
                if ($overlay === 'on') {
                    $html .= "<div class='ws-item-overlay'>";
                    if($over_icon === 'on') $html .= '<svg viewBox="0 0 24 24" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>';
                    $html .= "</div>";
                }
                $html .= "</div>";
            }

            if ($layout === 'slider') { $html .= "</div>"; }
            $html .= "</div>";

            // Paginación BOTTOM
            if ($pag_pos === 'bottom') { $html .= $pagination_html; }

            // JS BENTO DEBOUNCED Y RAYCAST
            if ($layout !== 'slider') {
                $html .= "
                <script>
                document.addEventListener('DOMContentLoaded', function() {
                    const grid = document.getElementById('{$uid}');
                    if (!grid) return;
                    
                    const items = Array.from(grid.querySelectorAll('.ws-item-wrap'));
                    let visibleCount = {$per_page};
                    const pagType = '{$pag_type}';
                    const fillMode = '{$bento_fill}';
                    const gap = {$gap};
                    
                    function applySmartBento() {
                        if ('{$layout}' !== 'metro' || fillMode === 'off') return;
                        
                        items.forEach(i => { i.style.removeProperty('--dynamic-c-span'); i.style.removeProperty('--dynamic-r-span'); });
                        grid.style.gridAutoFlow = 'dense';
                        
                        setTimeout(() => {
                            const gridRect = grid.getBoundingClientRect();
                            const visibleItems = items.filter(i => !i.classList.contains('ws-item-hidden'));
                            if(visibleItems.length === 0) return;

                            let currentCols = {$cols_d};
                            if(window.innerWidth <= 767) currentCols = {$cols_m};
                            else if(window.innerWidth <= 980) currentCols = {$cols_t};
                            
                            if (currentCols <= 1) return;

                            let gapOffset = gap + 5; 

                            if (['hor', 'both'].includes(fillMode)) {
                                visibleItems.forEach(item => {
                                    let rect = item.getBoundingClientRect();
                                    if (Math.round(rect.right) < Math.round(gridRect.right) - gapOffset) {
                                        let elRight = document.elementFromPoint(rect.right + gapOffset, rect.top + gapOffset);
                                        let siblingR = elRight ? elRight.closest('.ws-item-wrap') : null;
                                        
                                        if (!siblingR || siblingR === item) {
                                            let cSpan = parseInt(window.getComputedStyle(item).getPropertyValue('--c-span')) || 1;
                                            while(cSpan < currentCols) {
                                                cSpan++; 
                                                item.style.setProperty('--dynamic-c-span', cSpan);
                                                if(Math.round(item.getBoundingClientRect().right) >= Math.round(gridRect.right) - gapOffset) break;
                                            }
                                        }
                                    }
                                });
                            }

                            setTimeout(() => {
                                if (['ver', 'both'].includes(fillMode)) {
                                    let maxBottom = 0;
                                    visibleItems.forEach(i => maxBottom = Math.max(maxBottom, i.getBoundingClientRect().bottom));

                                    visibleItems.forEach(item => {
                                        let rect = item.getBoundingClientRect(); 
                                        if (Math.round(rect.bottom) < Math.round(maxBottom) - gapOffset) {
                                            let elBelow = document.elementFromPoint(rect.left + gapOffset, rect.bottom + gapOffset);
                                            let siblingB = elBelow ? elBelow.closest('.ws-item-wrap') : null;
                                            
                                            if (!siblingB || siblingB === item) {
                                                let rSpan = parseInt(window.getComputedStyle(item).getPropertyValue('--r-span')) || 1;
                                                while(rSpan < 10) {
                                                    rSpan++; 
                                                    item.style.setProperty('--dynamic-r-span', rSpan);
                                                    if(Math.round(item.getBoundingClientRect().bottom) >= Math.round(maxBottom) - gapOffset) break;
                                                }
                                            }
                                        }
                                    });
                                }
                            }, 50);
                        }, 50);
                    }

                    function revealMoreItems() {
                        visibleCount += {$per_page};
                        items.forEach((item, index) => {
                            if (index < visibleCount) item.classList.remove('ws-item-hidden');
                        });
                        
                        if (visibleCount >= items.length) {
                            let wrap = document.getElementById('{$uid}-pagination-wrap');
                            if(wrap) wrap.style.display = 'none';
                        }
                        applySmartBento();
                    }

                    function showPage(pageNum) {
                        let startIndex = (pageNum - 1) * {$per_page};
                        let endIndex = startIndex + {$per_page};
                        
                        items.forEach((item, index) => {
                            if (index >= startIndex && index < endIndex) item.classList.remove('ws-item-hidden');
                            else item.classList.add('ws-item-hidden');
                        });
                        applySmartBento();
                    }

                    if (pagType === 'btn') {
                        let btn = document.getElementById('{$uid}-load-more');
                        if(btn) btn.addEventListener('click', revealMoreItems);
                    } else if (pagType === 'numbers') {
                        let pageBtns = document.querySelectorAll('#{$uid}-pagination-wrap .ws-page-num');
                        pageBtns.forEach(btn => {
                            btn.addEventListener('click', function() {
                                pageBtns.forEach(b => b.classList.remove('ws-active'));
                                this.classList.add('ws-active');
                                showPage(parseInt(this.dataset.page));
                                grid.scrollIntoView({behavior: 'smooth', block: 'start'});
                            });
                        });
                    } else if (pagType === 'scroll') {
                        let trigger = document.getElementById('{$uid}-infinite-trigger');
                        let loader = document.getElementById('{$uid}-infinite-loader');
                        if (trigger) {
                            if(loader) loader.style.display = 'block';
                            let observer = new IntersectionObserver((entries) => {
                                if(entries[0].isIntersecting && visibleCount < items.length) revealMoreItems();
                            }, { rootMargin: '200px' });
                            observer.observe(trigger);
                        }
                    }

                    let bentoResizeTimer;
                    let bentoLastWidth = window.innerWidth;
                    window.addEventListener('resize', () => {
                        if (window.innerWidth !== bentoLastWidth) {
                            bentoLastWidth = window.innerWidth;
                            clearTimeout(bentoResizeTimer);
                            bentoResizeTimer = setTimeout(applySmartBento, 250);
                        }
                    });

                    applySmartBento();
                });
                </script>";
            }

            // SLIDER JS
            if ($layout === 'slider') {
                $svg_l = '<svg viewBox="0 0 24 24"><polyline points="15 18 9 12 15 6"></polyline></svg>';
                $svg_r = '<svg viewBox="0 0 24 24"><polyline points="9 18 15 12 9 6"></polyline></svg>';
                
                if ($arrows === 'on') {
                    $html .= "<div class='ws-slider-nav-wrap'><button class='ws-slider-nav ws-slider-prev' style='background:{$arr_bg};'>{$svg_l}</button><button class='ws-slider-nav ws-slider-next' style='background:{$arr_bg};'>{$svg_r}</button></div>";
                }
                if ($dots === 'on') {
                    $html .= "<div id=\"{$uid}-dots\" class='ws-slider-dots'></div>";
                }

                $loop_js = ($this->props['ws_gal_slider_loop'] ?? 'on') === 'on' ? 'true' : 'false';
                $auto_js = ($this->props['ws_gal_autoplay'] ?? 'off') === 'on' ? 'true' : 'false';
                $center_js = $center === 'on' ? 'true' : 'false';
                $delay = intval($this->props['ws_gal_auto_delay'] ?? 3000);

                $html .= "
                <script>
                document.addEventListener('DOMContentLoaded', function() {
                    const wrap = document.getElementById('{$uid}-wrap');
                    const slider = document.getElementById('{$uid}');
                    const track = slider.querySelector('.ws-slider-track');
                    const dotsWrap = document.getElementById('{$uid}-dots');
                    const prevBtn = wrap.querySelector('.ws-slider-prev');
                    const nextBtn = wrap.querySelector('.ws-slider-next');
                    
                    let isLoop = {$loop_js}; let isAuto = {$auto_js}; let isCenter = {$center_js};
                    let delay = {$delay}; let timer = null; let isAnimating = false;
                    let totalItems = track.children.length;

                    if(totalItems <= 1) return;

                    if(isLoop) {
                        let lastClone1 = track.lastElementChild.cloneNode(true);
                        let lastClone2 = track.children[totalItems - 2] ? track.children[totalItems - 2].cloneNode(true) : null;
                        lastClone1.classList.add('ws-cloned-item');
                        if(lastClone2) lastClone2.classList.add('ws-cloned-item');
                        track.prepend(lastClone1);
                        if(lastClone2) track.prepend(lastClone2);
                    }

                    const originalItems = Array.from(track.children).filter(el => !el.classList.contains('ws-cloned-item'));
                    if (dotsWrap) {
                        for(let i = 0; i < originalItems.length; i++) {
                            let d = document.createElement('div'); d.className = 'ws-slider-dot'; d.dataset.dotIndex = originalItems[i].dataset.index;
                            d.addEventListener('click', () => jumpToDot(originalItems[i].dataset.index)); dotsWrap.appendChild(d);
                        }
                    }

                    function getItemWidth() { return originalItems[0].offsetWidth + {$gap}; }
                    
                    function getCenterOffset() { 
                        return isCenter ? (slider.offsetWidth - originalItems[0].offsetWidth) / 2 : 0; 
                    }

                    let clonedCount = isLoop ? (track.children.length - originalItems.length) : 0;

                    function updateUI() {
                        let visualCenterIdx = clonedCount; 
                        Array.from(track.children).forEach((item, i) => item.classList.toggle('ws-slide-center', i === visualCenterIdx));
                        
                        if (dotsWrap && track.children[visualCenterIdx]) {
                            let activeIdx = track.children[visualCenterIdx].dataset.index;
                            Array.from(dotsWrap.children).forEach(d => d.classList.toggle('ws-dot-active', d.dataset.dotIndex === activeIdx));
                        }
                    }

                    function resetTrackPos() {
                        track.style.transition = 'none';
                        let offset = getCenterOffset() - (clonedCount * getItemWidth());
                        track.style.transform = `translateX(\${offset}px)`;
                        isAnimating = false; updateUI();
                    }

                    function moveNext() {
                        if(isAnimating) return;
                        isAnimating = true;
                        let currentOffset = getCenterOffset() - (clonedCount * getItemWidth());
                        let targetOffset = currentOffset - getItemWidth();
                        
                        track.style.transition = 'transform 0.4s cubic-bezier(0.25, 1, 0.5, 1)';
                        track.style.transform = `translateX(\${targetOffset}px)`;
                        
                        setTimeout(() => { if(isLoop) track.appendChild(track.firstElementChild); resetTrackPos(); }, 400);
                    }

                    function movePrev() {
                        if(isAnimating) return;
                        isAnimating = true;
                        
                        if(isLoop) {
                            track.prepend(track.lastElementChild);
                            let startOffset = getCenterOffset() - ((clonedCount + 1) * getItemWidth());
                            track.style.transition = 'none'; track.style.transform = `translateX(\${startOffset}px)`; track.offsetHeight;
                        }
                        
                        let targetOffset = getCenterOffset() - (clonedCount * getItemWidth());
                        track.style.transition = 'transform 0.4s cubic-bezier(0.25, 1, 0.5, 1)';
                        track.style.transform = `translateX(\${targetOffset}px)`;
                        
                        setTimeout(() => { resetTrackPos(); }, 400);
                    }

                    function jumpToDot(dotIndex) { stopAuto(); moveNext(); startAuto(); }

                    if(nextBtn) nextBtn.addEventListener('click', () => { moveNext(); stopAuto(); startAuto(); });
                    if(prevBtn) prevBtn.addEventListener('click', () => { movePrev(); stopAuto(); startAuto(); });

                    function startAuto() { if(isAuto) { clearInterval(timer); timer = setInterval(moveNext, delay); } }
                    function stopAuto() { clearInterval(timer); }

                    resetTrackPos(); startAuto();
                    wrap.addEventListener('mouseenter', stopAuto); wrap.addEventListener('mouseleave', startAuto);
                    window.addEventListener('resize', resetTrackPos);
                });
                </script>";
            }

            // LIGHTBOX MODAL CON SWIPE
            if ($lightbox === 'on') {
                $js_array = json_encode($img_data);
                $html .= "
                <div id='{$uid}-modal' class='ws-modal-overlay' style='pointer-events: none;'>
                    <div class='ws-modal-close'>&times;</div>
                    <div class='ws-modal-nav ws-modal-prev'>&#10094;</div>
                    <div class='ws-modal-content'>
                        <div id='{$uid}-modal-caption' class='ws-modal-caption'></div>
                    </div>
                    <div class='ws-modal-nav ws-modal-next'>&#10095;</div>
                </div>
                <script>
                document.addEventListener('DOMContentLoaded', function() {
                    const imgData = {$js_array};
                    const modal = document.getElementById('{$uid}-modal');
                    const content = modal.querySelector('.ws-modal-content');
                    const captionBox = document.getElementById('{$uid}-modal-caption');
                    let currIdx = 0;
                    
                    let touchstartX = 0;
                    let touchendX = 0;

                    document.documentElement.appendChild(modal);

                    imgData.forEach((data, i) => {
                        let img = document.createElement('img');
                        img.src = data.src; img.dataset.idx = i;
                        content.insertBefore(img, captionBox);
                    });

                    function showImg(idx) {
                        currIdx = idx;
                        if(currIdx < 0) currIdx = imgData.length - 1;
                        if(currIdx >= imgData.length) currIdx = 0;
                        
                        Array.from(content.querySelectorAll('img')).forEach(img => img.classList.remove('ws-show'));
                        content.querySelectorAll('img')[currIdx].classList.add('ws-show');
                        
                        if(imgData[currIdx].txt !== '') {
                            captionBox.innerText = imgData[currIdx].txt;
                        } else {
                            captionBox.innerText = '';
                        }
                    }

                    document.addEventListener('click', function(e) {
                        let item = e.target.closest('#{$uid} .ws-item-wrap');
                        if (item) {
                            e.preventDefault();
                            showImg(parseInt(item.dataset.index));
                            modal.classList.add('ws-show');
                            modal.style.pointerEvents = 'auto';
                        }
                    });

                    modal.querySelector('.ws-modal-close').addEventListener('click', () => { modal.classList.remove('ws-show'); modal.style.pointerEvents = 'none'; });
                    modal.querySelector('.ws-modal-next').addEventListener('click', (e) => { e.stopPropagation(); showImg(currIdx + 1); });
                    modal.querySelector('.ws-modal-prev').addEventListener('click', (e) => { e.stopPropagation(); showImg(currIdx - 1); });
                    
                    modal.addEventListener('click', (e) => { 
                        if(e.target === modal) { modal.classList.remove('ws-show'); modal.style.pointerEvents = 'none'; } 
                    });

                    modal.addEventListener('touchstart', e => {
                        touchstartX = e.changedTouches[0].screenX;
                    });

                    modal.addEventListener('touchend', e => {
                        touchendX = e.changedTouches[0].screenX;
                        if (touchendX < touchstartX - 50) showImg(currIdx + 1); 
                        if (touchendX > touchstartX + 50) showImg(currIdx - 1); 
                    });
                });
                </script>";
            }

            $html .= "</div>";
            return $html;
        }
    }

    new WPSheets_Divi_Module();
}