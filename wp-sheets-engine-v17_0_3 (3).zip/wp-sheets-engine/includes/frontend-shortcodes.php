<?php
if (!defined('ABSPATH')) exit;

/**
 * WP Sheets Engine - Shortcodes
 * Permite mostrar campos dinámicos y taxonomías usando [ws_data]
 */
add_shortcode('ws_data', 'wpsheets_render_shortcode');
function wpsheets_render_shortcode($atts) {
    global $post;

    $atts = shortcode_atts([
        'key'     => '', // Para campos personalizados (meta) o nativos
        'tax'     => '', // Para sacar las taxonomías asociadas a un post
        'id'      => '', // ID del registro en Google Sheets (columna id)
        'term_id' => ''  // ID de la taxonomía en Google Sheets (columna id)
    ], $atts);

    // --- CASO 1: Consultar una Categoría (Taxonomía) por su ID de Google Sheets ---
    if (!empty($atts['term_id'])) {
        $sheet_term_id = sanitize_text_field($atts['term_id']);

        // Buscar en la BD cuál término tiene ese _ws_import_id
        $terms = get_terms([
            'hide_empty' => false,
            'meta_query' => [
                [
                    'key' => '_ws_import_id',
                    'value' => $sheet_term_id
                ]
            ],
            'number' => 1
        ]);

        if (!empty($terms) && !is_wp_error($terms)) {
            $term = $terms[0];
            $term_db_id = $term->term_id;

            if ($atts['key'] === 'tax_name')  return $term->name;
            if ($atts['key'] === 'tax_slug')  return $term->slug;
            if ($atts['key'] === 'tax_desc')  return $term->description;
            if ($atts['key'] === 'tax_count') return (string)$term->count;
            if (!empty($atts['key'])) return get_term_meta($term_db_id, sanitize_text_field($atts['key']), true);
        }
        return '';
    }

    // --- CASO 2: Consultar un Post (Platillo) por su ID de Google Sheets ---
    $post_id = 0;

    if (!empty($atts['id'])) {
        $sheet_post_id = sanitize_text_field($atts['id']);

        // Buscar en la BD cuál post tiene ese _ws_import_id
        $posts = get_posts([
            'post_type' => 'any',
            'meta_key' => '_ws_import_id',
            'meta_value' => $sheet_post_id,
            'posts_per_page' => 1,
            'post_status' => 'any'
        ]);

        if (!empty($posts)) {
            $post_id = $posts[0]->ID;
        } else {
            return ''; // No se encontró el registro
        }
    } else {
        $post_id = isset($post->ID) ? $post->ID : 0;
    }

    if (!$post_id) return '';

    // Si se pide qué categorías tiene asignadas este post
    if (!empty($atts['tax'])) {
        $terms = wp_get_post_terms($post_id, sanitize_text_field($atts['tax']), ['fields' => 'names']);
        return (!is_wp_error($terms) && !empty($terms)) ? implode(', ', $terms) : '';
    }

    // Si se pide un campo nativo del post
    if ($atts['key'] === 'wp_title')    return get_the_title($post_id);
    if ($atts['key'] === 'wp_slug')     { $p = get_post($post_id); return $p ? $p->post_name : ''; }
    if ($atts['key'] === 'wp_excerpt')  { $p = get_post($post_id); return $p ? apply_filters('the_excerpt', $p->post_excerpt) : ''; }
    if ($atts['key'] === 'wp_status')   { $p = get_post($post_id); return $p ? $p->post_status : ''; }
    if ($atts['key'] === 'wp_content')  { $p = get_post($post_id); return $p ? apply_filters('the_content', $p->post_content) : ''; }
    if ($atts['key'] === 'wp_thumbnail') return get_the_post_thumbnail_url($post_id, 'full') ?: '';

    // Si se pide un campo personalizado del post (ej: precio, url_img_platillo)
    if (!empty($atts['key'])) {
        $val = get_post_meta($post_id, sanitize_text_field($atts['key']), true);
        return $val;
    }

    return '';
}




// --- NUEVO SHORTCODE PARA CONDICIONES CSS INTELIGENTES (CLASE GENERAL) ---
// ============================================================
// SHORTCODE [ws_condicion]
// Oculta el bloque contenedor si view_display (o el campo indicado)
// tiene un valor de FALSE / FALSO / 0 / vacío.
//
// Uso básico (usa view_display automáticamente):
//   [ws_condicion id="PROD-123"]
//   [ws_condicion term_id="TIPO_ALIM-6"]
//
// Uso avanzado (campo personalizado):
//   [ws_condicion id="MENU-47" key="destacado" expected="TRUE"]
//
// El shortcode va DENTRO del bloque/fila/columna de Divi (o donde quieras).
// El contenedor que quieras ocultar debe tener la clase CSS: ws-ocultar
// (configurable con el atributo 'clase')
// ============================================================
add_shortcode('ws_condicion', 'wpsheets_render_condicion');
function wpsheets_render_condicion($atts) {
    $atts = shortcode_atts([
        'id'       => '',
        'term_id'  => '',
        'key'      => 'view_display', // Por defecto siempre usa view_display
        'expected' => 'TRUE',
        'clase'    => 'ws-ocultar',
    ], $atts);

    // Obtener el valor del campo
    $val = '';
    if (!empty($atts['term_id'])) {
        $terms = get_terms([
            'hide_empty' => false,
            'meta_query' => [['key' => '_ws_import_id', 'value' => sanitize_text_field($atts['term_id'])]],
            'number' => 1,
        ]);
        if (!empty($terms) && !is_wp_error($terms)) {
            $val = get_term_meta($terms[0]->term_id, sanitize_text_field($atts['key']), true);
        }
    } elseif (!empty($atts['id'])) {
        $posts = get_posts([
            'post_type' => 'any', 'meta_key' => '_ws_import_id',
            'meta_value' => sanitize_text_field($atts['id']),
            'posts_per_page' => 1, 'post_status' => 'any',
        ]);
        if (!empty($posts)) {
            $val = get_post_meta($posts[0]->ID, sanitize_text_field($atts['key']), true);
        }
    }

    // Valores que se consideran "visible / mostrar"
    $show_values = ['TRUE', 'VERDADERO', 'TRUE', '1', 'YES', 'SÍ', 'SI'];
    $val_upper   = strtoupper(trim((string)$val));
    $exp_upper   = strtoupper(trim((string)$atts['expected']));

    // Si el expected es TRUE (caso view_display), verificar contra show_values
    $should_show = in_array($val_upper, $show_values) || $val_upper === $exp_upper;

    // Si el campo está vacío, mostrar por defecto
    if ($val_upper === '') $should_show = true;

    if (!$should_show) {
        $uid          = 'ws_' . substr(md5(uniqid('', true)), 0, 8);
        $clase_target = sanitize_html_class($atts['clase']);
        ob_start(); ?>
        <span id="<?php echo $uid; ?>" style="display:none;"></span>
        <style>
            .<?php echo $clase_target; ?>:has(#<?php echo $uid; ?>) { display: none !important; }
        </style>
        <script>
        (function() {
            function wsHide() {
                var el = document.getElementById('<?php echo $uid; ?>');
                if (!el) return;
                var c = el.closest('.<?php echo $clase_target; ?>');
                if (c) c.style.setProperty('display', 'none', 'important');
            }
            if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', wsHide);
            else wsHide();
        })();
        </script>
        <?php
        return ob_get_clean();
    }

    return '';
}


// ============================================================
// VISIBILIDAD AUTOMÁTICA — view_display
// Cuando view_display = FALSE en Google Sheets, el registro
// se excluye automáticamente de las consultas del frontend.
// No requiere shortcodes ni clases CSS.
// Solo aplica en el frontend (no en el admin de WordPress).
// ============================================================
add_action('init', function() {
    if (is_admin()) return;

    // ── Posts: excluir donde view_display = FALSE ─────────────
    add_action('pre_get_posts', function($query) {
        // Solo queries del frontend que no sean el admin
        if (is_admin() || !$query->is_main_query()) return;

        // Obtener los post_types que tienen view_display mapeado
        $mapping_all   = get_option('wpsheets_fields_mapping', []) ?: [];
        $native_sheets = get_option('wpsheets_native_cpts', []) ?: [];
        $cpts          = get_option('wpsheets_cpts', []) ?: [];

        // Construir lista de post_types activos en el plugin
        $active_types = [];
        foreach ($cpts as $cpt) { if (!empty($cpt['slug'])) $active_types[] = $cpt['slug']; }
        if (!empty($native_sheets['post']))  $active_types[] = 'post';
        if (!empty($native_sheets['page']))  $active_types[] = 'page';
        // CPT de proyectos
        $project_slugs = ['jetpack-portfolio','jetpack_portfolio','portfolio','project',
                          'projects','avada_portfolio','portfolio_page','work','case_study'];
        foreach ($project_slugs as $ps) {
            if (!empty($native_sheets[$ps])) { $active_types[] = $ps; break; }
        }
        if (class_exists('WooCommerce')) { $active_types[] = 'product'; }

        // Verificar si el post_type actual tiene view_display en su mapeo
        $queried_type = $query->get('post_type') ?: 'post';
        if (is_array($queried_type)) {
            $relevant = array_intersect($queried_type, $active_types);
        } else {
            $relevant = in_array($queried_type, $active_types) ? [$queried_type] : [];
        }
        if (empty($relevant)) return;

        // Añadir condición: excluir view_display = FALSE
        $mq = $query->get('meta_query') ?: [];
        $mq[] = [
            'relation' => 'OR',
            ['key' => 'view_display', 'compare' => 'NOT EXISTS'],
            ['key' => 'view_display', 'value' => ['FALSE', 'false', 'False', '0'], 'compare' => 'NOT IN'],
        ];
        $query->set('meta_query', $mq);
    });

    // ── Términos: excluir donde view_display = FALSE ──────────
    add_filter('get_terms_args', function($args, $taxonomies) {
        if (is_admin()) return $args;

        // Solo actuar en taxonomías conocidas del plugin
        $native_sheets = get_option('wpsheets_native_cpts', []) ?: [];
        $plugin_taxs   = array_column(get_option('wpsheets_taxonomies', []) ?: [], 'slug');
        $known_taxs    = $plugin_taxs;
        if (!empty($native_sheets['tax_category']))  $known_taxs[] = 'category';
        if (!empty($native_sheets['tax_post_tag']))  $known_taxs[] = 'post_tag';
        if (class_exists('WooCommerce')) {
            $known_taxs = array_merge($known_taxs, ['product_cat', 'product_tag']);
        }

        $relevant = array_intersect((array)$taxonomies, $known_taxs);
        if (empty($relevant)) return $args;

        $mq   = $args['meta_query'] ?? [];
        $mq[] = [
            'relation' => 'OR',
            ['key' => 'view_display', 'compare' => 'NOT EXISTS'],
            ['key' => 'view_display', 'value' => ['FALSE', 'false', 'False', '0'], 'compare' => 'NOT IN'],
        ];
        $args['meta_query'] = $mq;
        return $args;
    }, 10, 2);
});

