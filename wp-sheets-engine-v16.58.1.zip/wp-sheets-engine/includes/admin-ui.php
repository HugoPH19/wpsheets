<?php
if (!defined('ABSPATH')) exit;
add_action('admin_menu', function() {
    add_menu_page('Sheets Engine', 'Sheets Engine', 'manage_options', 'wpsheets-dashboard', 'wpsheets_page_dashboard', 'dashicons-grid-view', 30);
    add_submenu_page('wpsheets-dashboard', 'Dashboard', 'Dashboard', 'manage_options', 'wpsheets-dashboard', 'wpsheets_page_dashboard');
    add_submenu_page('wpsheets-dashboard', 'Conexión API', 'Conexión API', 'manage_options', 'wpsheets-api', 'wpsheets_page_api');
    add_submenu_page('wpsheets-dashboard', 'Configuración', '⚙️ Configuración', 'manage_options', 'wpsheets-settings', 'wpsheets_page_settings');
    add_submenu_page('wpsheets-dashboard', 'Post Types', 'Post Types', 'manage_options', 'wpsheets-cpts', 'wpsheets_page_cpts');
    add_submenu_page('wpsheets-dashboard', 'Taxonomías', 'Taxonomías', 'manage_options', 'wpsheets-tax', 'wpsheets_page_tax');
    add_submenu_page('wpsheets-dashboard', 'Campos Dinámicos', 'Campos Dinámicos', 'manage_options', 'wpsheets-fields', 'wpsheets_page_fields');
    add_submenu_page('wpsheets-dashboard', 'Data Grid Live', 'Data Grid (Live)', 'manage_options', 'wpsheets-datagrid', 'wpsheets_page_datagrid');
    add_submenu_page('wpsheets-dashboard', 'Sincronizar Datos', 'Sincronizar', 'manage_options', 'wpsheets-sync', 'wpsheets_page_sync');
    add_submenu_page('wpsheets-dashboard', 'Auto-Sync (Cron)', 'Auto-Sync', 'manage_options', 'wpsheets-auto-sync', 'wpsheets_page_auto_sync');
    if (class_exists('WooCommerce')) add_submenu_page('wpsheets-dashboard', 'WooCommerce', 'WooCommerce', 'manage_options', 'wpsheets-woo', 'wpsheets_page_woo');
});



add_action('admin_init', function() { register_setting('wpsheets_options', 'wpsheets_service_account_json'); register_setting('wpsheets_options', 'wpsheets_spreadsheet_id'); });
function wpsheets_page_api() {
    ?>
    <div class="wpsheets-wrap">
        <div class="wpsheets-header">
            <div class="wpsheets-header-title">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#2563EB" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="17 8 12 3 7 8"></polyline><line x1="12" y1="3" x2="12" y2="15"></line></svg>
                <div><h1>Conexión a Google Sheets</h1><div class="wpsheets-subtitle">Configura las credenciales de la API v4.</div></div>
            </div>
        </div>
        <form method="post" action="options.php" class="ws-card">
            <?php settings_fields('wpsheets_options'); ?>
            <div class="ws-form-group">
                <label class="ws-label">Credenciales Service Account (JSON)</label>
                <textarea name="wpsheets_service_account_json" rows="6" class="ws-textarea"><?php echo esc_textarea(get_option('wpsheets_service_account_json')); ?></textarea>
            </div>
            <div class="ws-form-group">
                <label class="ws-label">ID de la Hoja de Cálculo Principal</label>
                <input type="text" name="wpsheets_spreadsheet_id" value="<?php echo esc_attr(get_option('wpsheets_spreadsheet_id')); ?>" class="ws-input" />
            </div>
            <div style="margin-top: 30px; display: flex; gap: 15px;">
                <button type="submit" class="ws-btn ws-btn-primary">Guardar Configuración</button>
                <button type="button" id="wpsheets-test-btn" class="ws-btn ws-btn-secondary">Probar Conexión</button>
            </div>
            <div id="wpsheets-test-result" class="ws-alert" style="display: none; margin-top: 20px;"></div>
        </form>
    </div>

    
    <?php if (class_exists('WooCommerce')): ?>
    <div class="ws-card" style="margin-top: 30px; border-top: 4px solid #8B5CF6;">
        <h2 style="margin-top:0; font-size:18px; color:#4C1D95; display:flex; align-items:center; gap:8px;">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>
            Integración WooCommerce (Restaurador Inteligente)
        </h2>
        <p style="color:#6B7280; font-size:13px;">Generará o restaurará automáticamente las pestañas de <strong>Productos, Categorías, Etiquetas, Órdenes y Cupones</strong> en tu Google Sheets. <br><span style="color:#D97706; font-weight:bold;">⚠️ Seguro de usar:</span> Si el sistema detecta que una hoja ya existe, no la sobreescribirá ni borrará tus datos.</p>
        <button type="button" id="wpsheets-woo-btn" class="ws-btn ws-btn-primary" style="background:#8B5CF6; border-color:#8B5CF6;">✨ Inicializar / Restaurar Hojas WooCommerce</button>
        <div id="wpsheets-woo-result" class="ws-alert" style="display: none; margin-top: 15px;"></div>
    </div>

    <script>
    jQuery(document).ready(function($) {
        $('#wpsheets-woo-btn').on('click', function(e) {
            e.preventDefault();
            var btn = $(this);
            btn.text('Restaurando... (Por favor espera)').prop('disabled', true);
            $('#wpsheets-woo-result').hide();

            $.post(ajaxurl, {
                action: 'wpsheets_init_woocommerce',
                nonce: '<?php echo wp_create_nonce("wpsheets_ajax_nonce"); ?>'
            }, function(res) {
                btn.text('✨ Inicializar / Restaurar Hojas WooCommerce').prop('disabled', false);
                var alertBox = $('#wpsheets-woo-result');
                if (res.success) {
                    alertBox.removeClass('ws-alert-error').addClass('ws-alert-success').html(res.data).show();
                } else {
                    alertBox.removeClass('ws-alert-success').addClass('ws-alert-error').html(res.data).show();
                }
            }).fail(function() {
                btn.text('✨ Inicializar / Restaurar Hojas WooCommerce').prop('disabled', false);
                $('#wpsheets-woo-result').removeClass('ws-alert-success').addClass('ws-alert-error').html('Error interno del servidor.').show();
            });
        });
    });
    </script>
    <?php endif; ?>

    
    <?php
}
add_action('wp_ajax_wpsheets_test_connection', function() {
    check_ajax_referer('wpsheets_ajax_nonce', 'nonce');
    $sid = get_option('wpsheets_spreadsheet_id');
    if (empty($sid)) { wp_send_json_error('Guarda el ID primero.'); }
    $tabs = WPSheets_Google_API::get_spreadsheet_tabs($sid);
    if (is_wp_error($tabs) || empty($tabs)) { wp_send_json_error('Error de conexión o permisos en Google.'); }
    wp_send_json_success('Conexión establecida con éxito. Pestañas detectadas: <strong>' . implode(', ', $tabs) . '</strong>');
});


add_action('wp_ajax_wpsheets_init_woocommerce', function() {
    check_ajax_referer('wpsheets_ajax_nonce', 'nonce');

    $sid = get_option('wpsheets_spreadsheet_id');
    if (empty($sid)) wp_send_json_error('No has configurado el ID de Google Sheets.');
    if (!class_exists('WooCommerce')) wp_send_json_error('WooCommerce no está activo.');

    $existing_tabs = WPSheets_Google_API::get_spreadsheet_tabs($sid);
    if (is_wp_error($existing_tabs)) {
        $existing_tabs = [];
    }

    $sheets_to_create = [
        'Productos_WooCommerce' => [
            '_ws_import_id', 'post_title', 'post_name', 'post_status', 'sku', 'downloadable', 'virtual', 'visibility', 
            'stock', 'stock_status', 'backorders', 'manage_stock', 'regular_price', 'sale_price', 'weight', 'length', 
            'width', 'height', 'tax_status', 'tax_class', 'tax:product_type', 'tax:product_cat', 'tax:product_tag', 
            'tax:product_brand', 'attribute:Color', 'attribute_data:Color', 'attribute:Size', 'attribute_data:Size'
        ],
        'Categorias_Woo' => ['_ws_import_id', 'tax_name', 'tax_slug', 'tax_desc', 'image_url'],
        'Etiquetas_Woo' => ['_ws_import_id', 'tax_name', 'tax_slug', 'tax_desc'],
        'Órdenes_Woo' => ['_ws_import_id', 'post_title', 'post_status', 'order_total', 'order_currency', 'billing_first_name', 'billing_last_name', 'billing_email'],
        'Cupones_Woo' => ['_ws_import_id', 'post_title', 'post_status', 'coupon_amount', 'discount_type', 'free_shipping', 'expiry_date']
    ];

    // Detectar Atributos y Marcas
    $all_tax = get_taxonomies([], 'objects');
    $dynamic_tax_sheets = [];
    foreach ($all_tax as $t) {
        if (strpos($t->name, 'pa_') === 0) {
            $safe_name = 'Atributo_' . ucfirst(str_replace('pa_', '', $t->name));
            $sheets_to_create[$safe_name] = ['_ws_import_id', 'tax_name', 'tax_slug', 'tax_desc'];
            $dynamic_tax_sheets[$t->name] = $safe_name;
        } elseif (strpos($t->name, 'pwb-brand') !== false || strpos($t->name, 'yith_product_brand') !== false || strpos($t->name, 'product_brand') !== false) {
            $sheets_to_create['Marcas_Woo'] = ['_ws_import_id', 'tax_name', 'tax_slug', 'tax_desc', 'image_url'];
            $dynamic_tax_sheets[$t->name] = 'Marcas_Woo';
        }
    }

    if (function_exists('wc_get_attribute_taxonomies')) {
        $attribute_taxonomies = wc_get_attribute_taxonomies();
        if (!empty($attribute_taxonomies)) {
            foreach ($attribute_taxonomies as $tax) {
                $tax_name = 'pa_' . $tax->attribute_name;
                $safe_name = 'Atributo_' . ucfirst($tax->attribute_name);
                if (!isset($sheets_to_create[$safe_name])) {
                    $sheets_to_create[$safe_name] = ['_ws_import_id', 'tax_name', 'tax_slug', 'tax_desc'];
                    $dynamic_tax_sheets[$tax_name] = $safe_name;
                }
            }
        }
    }

    $created = [];
    $skipped = [];

    foreach ($sheets_to_create as $sheet_name => $headers) {
        if (is_array($existing_tabs) && in_array($sheet_name, $existing_tabs)) {
            $skipped[] = $sheet_name;
        } else {
            $api = WPSheets_Google_API::add_sheet_with_headers($sid, $sheet_name, $headers);
            if (!is_wp_error($api)) {
                $created[] = $sheet_name;
            }
        }
    }

    // Auto-Mapeo Fuerte e Incondicional para Woo (Sobrescribimos si están vacíos o incompletos)
    $mapping = get_option('wpsheets_fields_mapping', []);
    if (!is_array($mapping)) $mapping = [];

    // Producto Mapeo
    $product_map = [];
    foreach($sheets_to_create['Productos_WooCommerce'] as $h) {
        $safeCol = strtolower(preg_replace('/[^a-zA-Z0-9_]/', '_', $h));
        $cfg = ['type' => 'text', 'required' => 0, 'options' => []];

        if ($h === '_ws_import_id') $cfg['type'] = 'id';
        elseif ($h === 'post_title') $cfg['type'] = 'wp_title';
        elseif ($h === 'post_status') $cfg['type'] = 'wp_status';
        elseif ($h === 'post_name') $cfg['type'] = 'wp_slug';
        elseif (strpos($h, 'tax:product_cat') !== false) {
            $cfg['type'] = 'taxonomy'; $cfg['options'] = ['tax_slug' => 'product_cat'];
        }
        elseif (strpos($h, 'tax:product_tag') !== false) {
            $cfg['type'] = 'taxonomy'; $cfg['options'] = ['tax_slug' => 'product_tag'];
        }
        elseif (strpos($h, 'tax:product_brand') !== false) {
            $cfg['type'] = 'taxonomy';
            $brand_slug = 'pwb-brand';
            foreach ($dynamic_tax_sheets as $dt_name => $dt_sheet) { if (strpos($dt_name, 'brand') !== false) $brand_slug = $dt_name; }
            $cfg['options'] = ['tax_slug' => $brand_slug];
        }
        else {
            $cfg['type'] = 'meta'; $cfg['options'] = ['meta_key' => '_' . ltrim($h, '_')];
        }
        $product_map[$safeCol] = $cfg;
    }
    // Para no borrar mapeos custom, solo inyectamos los que faltan o si está vacío
    if (empty($mapping['product'])) {
        $mapping['product'] = $product_map;
    }

    // Mapas Fijos
    $mapping['tax_product_cat'] = [
        '_ws_import_id' => ['type' => 'id'], 'tax_name' => ['type' => 'tax_name'], 'tax_slug' => ['type' => 'tax_slug'], 'tax_desc' => ['type' => 'tax_desc'], 'image_url' => ['type' => 'image_url', 'options' => ['meta_key' => 'thumbnail_id']]
    ];
    $mapping['tax_product_tag'] = [
        '_ws_import_id' => ['type' => 'id'], 'tax_name' => ['type' => 'tax_name'], 'tax_slug' => ['type' => 'tax_slug'], 'tax_desc' => ['type' => 'tax_desc']
    ];
    $mapping['shop_order'] = [
        '_ws_import_id' => ['type' => 'id'], 'post_title' => ['type' => 'wp_title'], 'post_status' => ['type' => 'wp_status'],
        'order_total' => ['type' => 'meta', 'options' => ['meta_key' => '_order_total']], 'order_currency' => ['type' => 'meta', 'options' => ['meta_key' => '_order_currency']],
        'billing_first_name' => ['type' => 'meta', 'options' => ['meta_key' => '_billing_first_name']], 'billing_last_name' => ['type' => 'meta', 'options' => ['meta_key' => '_billing_last_name']],
        'billing_email' => ['type' => 'meta', 'options' => ['meta_key' => '_billing_email']]
    ];
    $mapping['shop_coupon'] = [
        '_ws_import_id' => ['type' => 'id'], 'post_title' => ['type' => 'wp_title'], 'post_status' => ['type' => 'wp_status'],
        'coupon_amount' => ['type' => 'meta', 'options' => ['meta_key' => 'coupon_amount']], 'discount_type' => ['type' => 'meta', 'options' => ['meta_key' => 'discount_type']],
        'free_shipping' => ['type' => 'meta', 'options' => ['meta_key' => 'free_shipping']], 'expiry_date' => ['type' => 'meta', 'options' => ['meta_key' => 'date_expires']]
    ];

    // Mapeo Atributos y Marcas
    foreach ($dynamic_tax_sheets as $tax_slug => $sheet_name) {
        $map_key = 'tax_' . $tax_slug;
        $base_map = [
            '_ws_import_id' => ['type' => 'id'], 'tax_name' => ['type' => 'tax_name'], 'tax_slug' => ['type' => 'tax_slug'], 'tax_desc' => ['type' => 'tax_desc']
        ];
        if ($sheet_name === 'Marcas_Woo') {
            $base_map['image_url'] = ['type' => 'image_url', 'options' => ['meta_key' => 'thumbnail_id']];
        }
        $mapping[$map_key] = $base_map;
    }

    update_option('wpsheets_fields_mapping', $mapping);

    $msg = "<strong>Resultado de la Restauración:</strong><br>";
    if (!empty($created)) {
        $msg .= "✅ <strong>Hojas creadas:</strong> " . implode(', ', $created) . ".<br>";
    }
    if (!empty($skipped)) {
        $msg .= "⚠️ <strong>Hojas ya existentes (Omitidas):</strong> " . implode(', ', $skipped) . ".<br>";
    }
    $msg .= "<em>El mapeo interno exacto (Atributos, Marcas, Cupones, Órdenes) se ha autoconfigurado al 100%.</em>";

    wp_send_json_success($msg);
});



function wpsheets_page_dashboard() {
    $cpts = get_option('wpsheets_cpts', []);
    $taxs = get_option('wpsheets_taxonomies', []);
    $mapping = get_option('wpsheets_fields_mapping', []);
    $sid = get_option('wpsheets_spreadsheet_id', '');

    $cpt_tags = '';
    if (is_array($cpts) && count($cpts) > 0) {
        foreach($cpts as $c) {
            $plural = isset($c['plural']) ? $c['plural'] : 'CPT';
            $cpt_tags .= '<span style="background:#E2E8F0; color:#334155; padding:4px 10px; border-radius:12px; font-size:12px; margin:3px; display:inline-block; font-weight:500;">' . esc_html($plural) . '</span>';
        }
    }
    if (class_exists('WooCommerce')) {
        $cpt_tags .= '<span style="background:#EDE9FE; color:#5B21B6; padding:4px 10px; border-radius:12px; font-size:12px; margin:3px; display:inline-block; font-weight:500;">🛍️ Productos (Woo)</span>';
    }
    if (empty($cpt_tags)) $cpt_tags = '<span style="color:#94A3B8; font-size:13px;">Ninguno</span>';

    $tax_tags = '';
    if (is_array($taxs) && count($taxs) > 0) {
        foreach($taxs as $t) {
            $plural = isset($t['plural']) ? $t['plural'] : 'Tax';
            $tax_tags .= '<span style="background:#E2E8F0; color:#334155; padding:4px 10px; border-radius:12px; font-size:12px; margin:3px; display:inline-block; font-weight:500;">' . esc_html($plural) . '</span>';
        }
    }
    if (class_exists('WooCommerce')) {
        $tax_tags .= '<span style="background:#EDE9FE; color:#5B21B6; padding:4px 10px; border-radius:12px; font-size:12px; margin:3px; display:inline-block; font-weight:500;">📂 Categorías (Woo)</span>';
        $tax_tags .= '<span style="background:#EDE9FE; color:#5B21B6; padding:4px 10px; border-radius:12px; font-size:12px; margin:3px; display:inline-block; font-weight:500;">🏷️ Etiquetas (Woo)</span>';
    }
    if (empty($tax_tags)) $tax_tags = '<span style="color:#94A3B8; font-size:13px;">Ninguna</span>';

    $is_connected = !empty($sid) ? '<span style="color:#10B981; font-weight:bold;">Conectado 🟢</span>' : '<span style="color:#EF4444; font-weight:bold;">Sin Conexión 🔴</span>';
?>
    <div class="wpsheets-wrap">
        <div class="wpsheets-header">
            <div class="wpsheets-header-title">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#2563EB" stroke-width="2"><path d="M3 3v18h18"/><path d="m19 9-5 5-4-4-3 3"/></svg>
                <h1>Dashboard de WP Sheets Engine</h1>
            </div>
            <div class="wpsheets-subtitle">Resumen de tu sistema y atajos rápidos.</div>
        </div>

        <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap:20px; margin-bottom:30px;">
            <!-- Estado API -->
            <div class="ws-card" style="margin:0;">
                <h3 style="margin-top:0; font-size:15px; color:#64748b;">Estado de API</h3>
                <div style="font-size:24px; margin:10px 0;"><?php echo $is_connected; ?></div>
                <a href="?page=wpsheets-api" class="ws-btn ws-btn-secondary" style="font-size:12px; padding:5px 10px;">Configurar</a>
            </div>
            <!-- CPTs -->
            <div class="ws-card" style="margin:0;">
                <h3 style="margin-top:0; font-size:15px; color:#64748b;">Post Types</h3>
                <div style="font-size:32px; font-weight:bold; margin:5px 0; color:#1E293B;"><?php echo $cpt_tags; ?></div>
                <a href="?page=wpsheets-cpts" class="ws-btn ws-btn-secondary" style="font-size:12px; padding:5px 10px;">Gestionar</a>
            </div>
            <!-- Taxonomies -->
            <div class="ws-card" style="margin:0;">
                <h3 style="margin-top:0; font-size:15px; color:#64748b;">Taxonomías</h3>
                <div style="font-size:32px; font-weight:bold; margin:5px 0; color:#1E293B;"><?php echo $tax_tags; ?></div>
                <a href="?page=wpsheets-tax" class="ws-btn ws-btn-secondary" style="font-size:12px; padding:5px 10px;">Gestionar</a>
            </div>
        </div>

        <div style="display:grid; grid-template-columns: 2fr 1fr; gap:20px;">
            <div>
                <!-- Acciones Rápidas -->
                <div class="ws-card">
                    <h2 style="margin-top:0; font-size:18px;">Acciones Rápidas</h2>
                    <div style="display:flex; gap:15px; flex-wrap:wrap; margin-top:20px;">
                        <a href="?page=wpsheets-sync" class="ws-btn ws-btn-primary" style="text-decoration:none;">🔄 Ir a Sincronizar Datos</a>
                        <a href="?page=wpsheets-fields" class="ws-btn ws-btn-secondary" style="text-decoration:none;">⚙️ Mapeo de Columnas</a>
                        <a href="?page=wpsheets-datagrid" class="ws-btn ws-btn-secondary" style="text-decoration:none;">📊 Editor Data Grid</a>
                        <a href="?page=wpsheets-auto-sync" class="ws-btn ws-btn-secondary" style="text-decoration:none; background:#FFFBEB; color:#B45309; border-color:#FCD34D;">⏱️ Configurar Auto-Sync</a>
                    </div>
                </div>

                <?php if (class_exists('WooCommerce')): 
                    $woo_init = get_option('wpsheets_fields_mapping');
                    $is_woo_ready = isset($woo_init['product']);
                ?>
                <div class="ws-card" style="margin-top: 20px; border-top: 4px solid #8B5CF6;">
                    <h2 style="margin-top:0; font-size:18px; color:#4C1D95; display:flex; align-items:center; gap:8px;">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>
                        Módulo WooCommerce
                    </h2>

                    <?php if ($is_woo_ready): ?>
                        <div style="background:#F5F3FF; padding:15px; border-radius:8px; margin-bottom:15px;">
                            <span style="color:#10B981; font-weight:bold; display:flex; align-items:center; gap:5px;">
                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
                                ¡Conexión Activa y Mapeada!
                            </span>
                            <p style="color:#5B21B6; font-size:13px; margin-top:5px;">La hoja "Productos_WooCommerce" está configurada. ¿Qué deseas hacer?</p>
                        </div>
                        <div style="display:flex; gap:10px;">
                            <a href="?page=wpsheets-woo" class="ws-btn ws-btn-primary" style="background:#8B5CF6; border-color:#8B5CF6; text-decoration:none;">⚙️ Ver Panel de Woo</a>
                            <a href="?page=wpsheets-fields" class="ws-btn ws-btn-secondary" style="text-decoration:none;">Ver Mapeo</a>
                        </div>
                    <?php else: ?>
                        <p style="color:#6B7280; font-size:13px;">Hemos detectado WooCommerce en tu sitio. Haz clic abajo para generar automáticamente la pestaña <strong>Productos_WooCommerce</strong> en tu Google Sheets.</p>
                        <button type="button" id="wpsheets-woo-btn-dash" class="ws-btn ws-btn-primary" style="background:#8B5CF6; border-color:#8B5CF6;">Inicializar Hoja WooCommerce</button>
                        <div id="wpsheets-woo-result-dash" class="ws-alert" style="display: none; margin-top: 15px;"></div>
                        <script>
                        jQuery(document).ready(function($) {
                            $('#wpsheets-woo-btn-dash').on('click', function(e) {
                                e.preventDefault();
                                var btn = $(this);
                                btn.text('Inicializando...').prop('disabled', true);
                                $.post(ajaxurl, { action: 'wpsheets_init_woocommerce', nonce: '<?php echo wp_create_nonce("wpsheets_ajax_nonce"); ?>' }, function(res) {
                                    if (res.success) { location.reload(); } else { $('#wpsheets-woo-result-dash').addClass('ws-alert-error').html(res.data).show(); btn.text('Error').prop('disabled', false); }
                                });
                            });
                        });
                        </script>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>

            <!-- Ayuda / Info -->
            <div class="ws-card" style="background:#F8FAFC;">
                <h2 style="margin-top:0; font-size:18px;">💡 Tips de Uso</h2>
                <ul style="color:#475569; font-size:13px; line-height:1.6; padding-left:20px;">
                    <li>Siempre que agregues un nuevo campo en "Campos Dinámicos", recuerda hacer una sincronización.</li>
                    <li>Usa el <strong>Data Grid Live</strong> para editar como si estuvieras en Excel sin salir de WP.</li>
                    <li>Las fotos del carrusel de Divi toman su configuración de diseño directamente desde el constructor.</li>
                </ul>
            </div>
        
            <!-- Webhook Debug Log -->
            <div class="ws-card" style="border-top: 4px solid #F59E0B; margin-top:20px;">
                <h2 style="margin-top:0; font-size:18px; color:#B45309;">🔎 Registro de Diagnóstico (Logs)</h2>
                <p style="color:#475569; font-size:13px;">Si editas en Google Sheets y no ves el cambio en WordPress, revisa el último mensaje recibido del Webhook:</p>
                <div style="background:#1E293B; color:#F8FAFC; padding:15px; border-radius:6px; font-family:monospace; font-size:12px;">
                    <?php echo esc_html(get_option('wpsheets_last_webhook_error', 'Esperando el primer envío de datos desde Google Sheets...')); ?>
                </div>
            </div>

    </div>
    </div>
    <?php
}

// ADMIN NOTICES
add_action('admin_notices', function() {
    // Notice 1: WooCommerce Detected but not initialized
    if (class_exists('WooCommerce') && !get_option('wpsheets_woo_initialized')) {
        $mapping = get_option('wpsheets_fields_mapping', []);
        if (!isset($mapping['product'])) {
            echo '<div style="background: linear-gradient(135deg, #6D28D9 0%, #8B5CF6 100%); color: white; padding: 20px; margin: 15px 15px 15px 0; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); display: flex; align-items: center; justify-content: space-between;">';
            echo '<div style="display:flex; align-items:center; gap:15px;">';
            echo '<span style="font-size:35px; line-height:1;">🚀</span>';
            echo '<div>';
            echo '<h3 style="margin: 0 0 5px 0; color: white; font-size: 18px;">¡WooCommerce Detectado!</h3>';
            echo '<p style="margin: 0; font-size: 14px; opacity: 0.9;">WP Sheets Engine está listo para conectar tus productos con Google Sheets de forma automática.</p>';
            echo '</div></div>';
            echo '<a href="?page=wpsheets-dashboard" style="background: white; color: #6D28D9; text-decoration: none; padding: 12px 24px; border-radius: 6px; font-weight: bold; font-size: 14px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">Inicializar Ahora &rarr;</a>';
            echo '</div>';
        }
    }

    // Notice 2: Needs Sync
    if (get_option('wpsheets_needs_sync') == '1') {
        echo '<div style="background: linear-gradient(135deg, #F59E0B 0%, #FCD34D 100%); color: #78350F; padding: 20px; margin: 15px 15px 15px 0; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); display: flex; align-items: center; justify-content: space-between;">';
        echo '<div style="display:flex; align-items:center; gap:15px;">';
        echo '<span style="font-size:35px; line-height:1;">⚠️</span>';
        echo '<div>';
        echo '<h3 style="margin: 0 0 5px 0; color: #78350F; font-size: 18px;">Cambios Pendientes de Sincronizar</h3>';
        echo '<p style="margin: 0; font-size: 14px; opacity: 0.9;">Detectamos modificaciones en tus estructuras o mapeos. Sincroniza para reflejarlos en tu base de datos.</p>';
        echo '</div></div>';
        echo '<a href="?page=wpsheets-sync" style="background: #78350F; color: white; text-decoration: none; padding: 12px 24px; border-radius: 6px; font-weight: bold; font-size: 14px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">Ir a Sincronizar &rarr;</a>';
        echo '</div>';
    }
});


function wpsheets_page_settings() {
    $secret = get_option('wpsheets_webhook_secret');
    if (empty($secret)) {
        $secret = wp_generate_password(24, false);
        update_option('wpsheets_webhook_secret', $secret);
    }
    $webhook_url = rest_url('wpsheets/v1/webhook');
    ?>
    <div class="wpsheets-wrap">
        <div class="wpsheets-header">
            <div class="wpsheets-header-title">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#2563EB" stroke-width="2"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/></svg>
                <h1>Configuración & Webhooks</h1>
            </div>
            <div class="wpsheets-subtitle">Configura la sincronización en tiempo real mediante Google Apps Script.</div>
        </div>

        <div class="ws-card" style="border-top: 4px solid #10B981;">
            <h2 style="margin-top:0; font-size:18px; color:#047857;">🚀 Sincronización en Tiempo Real (Bidireccional)</h2>
            <p style="color:#475569; font-size:14px; line-height:1.6;">
                Este código de <strong>Google Apps Script</strong> convierte tu Google Sheets en una base de datos reactiva. Al pegarlo en tu hoja, cualquier celda que edites (ya sea un producto de WooCommerce, un Platillo o una Categoría) se enviará <strong>instantáneamente</strong> a tu sitio web sin tener que esperar al Auto-Sync.
            </p>

            <div style="background:#F1F5F9; padding:15px; border-radius:6px; margin:20px 0; border:1px solid #CBD5E1;">
                <div style="margin-bottom:10px;"><strong>📍 Tu URL de Webhook:</strong> <code style="background:#fff; padding:4px 8px; color:#2563EB;"><?php echo esc_url($webhook_url); ?></code></div>
                <div><strong>🔑 Tu Token Secreto:</strong> <code style="background:#fff; padding:4px 8px; color:#EF4444;"><?php echo esc_html($secret); ?></code></div>
            </div>

            <h3 style="font-size:15px; margin-bottom:10px;">Instrucciones de Uso (Paso a Paso):</h3>
            <div style="color:#475569; font-size:14px; line-height:1.8; margin-bottom:20px;">
                <p>Google bloquea las conexiones externas por seguridad si solo pegas el código. Sigue estos 5 pasos exactos para autorizar a tu hoja a hablar con WordPress:</p>
                <ol style="padding-left:20px; background:#F8FAFC; padding:15px 15px 15px 35px; border-radius:8px; border:1px solid #E2E8F0;">
                    <li>Abre tu archivo de Google Sheets y ve al menú <strong>Extensiones > Apps Script</strong>.</li>
                    <li>Borra todo el código que aparezca ahí y <strong>pega el código negro de abajo</strong>. Haz clic en Guardar (💾).</li>
                    <li>En el menú lateral izquierdo de Apps Script, haz clic en el ícono del <strong>Reloj 🕒 (Activadores / Triggers)</strong>.</li>
                    <li>Haz clic en el botón azul <strong>"+ Añadir activador"</strong> (abajo a la derecha) y configúralo así:
                        <ul style="list-style-type:circle; padding-left:20px; margin-top:5px; color:#334155;">
                            <li>Función a ejecutar: <strong>sincronizarWP</strong></li>
                            <li>Fuente del evento: <strong>De la hoja de cálculo</strong></li>
                            <li>Tipo de evento: <strong>Al editar</strong></li>
                        </ul>
                    </li>
                    <li>Haz clic en <strong>Guardar</strong>. Google te pedirá permisos (saldrá una advertencia de seguridad). Haz clic en "Configuración Avanzada" > "Ir a Proyecto" y dale a <strong>Permitir</strong>.</li>
                </ol>
                <p style="color:#10B981; font-weight:bold;">¡Listo! No necesitas crear ninguna implementación o despliegue. Cierra Apps Script y edita cualquier celda para ver la magia.</p>
            </div>

            <div style="position:relative;">
                <button type="button" id="copy-script-btn" style="position:absolute; top:10px; right:10px; background:#3B82F6; color:#fff; border:none; padding:6px 12px; border-radius:4px; cursor:pointer; font-size:12px; display:flex; align-items:center; gap:5px; font-weight:bold; box-shadow:0 2px 4px rgba(0,0,0,0.2); transition:all 0.2s;">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>
                    Copiar Código
                </button>
                <pre id="apps-script-code" class="ws-code"><code>// ==========================================
// CONFIGURACIÓN PRINCIPAL
// ==========================================
var WEBHOOK_URL = "<?php echo esc_url_raw($webhook_url); ?>";

// ==========================================
// 1. INICIALIZADOR AUTOMÁTICO DE HOJAS
// ==========================================
function onOpen() {
  var ui = SpreadsheetApp.getUi();
  ui.createMenu('🤖 WP Sheets Engine')
      .addItem('✨ Inicializar esta Hoja', 'inicializarHojaActual')
      .addToUi();
}

function inicializarHojaActual() {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
  var ui = SpreadsheetApp.getUi();

  var lastRow = sheet.getLastRow() || 1;
  var hasData = (lastRow > 1); 

  // 1. Manejar columna A (ID) respetando _ws_import_id
  var firstHeader = sheet.getRange(1, 1).getValue();

  if (firstHeader !== "backendId" && firstHeader !== "_ws_import_id") {
    if (firstHeader !== "") {
      var response = ui.alert(
        'Configuración de ID', 
        '¿La primera columna ("' + firstHeader + '") ya contiene los IDs de tus registros?', 
        ui.ButtonSet.YES_NO
      );
      if (response == ui.Button.YES) {
        sheet.getRange(1, 1).setValue("backendId");
      } else {
        sheet.insertColumnBefore(1);
        sheet.getRange(1, 1).setValue("backendId");
      }
    } else {
      sheet.getRange(1, 1).setValue("backendId");
    }
  }

  // 2. Manejar columna wp_status_wordpress
  var headers = sheet.getRange(1, 1, 1, sheet.getLastColumn() || 1).getValues()[0];
  var statusColIndex = headers.indexOf("wp_status_wordpress") + 1;

  if (statusColIndex === 0) { 
    sheet.insertColumnAfter(1);
    sheet.getRange(1, 2).setValue("wp_status_wordpress");
    statusColIndex = 2; 
  }

  lastRow = sheet.getLastRow() || 1;
  var maxRows = sheet.getMaxRows();

  // 3. Rellenar automáticamente con "publish"
  if (lastRow > 1) {
    var statusRange = sheet.getRange(2, statusColIndex, lastRow - 1, 1);
    var statusValues = statusRange.getValues();

    var modified = false;
    for (var i = 0; i < statusValues.length; i++) {
      if (statusValues[i][0] === "") {
        statusValues[i][0] = "publish";
        modified = true;
      }
    }
    if (modified) {
      statusRange.setValues(statusValues);
    }
  }

  // 4. Estilos de encabezados
  var headerRange = sheet.getRange(1, 1, 1, sheet.getLastColumn());
  headerRange.setFontWeight("bold").setBackground("#f3f4f6");
  sheet.setFrozenRows(1);

  // 5. Poner los Chips
  var rule = SpreadsheetApp.newDataValidation()
    .requireValueInList(['publish', 'draft', 'trash'], true)
    .setAllowInvalid(false) 
    .build();

  var fullStatusRange = sheet.getRange(2, statusColIndex, maxRows - 1, 1);
  fullStatusRange.setDataValidation(rule);

  // 6. Colores a los Chips
  var rules = sheet.getConditionalFormatRules();
  var colorPublish = SpreadsheetApp.newConditionalFormatRule().whenTextEqualTo('publish').setBackground('#b7e1cd').setFontColor('#006622').setRanges([fullStatusRange]).build();
  var colorDraft = SpreadsheetApp.newConditionalFormatRule().whenTextEqualTo('draft').setBackground('#fce8b2').setFontColor('#b26b00').setRanges([fullStatusRange]).build();
  var colorTrash = SpreadsheetApp.newConditionalFormatRule().whenTextEqualTo('trash').setBackground('#f4c7c3').setFontColor('#990000').setRanges([fullStatusRange]).build();
  rules.push(colorPublish, colorDraft, colorTrash);
  sheet.setConditionalFormatRules(rules);

  // 7. Proteger la columna A (Lanza advertencia si la intentas editar)
  try {
    var protectId = sheet.getRange(2, 1, maxRows - 1, 1).protect().setDescription('Bloqueo de IDs');
    protectId.setWarningOnly(true); 
  } catch(e) {}

  ui.alert('✅ Hoja inicializada respetando tus IDs actuales.');
}

// ==========================================
// 2. EL MOTOR DE SINCRONIZACIÓN EN TIEMPO REAL
// ==========================================
function onEdit(e) {
  if (!e) return;
  var sheet = e.source.getActiveSheet();
  var range = e.range;
  var row = range.getRow();

  if (row === 1) return;

  var headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
  var rowData = sheet.getRange(row, 1, 1, sheet.getLastColumn()).getValues()[0];

  // Buscar ID (backendId o _ws_import_id)
  var idIndex = headers.indexOf("backendId");
  if (idIndex === -1) idIndex = headers.indexOf("_ws_import_id");

  if (idIndex !== -1 && !rowData[idIndex]) {
    var newId = Utilities.getUuid();
    sheet.getRange(row, idIndex + 1).setValue(newId);
    rowData[idIndex] = newId;

    var statusIndex = headers.indexOf("wp_status_wordpress");
    if (statusIndex !== -1 && !rowData[statusIndex]) {
      sheet.getRange(row, statusIndex + 1).setValue("publish");
      rowData[statusIndex] = "publish";
    }
  }

  if (idIndex !== -1 && rowData[idIndex]) {
    enviarAWordPress(sheet.getName(), headers, rowData);
  }
}

function enviarAWordPress(sheetName, headers, rowValues) {
  var payload = { sheet_name: sheetName, headers: headers, row_data: rowValues };
  var options = { method: "post", contentType: "application/json", payload: JSON.stringify(payload) };
  try { UrlFetchApp.fetch(WEBHOOK_URL, options); } catch (err) {}
}</code></pre>
            </div>
            <script>
            document.addEventListener('DOMContentLoaded', function() {
                var copyBtn = document.getElementById('copy-script-btn');
                if(copyBtn) {
                    copyBtn.addEventListener('click', function() {
                        var code = document.getElementById('apps-script-code').innerText;
                        navigator.clipboard.writeText(code).then(function() {
                            var originalHTML = copyBtn.innerHTML;
                            copyBtn.innerHTML = '¡Copiado! ✅';
                            copyBtn.style.background = '#10B981';
                            setTimeout(function() {
                                copyBtn.innerHTML = originalHTML;
                                copyBtn.style.background = '#3B82F6';
                            }, 2000);
                        });
                    });
                }
            });
            </script>
        
            <!-- Webhook Debug Log -->
            <div class="ws-card" style="border-top: 4px solid #F59E0B; margin-top:20px;">
                <h2 style="margin-top:0; font-size:18px; color:#B45309;">🔎 Registro de Diagnóstico (Logs)</h2>
                <p style="color:#475569; font-size:13px;">Si editas en Google Sheets y no ves el cambio en WordPress, revisa el último mensaje recibido del Webhook:</p>
                <div style="background:#1E293B; color:#F8FAFC; padding:15px; border-radius:6px; font-family:monospace; font-size:12px;">
                    <?php echo esc_html(get_option('wpsheets_last_webhook_error', 'Esperando el primer envío de datos desde Google Sheets...')); ?>
                </div>
            </div>

    </div>
    </div>
    <?php
}
