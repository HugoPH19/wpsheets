<?php
if (!defined('ABSPATH')) exit;

function wpsheets_page_woo() {
    if (!class_exists('WooCommerce')) {
        echo '<div class="wrap"><h1>WooCommerce no está activo</h1></div>';
        return;
    }

    $args = [
        'post_type' => 'product',
        'post_status' => 'any',
        'meta_key' => '_wpsheets_dummy',
        'meta_value' => '1',
        'posts_per_page' => -1,
        'fields' => 'ids'
    ];
    $dummy_products = get_posts($args);
    $dummy_count = count($dummy_products);
    ?>
    <div class="wpsheets-wrap">
        <div class="wpsheets-header">
            <div class="wpsheets-header-title">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#8B5CF6" stroke-width="2"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>
                <h1>Panel de Desarrollo WooCommerce</h1>
            </div>
            <div class="wpsheets-subtitle">Herramientas de pruebas avanzadas (Dummy Data Generator).</div>
        </div>

        <div style="display:grid; grid-template-columns: 2fr 1fr; gap:20px;">
            <!-- Herramientas de Prueba Avanzadas -->
            <div class="ws-card">
                <h2 style="margin-top:0; font-size:18px; color:#4C1D95;">🧪 Generador Avanzado de Productos</h2>
                <p style="color:#475569; font-size:13px;">Crea conjuntos de 5 productos completos con configuraciones reales (precios, stock, peso, envío, atributos). Útil para probar Divi, filtros y carritos.</p>

                <form id="dummy-form" style="background:#F8FAFC; padding:20px; border-radius:8px; border:1px solid #E2E8F0; margin:20px 0;">
                    <div style="display:grid; grid-template-columns: 1fr 1fr; gap:15px; margin-bottom:20px;">
                        <label style="display:flex; align-items:center; gap:10px; cursor:pointer;">
                            <input type="checkbox" name="dummy_types[]" value="simple" checked style="width:18px; height:18px;">
                            <span style="font-weight:600; color:#334155;">5 Productos Simples</span>
                            <span style="font-size:12px; color:#64748B;">(Físicos con peso y dimensiones)</span>
                        </label>
                        <label style="display:flex; align-items:center; gap:10px; cursor:pointer;">
                            <input type="checkbox" name="dummy_types[]" value="variable" checked style="width:18px; height:18px;">
                            <span style="font-weight:600; color:#334155;">5 Productos Variables</span>
                            <span style="font-size:12px; color:#64748B;">(Atributos: Color y Talla)</span>
                        </label>
                        <label style="display:flex; align-items:center; gap:10px; cursor:pointer;">
                            <input type="checkbox" name="dummy_types[]" value="digital" style="width:18px; height:18px;">
                            <span style="font-weight:600; color:#334155;">5 Productos Digitales</span>
                            <span style="font-size:12px; color:#64748B;">(Descargables / Virtuales)</span>
                        </label>
                        <label style="display:flex; align-items:center; gap:10px; cursor:pointer;">
                            <input type="checkbox" name="dummy_types[]" value="grouped" style="width:18px; height:18px;">
                            <span style="font-weight:600; color:#334155;">5 Productos Agrupados</span>
                            <span style="font-size:12px; color:#64748B;">(Packs de productos simples)</span>
                        </label>
                    </div>

                    <div style="display:flex; gap:10px; border-top:1px solid #E2E8F0; padding-top:15px;">
                        <button type="submit" id="btn-create-dummy" class="ws-btn ws-btn-primary" style="background:#8B5CF6; border-color:#8B5CF6;">
                            🚀 Generar Productos de Prueba
                        </button>
                    </div>
                </form>
                <div id="dummy-result" class="ws-alert" style="display:none;"></div>
            </div>

            
            
            
            <!-- Exportar todo a Google Sheets -->
            <div class="ws-card" style="grid-column: 1 / -1; margin-top: 10px; border-left: 4px solid #3B82F6;">
                <h2 style="margin-top:0; font-size:18px; color:#1D4ED8;">⬆️ Exportar Datos Woo a Google Sheets</h2>
                <p style="color:#475569; font-size:13px; margin-bottom:15px;">Selecciona la entidad que deseas exportar. Esto leerá el mapeo desde "Campos Dinámicos" y volcará todos los datos a la hoja de Google correspondiente.</p>

                <select id="ws-woo-export-select" class="ws-select" style="max-width:400px; margin-bottom:15px; display:block;">
                    <?php echo wpsheets_get_grouped_options_html(); ?>
                </select>

                <button id="btn-export-woo-entity" class="ws-btn ws-btn-primary" style="background:#3B82F6; border-color:#3B82F6;">
                    ⬆️ Exportar Seleccionado a Google Sheets
                </button>
                <div id="export-result" class="ws-alert" style="display:none; margin-top:15px;"></div>
            </div>


            <!-- Testear Sincronización -->
            <div class="ws-card" style="grid-column: 1 / -1; margin-top: 10px; border-left: 4px solid #10B981;">
                <h2 style="margin-top:0; font-size:18px; color:#047857;">🟢 Llenar Google Sheets (Para probar Data Grid y Sync)</h2>
                <p style="color:#475569; font-size:13px;">Como el Data Grid y la Sincronización leen los datos <strong>desde tu hoja de cálculo hacia WordPress</strong>, los productos creados arriba no aparecen ahí. Usa este botón para inyectar 3 productos de prueba directamente en tu Google Sheets.</p>
                <button id="btn-inject-sheet" class="ws-btn ws-btn-primary" style="background:#10B981; border-color:#10B981;">
                    📝 Inyectar Datos en Google Sheets
                </button>
                <div id="inject-result" class="ws-alert" style="display:none; margin-top:15px;"></div>
            </div>

            <!-- Panel Lateral de Control -->
            <div>
                <div class="ws-card">
                    <h2 style="margin-top:0; font-size:18px; color:#EF4444;">🗑️ Limpieza</h2>
                    <div style="background:#FEF2F2; padding:15px; border-radius:8px; margin:15px 0; text-align:center;">
                        <strong style="font-size:32px; color:#991B1B; display:block;"><?php echo $dummy_count; ?></strong>
                        <span style="color:#B91C1C; font-size:13px; font-weight:600;">Productos Dummy Activos</span>
                    </div>
                    <?php if ($dummy_count > 0): ?>
                    <button id="btn-delete-dummy" class="ws-btn ws-btn-secondary" style="width:100%; justify-content:center; color:#EF4444; border-color:#EF4444;">
                        Borrar Datos Dummy
                    </button>
                    <p style="font-size:11px; color:#64748B; text-align:center; margin-top:10px;">Solo se borrarán los productos generados por esta herramienta.</p>
                    <?php else: ?>
                    <p style="font-size:12px; color:#64748B; text-align:center;">No hay datos de prueba generados actualmente.</p>
                    <?php endif; ?>
                </div>

                <div class="ws-card">
                    <h2 style="margin-top:0; font-size:18px;">📊 Estadísticas Reales</h2>
                    <ul style="color:#475569; font-size:13px; line-height:2.2; margin:0; padding:0; list-style:none;">
                        <li style="border-bottom:1px solid #E2E8F0; padding-bottom:5px;">🛍️ Total Catálogo: <strong><?php echo wp_count_posts('product')->publish; ?></strong></li>
                        <li style="border-bottom:1px solid #E2E8F0; padding-bottom:5px; margin-top:5px;">📁 Categorías: <strong><?php echo wp_count_terms('product_cat'); ?></strong></li>
                        <li style="margin-top:5px;">🏷️ Etiquetas: <strong><?php echo wp_count_terms('product_tag'); ?></strong></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <script>
    jQuery(document).ready(function($) {
        $('#dummy-form').on('submit', function(e) {
            e.preventDefault();
            var types = [];
            $('input[name="dummy_types[]"]:checked').each(function() { types.push($(this).val()); });
            if(types.length === 0) { alert('Selecciona al menos un tipo de producto'); return; }

            var btn = $('#btn-create-dummy');
            btn.html('⏳ Generando (Esto tomará unos segundos)...').prop('disabled', true);
            $('#dummy-result').hide();

            $.post(ajaxurl, { 
                action: 'wpsheets_create_advanced_dummy', 
                nonce: '<?php echo wp_create_nonce("wpsheets_ajax_nonce"); ?>',
                types: types
            }, function(res) {
                if (res.success) { location.reload(); } 
                else { $('#dummy-result').addClass('ws-alert-error').html(res.data).show(); btn.html('🚀 Generar Productos').prop('disabled', false); }
            }).fail(function() {
                $('#dummy-result').addClass('ws-alert-error').html('Error de servidor timeout').show();
                btn.html('🚀 Generar Productos').prop('disabled', false);
            });
        });

        $('#btn-delete-dummy').on('click', function(e) {
            e.preventDefault();
            if(!confirm('¿Borrar todos los productos de prueba?')) return;
            var btn = $(this);
            btn.text('Borrando...').prop('disabled', true);
            $.post(ajaxurl, { action: 'wpsheets_delete_dummy_woo', nonce: '<?php echo wp_create_nonce("wpsheets_ajax_nonce"); ?>' }, function(res) {
                if (res.success) { location.reload(); } 
                else { alert('Error: ' + res.data); btn.text('Borrar').prop('disabled', false); }
            });
        });
    
        
        
        // Restaurador Inteligente
        $('#btn-restore-woo').on('click', function(e) {
            e.preventDefault();
            var btn = $(this);
            var result = $('#restore-result');

            btn.text('Restaurando... (espera)').prop('disabled', true);
            result.hide().removeClass('ws-alert-error ws-alert-success');

            $.post(ajaxurl, {
                action: 'wpsheets_init_woocommerce',
                nonce: wpSheets.nonce
            }, function(res) {
                btn.text('✨ Inicializar / Restaurar Hojas').prop('disabled', false);
                if(res.success) {
                    result.addClass('ws-alert-success').html(res.data).show();
                } else {
                    result.addClass('ws-alert-error').html(res.data).show();
                }
            }).fail(function() {
                btn.text('✨ Inicializar / Restaurar Hojas').prop('disabled', false);
                result.addClass('ws-alert-error').html('Error interno del servidor al restaurar.').show();
            });
        });

        $('#btn-export-woo-entity').on('click', function(e) {
            e.preventDefault();
            var btn = $(this);
            var select = $('#ws-woo-export-select');
            var entity = select.val();
            var sheet = select.find(':selected').data('sheet');

            if (!entity) return alert('Por favor selecciona una opción válida');
            if (!sheet) return alert('La opción seleccionada no tiene una hoja válida en Google Sheets (Verifica en el selector)');

            btn.text('Exportando ' + entity + ' (puede tomar tiempo)...').prop('disabled', true);
            $('#export-result').hide().removeClass('ws-alert-error ws-alert-success');

            $.post(ajaxurl, { 
                action: 'wpsheets_export_woo_mass', 
                nonce: '<?php echo wp_create_nonce("wpsheets_ajax_nonce"); ?>',
                entity: entity,
                sheet: sheet
            }, function(res) {
                if (res.success) { $('#export-result').addClass('ws-alert-success').html(res.data).show(); } 
                else { $('#export-result').addClass('ws-alert-error').html(res.data).show(); }
                btn.text('⬆️ Exportar Seleccionado a Google Sheets').prop('disabled', false);
            }).fail(function() {
                $('#export-result').addClass('ws-alert-error').html('Error interno de servidor o timeout.').show();
                btn.text('⬆️ Exportar Seleccionado a Google Sheets').prop('disabled', false);
            });
        });

        $('#btn-inject-sheet').on('click', function(e) {
            e.preventDefault();
            var btn = $(this);
            btn.text('Inyectando a Google Sheets...').prop('disabled', true);
            $('#inject-result').hide();
            $.post(ajaxurl, { action: 'wpsheets_inject_sheet_dummies', nonce: '<?php echo wp_create_nonce("wpsheets_ajax_nonce"); ?>' }, function(res) {
                if (res.success) { $('#inject-result').removeClass('ws-alert-error').addClass('ws-alert-success').html(res.data).show(); } 
                else { $('#inject-result').removeClass('ws-alert-success').addClass('ws-alert-error').html(res.data).show(); }
                btn.text('📝 Inyectar Datos en Google Sheets').prop('disabled', false);
            });
        });
});
    </script>
    <?php
}

// AJAX: Generador Avanzado
add_action('wp_ajax_wpsheets_create_advanced_dummy', function() {
    check_ajax_referer('wpsheets_ajax_nonce', 'nonce');
    if (!class_exists('WooCommerce')) wp_send_json_error('WooCommerce no está activo');

    $types = isset($_POST['types']) ? (array) $_POST['types'] : [];
    if (empty($types)) wp_send_json_error('No seleccionaste ningún tipo');

    // Helper functions for random data
    
    require_once(ABSPATH . 'wp-admin/includes/media.php');
    require_once(ABSPATH . 'wp-admin/includes/file.php');
    require_once(ABSPATH . 'wp-admin/includes/image.php');

    // Descargar una imagen genérica para todos (para no hacer timeout descargando 20)
    $img_url = 'https://picsum.photos/800/800.jpg';
    $img_id = media_sideload_image($img_url, 0, 'Imagen Dummy Generada', 'id');
    if (is_wp_error($img_id)) { $img_id = ''; }

    function get_random_cat() {

        $cats = ['Electrónica Dummy', 'Ropa Dummy', 'Hogar Dummy', 'Digital Dummy'];
        $name = $cats[array_rand($cats)];
        $term = term_exists($name, 'product_cat');
        if (!$term) { $term = wp_insert_term($name, 'product_cat'); }
        return is_array($term) ? $term['term_id'] : $term;
    }

    $created = 0;

    // 1. SIMPLES (Físicos con peso y medidas)
    if (in_array('simple', $types)) {
        for ($i=1; $i<=5; $i++) {
            $p = new WC_Product_Simple();
            $p->set_name("Dummy Físico - Producto Simple {$i}");
            $p->set_status('publish');
            $p->set_description("Este es un producto físico de prueba completo. Cuenta con dimensiones, peso y configuración de inventario. Generado por WP Sheets Engine.");
            $p->set_short_description("Producto físico con peso de prueba {$i}");
            $p->set_sku("DMY-SMP-" . rand(1000, 9999));
            $p->set_regular_price(rand(100, 900) . '.00');
            if (rand(0,1)) $p->set_sale_price((float)$p->get_regular_price() * 0.8);

            $p->set_manage_stock(true);
            $p->set_stock_quantity(rand(5, 50));
            $p->set_stock_status('instock');

            // Medidas físicas
            $p->set_weight(rand(1, 10) . '.5');
            $p->set_length(rand(10, 50));
            $p->set_width(rand(10, 30));
            $p->set_height(rand(5, 20));

            $p->set_category_ids([get_random_cat()]);
            if(!empty($img_id)) $p->set_image_id($img_id);
            $p->add_meta_data('_wpsheets_dummy', '1', true);
            $p->save();
            $created++;
        }
    }

    // 2. DIGITALES (Virtual / Descargable)
    if (in_array('digital', $types)) {
        for ($i=1; $i<=5; $i++) {
            $p = new WC_Product_Simple();
            $p->set_name("Dummy Digital - Ebook / Curso {$i}");
            $p->set_status('publish');
            $p->set_virtual(true);
            $p->set_downloadable(true);
            $p->set_description("Producto virtual y descargable. No tiene costo de envío ni dimensiones. Generado por WP Sheets Engine.");
            $p->set_sku("DMY-DIG-" . rand(1000, 9999));
            $p->set_regular_price(rand(50, 300) . '.00');

            $download = new WC_Product_Download();
            $download->set_id(md5(uniqid()));
            $download->set_name("Archivo de Prueba {$i}");
            $download->set_file(site_url('/wp-content/dummy-file.pdf'));
            $p->set_downloads([$download]);
            $p->set_download_limit(0); // ilimitado

            $p->set_category_ids([get_random_cat()]);
            if(!empty($img_id)) $p->set_image_id($img_id);
            $p->add_meta_data('_wpsheets_dummy', '1', true);
            $p->save();
            $created++;
        }
    }

    // 3. VARIABLES (Con Atributos)
    if (in_array('variable', $types)) {
        for ($i=1; $i<=5; $i++) {
            $p = new WC_Product_Variable();
            $p->set_name("Dummy Variable - Camiseta/Zapato {$i}");
            $p->set_status('publish');
            $p->set_sku("DMY-VAR-" . rand(1000, 9999));
            $p->set_category_ids([get_random_cat()]);

            $colors = ['Rojo', 'Azul', 'Negro'];
            $sizes = ['S', 'M', 'L'];

            $attr1 = new WC_Product_Attribute();
            $attr1->set_id(0); $attr1->set_name('Color');
            $attr1->set_options($colors); $attr1->set_position(0);
            $attr1->set_visible(true); $attr1->set_variation(true);

            $attr2 = new WC_Product_Attribute();
            $attr2->set_id(0); $attr2->set_name('Talla');
            $attr2->set_options($sizes); $attr2->set_position(1);
            $attr2->set_visible(true); $attr2->set_variation(true);

            $p->set_attributes([$attr1, $attr2]);
            if(!empty($img_id)) $p->set_image_id($img_id);
            $p->add_meta_data('_wpsheets_dummy', '1', true);
            $parent_id = $p->save();

            // Crear solo un par de variaciones reales para no saturar el servidor
            foreach (['Rojo', 'Azul'] as $color) {
                foreach (['S', 'M'] as $size) {
                    $v = new WC_Product_Variation();
                    $v->set_parent_id($parent_id);
                    $v->set_attributes(['color' => $color, 'talla' => $size]);
                    $v->set_regular_price(rand(150, 400) . '.00');
                    $v->set_manage_stock(true);
                    $v->set_stock_quantity(rand(2, 10));
                    $v->set_weight(rand(1,5) . '.0');
                    $v->set_length(rand(10,30));
                    $v->set_width(rand(10,20));
                    $v->set_height(rand(5,15));
                    $v->set_description('Descripción específica para la variación de color '.$color.' y talla '.$size.'. Incluye medidas exactas.');
                    if(!empty($img_id)) $v->set_image_id($img_id); // Variaciones también tienen peso
                    $v->add_meta_data('_wpsheets_dummy', '1', true);
                    $v->save();
                }
            }
            $created++;
        }
    }

    // 4. AGRUPADOS (Packs)
    if (in_array('grouped', $types)) {
        // Obtenemos 3 simples creados para agruparlos
        $simples = get_posts(['post_type' => 'product', 'meta_key' => '_wpsheets_dummy', 'posts_per_page' => 3, 'fields' => 'ids']);

        for ($i=1; $i<=5; $i++) {
            $p = new WC_Product_Grouped();
            $p->set_name("Dummy Pack - Colección Agrupada {$i}");
            $p->set_status('publish');
            $p->set_description("Este es un producto agrupado. Permite al cliente comprar varios productos simples desde una misma página.");
            $p->set_sku("DMY-GRP-" . rand(1000, 9999));
            $p->set_category_ids([get_random_cat()]);

            if (!empty($simples)) {
                $p->set_children($simples);
            }

            if(!empty($img_id)) $p->set_image_id($img_id);
            $p->add_meta_data('_wpsheets_dummy', '1', true);
            $p->save();
            $created++;
        }
    }

    wp_send_json_success("Generados $created productos base (más sus variaciones).");
});

add_action('wp_ajax_wpsheets_delete_dummy_woo', function() {
    check_ajax_referer('wpsheets_ajax_nonce', 'nonce');

    $args = [
        'post_type' => ['product', 'product_variation'],
        'post_status' => 'any',
        'meta_key' => '_wpsheets_dummy',
        'meta_value' => '1',
        'posts_per_page' => -1,
        'fields' => 'ids'
    ];
    $products = get_posts($args);
    foreach($products as $pid) {
        wp_delete_post($pid, true); // true = force delete
    }
    wp_send_json_success('Borrados con éxito');
});


// AJAX: Inyectar a Google Sheets
add_action('wp_ajax_wpsheets_inject_sheet_dummies', function() {
    check_ajax_referer('wpsheets_ajax_nonce', 'nonce');
    $sid = get_option('wpsheets_spreadsheet_id');
    if (empty($sid)) wp_send_json_error('No tienes configurado tu ID de Google Sheets.');

    // 28 columns matching the Headers created previously
    $rows = [
        ['DUMMY-GS-1', 'Gorra Minimalista', 'gorra-min', 'publish', 'SKU-GS-1', '0', '0', 'visible', '50', 'instock', 'no', 'yes', '300', '250', '0.1', '15', '10', '5', 'taxable', '', 'simple', 'Accesorios', 'moda', '', '', '', '', ''],
        ['DUMMY-GS-2', 'Reloj Inteligente', 'rel-int', 'publish', 'SKU-GS-2', '0', '0', 'visible', '15', 'instock', 'no', 'yes', '1500', '', '0.3', '10', '10', '10', 'taxable', '', 'simple', 'Electrónica', 'gadget', '', '', '', '', ''],
        ['DUMMY-GS-3', 'Ebook Emprendimiento', 'ebook-emp', 'publish', 'SKU-GS-3', '1', '1', 'visible', '', 'instock', 'no', 'no', '200', '', '', '', '', '', 'taxable', '', 'simple', 'Digital', 'libro', '', '', '', '', '']
    ];

    $res = WPSheets_Google_API::update_sheet_data($sid, 'Productos_WooCommerce!A2', $rows);
    if (is_wp_error($res)) wp_send_json_error('Error API Google: ' . $res->get_error_message());

    wp_send_json_success('✅ ¡Éxito! Abre tu Google Sheets o el Data Grid y verás 3 productos listos para ser editados y sincronizados.');
});


add_action('wp_ajax_wpsheets_export_woo_mass', function() {
    check_ajax_referer('wpsheets_ajax_nonce', 'nonce');
    if (!class_exists('WooCommerce')) wp_send_json_error('WooCommerce no está activo');

    $sid = get_option('wpsheets_spreadsheet_id');
    if (empty($sid)) wp_send_json_error('No tienes configurado tu ID de Google Sheets.');

    $entity = sanitize_text_field($_POST['entity']);
    $sheet = sanitize_text_field($_POST['sheet']);

    if (empty($entity) || empty($sheet)) wp_send_json_error('Faltan parámetros de entidad o hoja.');

    $mapping_all = get_option('wpsheets_fields_mapping', []);
    $mapping = $mapping_all[$entity] ?? [];
    if (empty($mapping)) wp_send_json_error("No hay mapeo guardado para '$entity'. Ve a Campos Dinámicos y guárdalo primero.");

    // Leer encabezados de Google Sheets
    $headers_raw = WPSheets_Google_API::get_sheet_data($sid, "'" . $sheet . "'!1:1");
    if (is_wp_error($headers_raw) || empty($headers_raw[0])) {
        wp_send_json_error("No se pudieron leer los encabezados de la hoja '$sheet'.");
    }
    $headers = $headers_raw[0];

    $export_data = [$headers]; // La fila 1 son los encabezados

    // CASO 1: TAXONOMÍA
    if (strpos($entity, 'tax_') === 0) {
        $tax_slug = str_replace('tax_', '', $entity);
        $terms = get_terms(['taxonomy' => $tax_slug, 'hide_empty' => false]);

        if (!is_wp_error($terms) && !empty($terms)) {
            foreach ($terms as $term) {
                $row = array_fill(0, count($headers), '');
                $ws_id = get_term_meta($term->term_id, '_ws_import_id', true);
                if (!$ws_id) { $ws_id = uniqid('ws_'); update_term_meta($term->term_id, '_ws_import_id', $ws_id); }

                foreach ($headers as $i => $h) {
                    $safeCol = strtolower(preg_replace('/[^a-zA-Z0-9_]/', '_', $h));
                    $cfg = $mapping[$safeCol] ?? null;
                    if (!$cfg) continue;

                    if ($cfg['type'] === 'id') $row[$i] = $ws_id;
                    elseif ($cfg['type'] === 'tax_name') $row[$i] = $term->name;
                    elseif ($cfg['type'] === 'tax_slug') $row[$i] = $term->slug;
                    elseif ($cfg['type'] === 'tax_desc') $row[$i] = $term->description;
                    elseif ($cfg['type'] === 'image_url') {
                        $meta_key = $cfg['options']['meta_key'] ?? '';
                        if ($meta_key) {
                            $attach_id = get_term_meta($term->term_id, $meta_key, true);
                            if ($attach_id) $row[$i] = wp_get_attachment_url($attach_id);
                        }
                    }
                }
                $export_data[] = $row;
            }
        }
    } 
    // CASO 2: POST TYPES
    else {
        $posts = get_posts(['post_type' => $entity, 'posts_per_page' => -1, 'post_status' => 'any']);
        if (!empty($posts)) {
            foreach ($posts as $post) {
                $row = array_fill(0, count($headers), '');
                $ws_id = get_post_meta($post->ID, '_ws_import_id', true);
                if (!$ws_id) { $ws_id = uniqid('ws_'); update_post_meta($post->ID, '_ws_import_id', $ws_id); }

                $product = ($entity === 'product') ? wc_get_product($post->ID) : null;
                $order = ($entity === 'shop_order') ? wc_get_order($post->ID) : null;
                $coupon = ($entity === 'shop_coupon') ? new WC_Coupon($post->ID) : null;

                foreach ($headers as $i => $h) {
                    $safeCol = strtolower(preg_replace('/[^a-zA-Z0-9_]/', '_', $h));
                    $cfg = $mapping[$safeCol] ?? null;
                    if (!$cfg) continue;

                    $type = $cfg['type'];
                    $opts = $cfg['options'] ?? [];

                    if ($type === 'id') $row[$i] = $ws_id;
                    elseif ($type === 'wp_title') $row[$i] = $post->post_title;
                    elseif ($type === 'wp_status') $row[$i] = $post->post_status;
                    elseif ($type === 'wp_slug') $row[$i] = $post->post_name;
                    elseif ($type === 'wp_content') $row[$i] = $post->post_content;
                    elseif ($type === 'wp_excerpt') $row[$i] = $post->post_excerpt;
                    elseif ($type === 'taxonomy' && !empty($opts['tax_slug'])) {
                        $terms = get_the_terms($post->ID, $opts['tax_slug']);
                        if (!empty($terms) && !is_wp_error($terms)) {
                            $tnames = []; foreach($terms as $t) $tnames[] = $t->name;
                            $row[$i] = implode(', ', $tnames);
                        }
                    }
                    elseif ($type === 'meta') {
                        $meta_key = $opts['meta_key'] ?? '';
                        if ($meta_key) {
                            if ($product) {
                                if ($meta_key === '_price') $row[$i] = $product->get_price();
                                elseif ($meta_key === '_regular_price') $row[$i] = $product->get_regular_price();
                                elseif ($meta_key === '_sale_price') $row[$i] = $product->get_sale_price();
                                elseif ($meta_key === '_stock') $row[$i] = $product->get_stock_quantity();
                                elseif ($meta_key === '_stock_status') $row[$i] = $product->get_stock_status();
                                elseif ($meta_key === '_sku') $row[$i] = $product->get_sku();
                                elseif ($meta_key === '_weight') $row[$i] = $product->get_weight();
                                elseif ($meta_key === '_length') $row[$i] = $product->get_length();
                                elseif ($meta_key === '_width') $row[$i] = $product->get_width();
                                elseif ($meta_key === '_height') $row[$i] = $product->get_height();
                                else $row[$i] = get_post_meta($post->ID, $meta_key, true);
                            } elseif ($order) {
                                if ($meta_key === '_order_total') $row[$i] = $order->get_total();
                                elseif ($meta_key === '_order_currency') $row[$i] = $order->get_currency();
                                elseif ($meta_key === '_billing_first_name') $row[$i] = $order->get_billing_first_name();
                                elseif ($meta_key === '_billing_last_name') $row[$i] = $order->get_billing_last_name();
                                elseif ($meta_key === '_billing_email') $row[$i] = $order->get_billing_email();
                                else $row[$i] = get_post_meta($post->ID, $meta_key, true);
                            } elseif ($coupon) {
                                if ($meta_key === 'coupon_amount') $row[$i] = $coupon->get_amount();
                                elseif ($meta_key === 'discount_type') $row[$i] = $coupon->get_discount_type();
                                elseif ($meta_key === 'free_shipping') $row[$i] = $coupon->get_free_shipping() ? 'yes' : 'no';
                                elseif ($meta_key === 'date_expires') {
                                    $date = $coupon->get_date_expires();
                                    $row[$i] = $date ? $date->date('Y-m-d') : '';
                                }
                                else $row[$i] = get_post_meta($post->ID, $meta_key, true);
                            } else {
                                $row[$i] = get_post_meta($post->ID, $meta_key, true);
                            }
                        }
                    }
                }
                $export_data[] = $row;
            }
        }
    }

    // Limpiar hoja y subir los datos
    $range = "'" . $sheet . "'!A:ZZ";
    WPSheets_Google_API::clear_sheet($sid, $range);
    $update = WPSheets_Google_API::update_sheet_data($sid, $range, $export_data);

    if (is_wp_error($update)) wp_send_json_error('Error exportando a Google Sheets: ' . $update->get_error_message());

    $count = count($export_data) - 1;
    wp_send_json_success("Exportación completada con éxito. Se enviaron $count registros a la hoja '$sheet'.");
});
