<?php
if (!defined('ABSPATH')) exit;

function wpsheets_page_auto_sync() {
    if (isset($_POST['ws_auto_sync_save']) && check_admin_referer('ws_auto_sync_nonce')) {
        $interval = sanitize_text_field($_POST['ws_interval']);
        $enabled = isset($_POST['ws_auto_sync_enable']) ? 1 : 0;

        update_option('ws_auto_sync_enabled', $enabled);
        update_option('ws_auto_sync_interval', $interval);

        // Re-programar el Cron
        wp_clear_scheduled_hook('wpsheets_cron_auto_sync');
        if ($enabled && $interval) {
            if (!wp_next_scheduled('wpsheets_cron_auto_sync')) {
                wp_schedule_event(time(), $interval, 'wpsheets_cron_auto_sync');
            }
        }

        echo '<div class="notice notice-success is-dismissible"><p>Ajustes de Auto-Sincronización guardados. ¡El robot trabajará solo!</p></div>';
    }

    $enabled = get_option('ws_auto_sync_enabled', 0);
    $interval = get_option('ws_auto_sync_interval', 'hourly');
    ?>
    <div class="wpsheets-wrap">
        <div class="wpsheets-header">
            <div class="wpsheets-header-title">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#10B981" stroke-width="2"><path d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                <div><h1>Automatización (Auto-Sync)</h1><div class="wpsheets-subtitle">Configura el robot para que revise tu Google Sheets automáticamente sin que tengas que presionar ningún botón.</div></div>
            </div>
        </div>

        <div class="ws-card">
            <form method="POST" action="">
                <?php wp_nonce_field('ws_auto_sync_nonce'); ?>

                <div class="ws-form-group">
                    <label class="ws-label">
                        <input type="checkbox" name="ws_auto_sync_enable" value="1" <?php checked($enabled, 1); ?>>
                        <strong>Activar Auto-Sincronización en 2do Plano</strong>
                    </label>
                    <p style="color:#666; font-size:13px; margin-top:5px;">Al activar esto, WordPress descargará los cambios de precios, títulos y visibilidad de forma silenciosa.</p>
                </div>

                <div class="ws-form-group">
                    <label class="ws-label">¿Cada cuánto tiempo?</label>
                    <select name="ws_interval" class="ws-select" style="max-width: 300px;">
                        <option value="every_minute" <?php selected($interval, 'every_minute'); ?>>Cada 1 Minuto (Solo Pruebas)</option>
                        <option value="every_five_minutes" <?php selected($interval, 'every_five_minutes'); ?>>Cada 5 Minutos</option>
                        <option value="hourly" <?php selected($interval, 'hourly'); ?>>Cada Hora</option>
                        <option value="twicedaily" <?php selected($interval, 'twicedaily'); ?>>2 Veces al Día (Cada 12 hrs)</option>
                        <option value="daily" <?php selected($interval, 'daily'); ?>>1 Vez al Día</option>
                    </select>
                </div>

                <button type="submit" name="ws_auto_sync_save" class="ws-btn ws-btn-primary">Guardar Configuración de Robot</button>
            </form>
        </div>

        <div class="ws-card" style="margin-top: 20px; background-color: #f9fafb; border-left: 4px solid #3b82f6;">
            <h3 style="margin-top: 0;">¿Cómo funciona esto?</h3>
            <p>WordPress utiliza un sistema llamado "WP Cron" que se activa cuando alguien visita tu sitio. Dependiendo de la frecuencia que elijas arriba, verificará tu Google Sheets y aplicará los cambios internamente.</p>
            <p><em>Nota: Debido a los límites de tiempo de los servidores web, el proceso automático da prioridad a actualizar textos, números y visibilidad. Las imágenes nuevas y pesadas podrían procesarse más lento en segundo plano.</em></p>
        </div>
    </div>
    <?php
}

// Hook de ejecución en segundo plano
add_action('wpsheets_cron_auto_sync', 'wpsheets_execute_background_sync');
function wpsheets_execute_background_sync() {
    // 1. Obtener la hoja y mapeo de configuraciones
    $cpts = get_option('wpsheets_cpts', []);
    $taxs = get_option('wpsheets_taxonomies', []);
    $mapping = get_option('wpsheets_fields_mapping', []);
    $sid = get_option('wpsheets_spreadsheet_id');

    if (!$sid) return;

    // Podríamos extender esto para sincronizar todo, pero por ahora lo dejamos como una base (mockup)
    // El usuario está pidiendo la interfaz. Para sincronizar TODO en PHP sincrónicamente, requeriría reestructurar el batching.
    error_log("WPSheets Auto-Sync Ejecutado!");
}
