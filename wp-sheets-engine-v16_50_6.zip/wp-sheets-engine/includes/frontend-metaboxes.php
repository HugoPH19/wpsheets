<?php
if (!defined('ABSPATH')) exit;

/**
 * WP Sheets Engine – Metaboxes para Post Types registrados
 * Muestra los campos custom (precio, visibilidad, etc.) en el editor de WordPress.
 */
add_action('add_meta_boxes', 'wpsheets_register_metaboxes', 99);
function wpsheets_register_metaboxes() {
    $cpts = get_option('wpsheets_cpts', []);
    if (empty($cpts)) return;

    // Obtener todos los mapeos de la base de datos (estructura de la V13/16)
    $all_mappings = get_option('wpsheets_fields_mapping', []);

    foreach ($cpts as $cpt) {
        // En V13 el mapping se guarda usando el SLUG del cpt como llave
        $mapping = isset($all_mappings[$cpt['slug']]) ? $all_mappings[$cpt['slug']] : [];

        if (empty($mapping)) continue;

        // Filtrar: sólo campos que NO son nativos de WP (esos ya tienen UI nativa)
        $custom_fields = [];
        foreach ($mapping as $key => $field) {
            $type = isset($field['type']) ? $field['type'] : 'text';
            if (!in_array($type, ['wp_title', 'wp_content', 'wp_thumbnail', 'id', 'taxonomy', 'post_object'])) {
                $custom_fields[$key] = $field;
            }
        }
        if (empty($custom_fields)) continue;

        add_meta_box(
            'wpsheets_meta_' . $cpt['slug'],
            '📊 Campos de Sheets: ' . esc_html($cpt['singular']),
            'wpsheets_render_metabox',
            $cpt['slug'],
            'normal',
            'high',
            ['fields' => $custom_fields]
        );
    }
}

function wpsheets_render_metabox($post, $metabox) {
    $fields = $metabox['args']['fields'];
    wp_nonce_field('wpsheets_meta_save_' . $post->post_type, 'wpsheets_meta_nonce');
    ?>
    <style>
        .wpsheets-meta-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 20px; padding: 10px 0; }
        .wpsheets-meta-field label { display: block; font-weight: 600; font-size: 13px; color: #1E293B; margin-bottom: 6px; }
        .wpsheets-meta-field input[type=text],
        .wpsheets-meta-field input[type=number],
        .wpsheets-meta-field input[type=url],
        .wpsheets-meta-field input[type=email],
        .wpsheets-meta-field textarea { width: 100%; border: 1px solid #CBD5E1; border-radius: 4px; padding: 6px 10px; font-size: 14px; transition: border .15s; box-shadow: inset 0 1px 2px rgba(0,0,0,0.03); }
        .wpsheets-meta-field input:focus,
        .wpsheets-meta-field textarea:focus { border-color: #2563EB; outline: none; box-shadow: 0 0 0 1px #2563EB; }
        .wpsheets-meta-field .type-badge { font-size: 11px; color: #94A3B8; font-weight: 400; text-transform: none; margin-left: 6px; }
        .wpsheets-meta-img-preview { max-width: 100px; max-height: 100px; border: 1px solid #E2E8F0; border-radius: 4px; margin-top: 8px; display: block; object-fit: contain; }
    </style>
    <div class="wpsheets-meta-grid">
    <?php foreach ($fields as $key => $field): ?>
        <?php
        $value = get_post_meta($post->ID, $key, true);
        $label = ucwords(str_replace(['_', '-'], ' ', $key));
        $type  = isset($field['type']) ? $field['type'] : 'text';
        ?>
        <div class="wpsheets-meta-field">
            <label for="wpsheets_meta_<?php echo esc_attr($key); ?>">
                <?php echo esc_html($label); ?>
                <span class="type-badge">(<?php echo esc_html($type); ?>)</span>
            </label>
            <?php if ($type === 'textarea'): ?>
                <textarea id="wpsheets_meta_<?php echo esc_attr($key); ?>"
                          name="wpsheets_meta[<?php echo esc_attr($key); ?>]"
                          rows="3"><?php echo esc_textarea($value); ?></textarea>
            <?php elseif ($type === 'boolean'): ?>
                <label style="font-size:14px;font-weight:400;color:#334155;display:flex;align-items:center;gap:8px;margin-top:8px;">
                    <input type="checkbox"
                           id="wpsheets_meta_<?php echo esc_attr($key); ?>"
                           name="wpsheets_meta[<?php echo esc_attr($key); ?>]"
                           value="1" <?php checked((bool)$value); ?>>
                    Habilitado / Verdadero
                </label>
            <?php elseif ($type === 'number' || $type === 'number_price'): ?>
                <input type="number" step="any"
                       id="wpsheets_meta_<?php echo esc_attr($key); ?>"
                       name="wpsheets_meta[<?php echo esc_attr($key); ?>]"
                       value="<?php echo esc_attr($value); ?>">
            <?php elseif (in_array($type, ['image_url', 'image_wp'])): ?>
                <input type="url"
                       id="wpsheets_meta_<?php echo esc_attr($key); ?>"
                       name="wpsheets_meta[<?php echo esc_attr($key); ?>]"
                       value="<?php echo esc_url($value); ?>">
                <?php if ($value): ?>
                    <img src="<?php echo esc_url($value); ?>" class="wpsheets-meta-img-preview" alt="">
                <?php endif; ?>
            <?php else: ?>
                <input type="text"
                       id="wpsheets_meta_<?php echo esc_attr($key); ?>"
                       name="wpsheets_meta[<?php echo esc_attr($key); ?>]"
                       value="<?php echo esc_attr($value); ?>">
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
    </div>
    <p style="margin-top: 15px; color: #64748B; font-size: 13px;"><em>Los valores modificados aquí se reflejarán en tu web local. Serán sobrescritos por Google Sheets en la próxima sincronización general a menos que modifiques la celda respectiva.</em></p>
    <?php
}

add_action('save_post', 'wpsheets_save_metabox_data');
function wpsheets_save_metabox_data($post_id) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!isset($_POST['wpsheets_meta_nonce'])) return;
    if (!wp_verify_nonce($_POST['wpsheets_meta_nonce'], 'wpsheets_meta_save_' . get_post_type($post_id))) return;
    if (!current_user_can('edit_post', $post_id)) return;

    if (!isset($_POST['wpsheets_meta']) || !is_array($_POST['wpsheets_meta'])) return;

    foreach ($_POST['wpsheets_meta'] as $key => $value) {
        $clean_key = sanitize_text_field($key);
        update_post_meta($post_id, $clean_key, sanitize_text_field($value));
    }

    // Checkbox fields that are unchecked don't send POST data, so we must set them to 0
    $post_type = get_post_type($post_id);
    $cpts = get_option('wpsheets_cpts', []);
    $all_mappings = get_option('wpsheets_fields_mapping', []);

    foreach ($cpts as $cpt) {
        if ($cpt['slug'] !== $post_type) continue;
        $mapping = isset($all_mappings[$cpt['slug']]) ? $all_mappings[$cpt['slug']] : [];
        foreach ($mapping as $key => $field) {
            if (isset($field['type']) && $field['type'] === 'boolean') {
                if (!isset($_POST['wpsheets_meta'][$key])) {
                    update_post_meta($post_id, $key, 0);
                }
            }
        }
    }
}
