<?php
if (!defined('ABSPATH')) exit;

/**
 * Función principal para exportar un post individual a Google Sheets.
 */
function wpsheets_export_post_to_google($post_id) {
    if (wp_is_post_revision($post_id) || wp_is_post_autosave($post_id)) return;
    $post = get_post($post_id);
    if (!$post || $post->post_status === 'auto-draft') return;

    // Identificar si el post_type está mapeado
    $cpts = get_option('wpsheets_cpts', []);
    if (!is_array($cpts)) $cpts = [];
    if (class_exists('WooCommerce')) {
        $cpts[] = ['slug' => 'product', 'sheet' => 'Products_Woo'];
    }

    $tab = ''; $obj_slug = $post->post_type;
    foreach($cpts as $c) {
        if(isset($c['slug']) && $c['slug'] === $obj_slug) {
            $tab = $c['sheet'] ?? ''; break;
        }
    }
    if (empty($tab)) return;

    $mapping_all = get_option('wpsheets_fields_mapping', []);
    $mapping = $mapping_all[$obj_slug] ?? [];
    if (empty($mapping)) return;

    $sid = get_option('wpsheets_spreadsheet_id');
    if (empty($sid)) return;

    // Obtener o crear ID de importación
    $item_id = get_post_meta($post_id, '_ws_import_id', true);
    if (empty($item_id)) {
        $item_id = wpsheets_generate_post_id($obj_slug, $post_id);
        update_post_meta($post_id, '_ws_import_id', $item_id);
    }

    // 1. Obtener los encabezados de la hoja (A1:Z1)
    $headers_raw = WPSheets_Google_API::get_sheet_data($sid, $tab . '!1:1');
    if (is_wp_error($headers_raw) || empty($headers_raw[0])) return;
    $headers = $headers_raw[0];

    // 2. Mapear los datos de WP a la estructura de Google Sheets
    $row_values = array_fill(0, count($headers), '');

    // Helper object logic for WooCommerce
    $product = null;
    if ($obj_slug === 'product' && function_exists('wc_get_product')) {
        $product = wc_get_product($post_id);
    }

    
    // Construir los valores a insertar
    $mapped_data = ['wp_status_wordpress' => $post->post_status]; // siempre presente
    foreach($mapping as $safeCol => $config) {
        $type = $config['type'];
        $opts = $config['options'] ?? [];
        $val = '';

        if ($type === 'id') { $val = $item_id; }
        elseif ($type === 'wp_title') { $val = $post->post_title; }
        elseif ($type === 'wp_content') { $val = $post->post_content; }
        elseif ($type === 'wp_excerpt') { $val = $post->post_excerpt; }
        elseif ($type === 'wp_status') { $val = $post->post_status; }
        elseif ($type === 'wp_slug') { $val = $post->post_name; }
        elseif ($type === 'taxonomy') {
            $tax_slug = $opts['tax_slug'] ?? '';
            if ($tax_slug) {
                $terms = get_the_terms($post_id, $tax_slug);
                if (!empty($terms) && !is_wp_error($terms)) {
                    $term_names = [];
                    foreach($terms as $term) {
                        $term_names[] = $term->name;
                    }
                    $val = implode(', ', $term_names);
                }
            }
        }
        elseif ($type === 'meta' || $type === 'acf') {
            $meta_key = $opts['meta_key'] ?? '';
            if ($meta_key) {
                if ($product) {
                    $wc_getters = [
                        '_price'          => 'get_price',
                        '_regular_price'  => 'get_regular_price',
                        '_sale_price'     => 'get_sale_price',
                        '_stock'          => 'get_stock_quantity',
                        '_stock_status'   => 'get_stock_status',
                        '_sku'            => 'get_sku',
                        '_weight'         => 'get_weight',
                        '_length'         => 'get_length',
                        '_width'          => 'get_width',
                        '_height'         => 'get_height',
                        '_manage_stock'   => 'get_manage_stock',
                        '_backorders'     => 'get_backorders',
                        '_tax_status'     => 'get_tax_status',
                        '_tax_class'      => 'get_tax_class',
                        '_downloadable'   => 'get_downloadable',
                        '_virtual'        => 'get_virtual',
                        '_visibility'     => 'get_catalog_visibility',
                    ];
                    if (isset($wc_getters[$meta_key])) {
                        $getter = $wc_getters[$meta_key];
                        $raw = $product->$getter();
                        $val = is_bool($raw) ? ($raw ? 'yes' : 'no') : (string)($raw ?? '');
                    } else {
                        $val = get_post_meta($post_id, $meta_key, true);
                    }
                } else {
                    $val = get_post_meta($post_id, $meta_key, true);
                }
            }
        }
        // Fallback para tipos simples: leer de post_meta si aún no tenemos valor
        if ($val === '' && in_array($type, ['text', 'number', 'select', 'boolean', 'textarea', 'url', 'email'])) {
            $mk = $opts['meta_key'] ?? $safeCol;
            $raw = get_post_meta($post_id, $mk, true);
            if ($raw !== false && $raw !== null && $raw !== '') $val = (string)$raw;
        }
        $mapped_data[$safeCol] = $val;
    }


    // Colocar los valores en el orden de las columnas de Google
    $id_col_index = -1;
    foreach ($headers as $index => $raw_header) {
        $safeHeader = strtolower(preg_replace('/[^a-zA-Z0-9_]/', '_', $raw_header));
        if (isset($mapped_data[$safeHeader])) {
            $row_values[$index] = $mapped_data[$safeHeader];
        }
        if ($index === 0) { // Asumimos que A es el ID
            $id_col_index = 0;
            $row_values[0] = $item_id; // Forzar ID en la primera col
        }
    }

    // 3. Buscar si la fila ya existe (Solo buscar en columna A)
    $all_ids_raw = WPSheets_Google_API::get_sheet_data($sid, $tab . '!A:A');
    $row_to_update = -1;

    if (!is_wp_error($all_ids_raw) && !empty($all_ids_raw)) {
        foreach($all_ids_raw as $i => $row) {
            if (isset($row[0]) && trim($row[0]) === $item_id) {
                $row_to_update = $i + 1; // +1 porque sheets usa 1-index
                break;
            }
        }
    }

    // 4. Escribir en Google Sheets
    if ($row_to_update > 0) {
        // Actualizar fila existente
        WPSheets_Google_API::update_sheet_data($sid, $tab . '!A' . $row_to_update, [$row_values]);
    } else {
        // Añadir nueva fila
        WPSheets_Google_API::append_sheet_data($sid, $tab . '!A1', [$row_values]);
    }
}


// ============================================================
// GENERACIÓN DE IDs DETERMINÍSTICOS
// WooCommerce: mapa fijo (sin colisiones entre tipos Woo)
// CPTs/Taxonomías propias: Opción C (max 4 chars × 2 palabras)
// ============================================================

/** Prefijo para CPTs y taxonomías personalizadas (Opción C) */
function wpsheets_make_prefix_custom($slug) {
    $slug  = strtolower(preg_replace('/[^a-z0-9_-]/', '', $slug));
    $parts = preg_split('/[_\-]+/', $slug);
    $parts = array_filter($parts);
    $parts = array_slice(array_values($parts), 0, 2);
    return implode('_', array_map(fn($p) => strtoupper(substr($p, 0, 4)), $parts));
}

/** Prefijo para entidades WooCommerce (mapa fijo + fallback) */
function wpsheets_make_prefix_woo($slug) {
    $woo_map = [
        'product'            => 'PROD',
        'product_cat'        => 'WCAT',
        'product_tag'        => 'WTAG',
        'pwb-brand'          => 'WBRD',
        'product_brands'     => 'WBRD',
        'yith_product_brand' => 'WBRD',
        'product_brand'      => 'WBRD',
        'shop_order'         => 'WORD',
        'shop_coupon'        => 'WCPN',
    ];
    if (isset($woo_map[$slug])) return $woo_map[$slug];
    // Atributos pa_*: Opción C sobre el nombre del atributo
    if (str_starts_with($slug, 'pa_')) {
        return wpsheets_make_prefix_custom(substr($slug, 3));
    }
    // Fallback a Opción C
    return wpsheets_make_prefix_custom($slug);
}

/** Generar ID para un post (CPT propio o Woo) */
function wpsheets_generate_post_id($post_type, $post_id) {
    $woo_types = ['product', 'shop_order', 'shop_coupon'];
    $prefix = in_array($post_type, $woo_types)
        ? wpsheets_make_prefix_woo($post_type)
        : wpsheets_make_prefix_custom($post_type);
    return $prefix . '-' . $post_id;
}

/** Generar ID para un término (taxonomía propia o Woo) */
function wpsheets_generate_term_id($taxonomy, $term_id) {
    $woo_taxs = ['product_cat', 'product_tag', 'product_brands', 'pwb-brand',
                 'yith_product_brand', 'product_brand'];
    $is_woo = in_array($taxonomy, $woo_taxs) || str_starts_with($taxonomy, 'pa_');
    $prefix = $is_woo
        ? wpsheets_make_prefix_woo($taxonomy)
        : wpsheets_make_prefix_custom($taxonomy);
    return $prefix . '-' . $term_id;
}

// Enganchar al Guardar Post (Pero evitar loops infinitos)
add_action('save_post', function($post_id, $post, $update) {
    // Evitar que el webhook dispare un save_post de vuelta a Google Sheets
    if (defined('WPSHEETS_IS_WEBHOOK') && WPSHEETS_IS_WEBHOOK) return;
    if (defined('WPSHEETS_IS_SYNCING') && WPSHEETS_IS_SYNCING) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    // Evitar loop si la petición viene del cron o del grid sync
    if (isset($_POST['action']) && $_POST['action'] === 'wpsheets_sync_process') return;

    wpsheets_export_post_to_google($post_id);
}, 10, 3);

// Enganchar a ventas de WooCommerce
if (class_exists('WooCommerce')) {
    add_action('woocommerce_reduce_order_stock', function($order) {
        if (defined('WPSHEETS_IS_WEBHOOK') && WPSHEETS_IS_WEBHOOK) return;
        foreach ($order->get_items() as $item) {
            $product_id = $item->get_product_id();
            if ($product_id) wpsheets_export_post_to_google($product_id);
        }
    });
}


// ============================================================
// EXPORTACIÓN DE TAXONOMÍAS (WP → Google Sheets)
// Prompt 6: created_term / edited_term hooks
// ============================================================
function wpsheets_export_term_to_google($term_id, $taxonomy) {
    $sid = get_option('wpsheets_spreadsheet_id');
    if (empty($sid)) return;

    // Determinar hoja destino
    $tab = '';

    // Taxonomías del plugin (usuario)
    $plugin_taxs = get_option('wpsheets_taxonomies', []);
    if (is_array($plugin_taxs)) {
        foreach ($plugin_taxs as $t) {
            if (isset($t['slug']) && $t['slug'] === $taxonomy && !empty($t['sheet'])) {
                $tab = $t['sheet']; break;
            }
        }
    }

    // WooCommerce
    if (empty($tab) && class_exists('WooCommerce')) {
        if ($taxonomy === 'product_cat') $tab = 'Categories_Woo';
        elseif ($taxonomy === 'product_tag') $tab = 'Tags_Woo';
        elseif (strpos($taxonomy, 'pa_') === 0) $tab = 'Attributes_Woo';
        else {
            $brand_slugs = ['product_brands', 'pwb-brand', 'yith_product_brand', 'product_brand'];
            foreach ($brand_slugs as $bs) {
                if (strpos($taxonomy, $bs) !== false) { $tab = 'Brands_Woo'; break; }
            }
        }
    }

    if (empty($tab)) return;

    // Clave de mapeo
    $mapping_key = 'tax_' . $taxonomy;
    if (strpos($taxonomy, 'pa_') === 0)                  $mapping_key = 'tax_woo_attributes';
    $brand_slugs2 = ['product_brands', 'pwb-brand', 'yith_product_brand', 'product_brand'];
    foreach ($brand_slugs2 as $bs) {
        if (strpos($taxonomy, $bs) !== false) { $mapping_key = 'tax_brands_woo'; break; }
    }

    $mapping_all = get_option('wpsheets_fields_mapping', []);
    $mapping = $mapping_all[$mapping_key] ?? ($mapping_all['tax_' . $taxonomy] ?? []);
    if (empty($mapping)) return;

    // Obtener o crear ID de importación
    $item_id = get_term_meta($term_id, '_ws_import_id', true);
    if (empty($item_id)) {
        // Buscar si ya existe en la hoja por nombre para evitar duplicar
        $term_obj_check = get_term($term_id, $taxonomy);
        $col_a_check = WPSheets_Google_API::get_sheet_data($sid, "'" . $tab . "'!A1:C");
        if (!is_wp_error($col_a_check) && count($col_a_check) > 1) {
            $check_headers = array_map('strtolower', array_map('trim', $col_a_check[0]));
            $nc = array_search('tax_name', $check_headers);
            foreach (array_slice($col_a_check, 1) as $cr) {
                if ($nc !== false && isset($cr[$nc]) && strtolower(trim($cr[$nc])) === strtolower($term_obj_check->name) && !empty($cr[0])) {
                    $item_id = trim($cr[0]);
                    update_term_meta($term_id, '_ws_import_id', $item_id);
                    break;
                }
            }
        }
        if (empty($item_id)) {
            $item_id = wpsheets_generate_term_id($taxonomy, $term_id);
            update_term_meta($term_id, '_ws_import_id', $item_id);
        }
    }

    $term = get_term($term_id, $taxonomy);
    if (!$term || is_wp_error($term)) return;

    // Leer encabezados de la hoja
    $headers_raw = WPSheets_Google_API::get_sheet_data($sid, "'" . $tab . "'!1:1");
    if (is_wp_error($headers_raw) || empty($headers_raw[0])) return;
    $headers = $headers_raw[0];

    // Construir datos mapeados
    $mapped_data = ['wp_status_wordpress' => 'publish']; // estado de términos activos
    foreach ($mapping as $safeCol => $config) {
        $type = $config['type'];
        $opts = $config['options'] ?? [];
        $val  = '';

        if ($type === 'id')          { $val = $item_id; }
        elseif ($type === 'tax_name') { $val = $term->name; }
        elseif ($type === 'tax_slug') { $val = $term->slug; }
        elseif ($type === 'tax_desc') { $val = $term->description; }
        elseif ($type === 'tax_parent') {
            if ($term->parent > 0) {
                $parent_term = get_term($term->parent, $taxonomy);
                $val = (!is_wp_error($parent_term) && $parent_term) ? $parent_term->name : '';
            }
            // Para Attributes_Woo: attribute_parent = nombre del atributo pa_*
            if ($safeCol === 'attribute_parent' && strpos($taxonomy, 'pa_') === 0) {
                if (function_exists('wc_get_attribute_taxonomies')) {
                    $attr_name = str_replace('pa_', '', $taxonomy);
                    foreach (wc_get_attribute_taxonomies() as $attr) {
                        if ($attr->attribute_name === $attr_name) { $val = $attr->attribute_label; break; }
                    }
                }
                if (empty($val)) $val = $taxonomy; // fallback al slug
            }
        }
        elseif ($type === 'meta') {
            $mk = $opts['meta_key'] ?? '';
            if ($mk) $val = get_term_meta($term_id, $mk, true);
        }
        elseif ($type === 'image_url') {
            $thumb_id = get_term_meta($term_id, 'thumbnail_id', true);
            if ($thumb_id) $val = wp_get_attachment_url($thumb_id) ?: '';
        }

        $mapped_data[$safeCol] = $val;
    }

    // Ordenar valores según encabezados de Google Sheets
    $row_values = array_fill(0, count($headers), '');
    foreach ($headers as $index => $raw_header) {
        $safe = strtolower(preg_replace('/[^a-zA-Z0-9_]/', '_', $raw_header));
        if (isset($mapped_data[$safe])) $row_values[$index] = $mapped_data[$safe];
        if ($index === 0) $row_values[0] = $item_id; // Forzar ID en col A
    }

    // Buscar fila existente en la hoja
    $all_ids = WPSheets_Google_API::get_sheet_data($sid, "'" . $tab . "'!A:A");
    $row_to_update = -1;
    if (!is_wp_error($all_ids) && !empty($all_ids)) {
        foreach ($all_ids as $i => $row) {
            if (isset($row[0]) && trim($row[0]) === $item_id) { $row_to_update = $i + 1; break; }
        }
    }

    if ($row_to_update > 0) {
        WPSheets_Google_API::update_sheet_data($sid, "'" . $tab . "'!A" . $row_to_update, [$row_values]);
    } else {
        WPSheets_Google_API::append_sheet_data($sid, "'" . $tab . "'!A1", [$row_values]);
    }
}

// Hooks para términos (Prompt 6)
add_action('created_term', function($term_id, $tt_id, $taxonomy) {
    if (defined('WPSHEETS_IS_WEBHOOK') && WPSHEETS_IS_WEBHOOK) return;
    if (defined('WPSHEETS_IS_SYNCING') && WPSHEETS_IS_SYNCING) return;
    wpsheets_export_term_to_google($term_id, $taxonomy);
}, 10, 3);

add_action('edited_term', function($term_id, $tt_id, $taxonomy) {
    if (defined('WPSHEETS_IS_WEBHOOK') && WPSHEETS_IS_WEBHOOK) return;
    if (defined('WPSHEETS_IS_SYNCING') && WPSHEETS_IS_SYNCING) return;
    wpsheets_export_term_to_google($term_id, $taxonomy);
}, 10, 3);


// ============================================================
// HELPER: Encontrar fila por backendId y borrarla de Sheets
// ============================================================
function wpsheets_delete_row_from_sheet($sid, $tab, $backend_id) {
    // 1. Leer columna A para encontrar la fila
    $col_a = WPSheets_Google_API::get_sheet_data($sid, "'" . $tab . "'!A:A");
    if (is_wp_error($col_a) || empty($col_a)) return false;

    $row_index = -1;
    foreach ($col_a as $i => $row) {
        if (isset($row[0]) && trim($row[0]) === $backend_id) {
            $row_index = $i; break; // 0-based index
        }
    }
    if ($row_index < 1) return false; // fila 0 = header, no borrar

    // 2. Obtener sheetId numérico
    $token = WPSheets_Google_API::get_access_token();
    if (is_wp_error($token)) return false;
    $meta = wp_remote_get("https://sheets.googleapis.com/v4/spreadsheets/{$sid}?fields=sheets.properties", [
        'headers' => ['Authorization' => 'Bearer ' . $token]
    ]);
    if (is_wp_error($meta)) return false;
    $meta_body = json_decode(wp_remote_retrieve_body($meta), true);
    $sheet_id = -1;
    foreach ($meta_body['sheets'] ?? [] as $s) {
        if ($s['properties']['title'] === $tab) { $sheet_id = $s['properties']['sheetId']; break; }
    }
    if ($sheet_id < 0) return false;

    // 3. Borrar la fila (row_index es 0-based, API también)
    return WPSheets_Google_API::delete_dimension($sid, $sheet_id, 'ROWS', $row_index);
}


// ============================================================
// HELPER: En un UPDATE de fila existente, preservar columnas
// de control (wp_status_wordpress, view_display) que el usuario
// puede haber modificado manualmente en Google Sheets.
// ============================================================
function wpsheets_preserve_control_cols(&$row_values, $headers, $existing_row_data) {
    $control_cols = ['wp_status_wordpress', 'view_display'];
    foreach ($headers as $idx => $raw_header) {
        $safe = strtolower(preg_replace('/[^a-zA-Z0-9_]/', '_', $raw_header));
        if (in_array($safe, $control_cols)) {
            // Si la hoja ya tenía un valor en esta columna, conservarlo
            $current_val = isset($existing_row_data[$idx]) ? trim($existing_row_data[$idx]) : '';
            if ($current_val !== '') {
                $row_values[$idx] = $current_val;
            }
            // Si estaba vacío, poner default
            elseif ($row_values[$idx] === '' || $row_values[$idx] === false) {
                $row_values[$idx] = ($safe === 'view_display') ? 'TRUE' : 'publish';
            }
        }
    }
}

// ============================================================
// BULK EXPORT: Exportar todos los posts de un CPT a Sheets
// Devuelve el número de registros exportados
// ============================================================
function wpsheets_bulk_export_cpt($post_type, $tab, $mapping_key) {
    $sid = get_option('wpsheets_spreadsheet_id');
    if (empty($sid)) return 0;

    $mapping_all = get_option('wpsheets_fields_mapping', []);
    $mapping = $mapping_all[$mapping_key] ?? [];
    if (empty($mapping)) return 0;

    // Leer encabezados de la hoja
    $headers_raw = WPSheets_Google_API::get_sheet_data($sid, "'" . $tab . "'!1:1");
    if (is_wp_error($headers_raw) || empty($headers_raw[0])) return 0;
    $headers = $headers_raw[0];

    // Leer IDs existentes en la hoja para no duplicar
    // Leer hoja completa una sola vez: para IDs existentes Y valores actuales de control cols
    $sheet_full_raw = WPSheets_Google_API::get_sheet_data($sid, "'" . $tab . "'!A1:ZZ");
    $existing_ids   = [];  // id => true
    $existing_rows  = [];  // id => [col0, col1, col2, ...]  (valores actuales en Sheets)
    if (!is_wp_error($sheet_full_raw) && count($sheet_full_raw) > 1) {
        for ($ri = 1; $ri < count($sheet_full_raw); $ri++) {
            $r = $sheet_full_raw[$ri];
            $rid = isset($r[0]) ? trim($r[0]) : '';
            if ($rid !== '') {
                $existing_ids[$rid]  = true;
                $existing_rows[$rid] = ['row_num' => $ri + 1, 'data' => $r];
            }
        }
    }

    $posts = get_posts([
        'post_type'      => $post_type,
        'post_status'    => 'any',
        'posts_per_page' => -1,
        'fields'         => 'ids',
    ]);

    $exported = 0;
    foreach ($posts as $post_id) {
        $post = get_post($post_id);
        if (!$post) continue;

        // Obtener o crear backendId
        $item_id = get_post_meta($post_id, '_ws_import_id', true);
        if (empty($item_id)) {
            $item_id = wpsheets_generate_post_id($post_type, $post_id);
            update_post_meta($post_id, '_ws_import_id', $item_id);
        }

        $product = null;
        if ($post_type === 'product' && function_exists('wc_get_product')) {
            $product = wc_get_product($post_id);
        }

        // Construir fila
        $mapped_data = ['wp_status_wordpress' => $post->post_status];
        foreach ($mapping as $safeCol => $config) {
            $type = $config['type'];
            $opts = $config['options'] ?? [];
            $val  = '';

            if ($type === 'id')             $val = $item_id;
            elseif ($type === 'wp_title')   $val = $post->post_title;
            elseif ($type === 'wp_content') $val = wp_strip_all_tags($post->post_content);
            elseif ($type === 'wp_excerpt') $val = $post->post_excerpt;
            elseif ($type === 'wp_status')  $val = $post->post_status;
            elseif ($type === 'wp_slug')    $val = $post->post_name;
            elseif ($type === 'wp_thumbnail') {
                $thumb_id = get_post_thumbnail_id($post_id);
                $val = $thumb_id ? wp_get_attachment_url($thumb_id) : '';
            }
            elseif ($type === 'taxonomy') {
                $tax_slug = $opts['tax_target'] ?? ($opts['tax_slug'] ?? '');
                if ($tax_slug) {
                    $terms = get_the_terms($post_id, $tax_slug);
                    if (!empty($terms) && !is_wp_error($terms)) {
                        $val = implode(', ', wp_list_pluck($terms, 'name'));
                    }
                }
            }
            elseif ($type === 'meta') {
                $mk = $opts['meta_key'] ?? '';
                if ($mk && $product) {
                    $getter_map = [
                        '_price'          => 'get_price',
                        '_regular_price'  => 'get_regular_price',
                        '_sale_price'     => 'get_sale_price',
                        '_stock'          => 'get_stock_quantity',
                        '_stock_status'   => 'get_stock_status',
                        '_sku'            => 'get_sku',
                        '_weight'         => 'get_weight',
                        '_length'         => 'get_length',
                        '_width'          => 'get_width',
                        '_height'         => 'get_height',
                        '_manage_stock'   => 'get_manage_stock',
                        '_backorders'     => 'get_backorders',
                        '_tax_status'     => 'get_tax_status',
                        '_tax_class'      => 'get_tax_class',
                        '_downloadable'   => 'get_downloadable',
                        '_virtual'        => 'get_virtual',
                        '_visibility'     => 'get_catalog_visibility',
                    ];
                    if (isset($getter_map[$mk])) {
                        $getter = $getter_map[$mk];
                        $raw = $product->$getter();
                        $val = is_bool($raw) ? ($raw ? 'yes' : 'no') : (string)($raw ?? '');
                    } else {
                        $val = get_post_meta($post_id, $mk, true);
                    }
                } elseif ($mk) {
                    $val = get_post_meta($post_id, $mk, true);
                }
            }
            $mapped_data[$safeCol] = (string)($val ?? '');
        }

        $row_values = array_fill(0, count($headers), '');
        foreach ($headers as $idx => $raw_header) {
            $safe = strtolower(preg_replace('/[^a-zA-Z0-9_]/', '_', $raw_header));
            if (isset($mapped_data[$safe])) $row_values[$idx] = $mapped_data[$safe];
            if ($idx === 0) $row_values[0] = $item_id;
        }

        if (isset($existing_ids[$item_id])) {
            // UPDATE: preservar wp_status_wordpress y view_display que el usuario puede haber editado
            $current_data = $existing_rows[$item_id]['data'] ?? [];
            wpsheets_preserve_control_cols($row_values, $headers, $current_data);
            $row_num = $existing_rows[$item_id]['row_num'] ?? -1;
            if ($row_num > 1) {
                WPSheets_Google_API::update_sheet_data($sid, "'" . $tab . "'!A" . $row_num, [$row_values]);
            }
        } else {
            // INSERT: poner defaults en columnas de control
            foreach ($headers as $idx => $raw_h) {
                $safe_h = strtolower(preg_replace('/[^a-zA-Z0-9_]/', '_', $raw_h));
                if ($safe_h === 'view_display' && ($row_values[$idx] === '' || $row_values[$idx] === false)) {
                    $row_values[$idx] = 'TRUE';
                }
            }
            WPSheets_Google_API::append_sheet_data($sid, "'" . $tab . "'!A1", [$row_values]);
            $existing_ids[$item_id] = true;
        }
        $exported++;
    }
    return $exported;
}

// ============================================================
// BULK EXPORT: Exportar todos los términos de una taxonomía a Sheets
// ============================================================
function wpsheets_bulk_export_taxonomy($taxonomy, $tab, $mapping_key) {
    $sid = get_option('wpsheets_spreadsheet_id');
    if (empty($sid)) return 0;

    $mapping_all = get_option('wpsheets_fields_mapping', []);
    $mapping = $mapping_all[$mapping_key] ?? ($mapping_all['tax_' . $taxonomy] ?? []);
    if (empty($mapping)) return 0;

    $headers_raw = WPSheets_Google_API::get_sheet_data($sid, "'" . $tab . "'!1:1");
    if (is_wp_error($headers_raw) || empty($headers_raw[0])) return 0;
    $headers = $headers_raw[0];

    $existing_ids_raw = WPSheets_Google_API::get_sheet_data($sid, "'" . $tab . "'!A:A");
    $existing_ids = [];
    if (!is_wp_error($existing_ids_raw)) {
        foreach ($existing_ids_raw as $r) {
            if (!empty($r[0])) $existing_ids[$r[0]] = true;
        }
    }

    $terms = get_terms(['taxonomy' => $taxonomy, 'hide_empty' => false]);
    if (is_wp_error($terms) || empty($terms)) return 0;

    // Leer hoja completa para detectar duplicados por nombre/slug
    $sheet_all_raw = WPSheets_Google_API::get_sheet_data($sid, "'" . $tab . "'!A1:ZZ");
    $sheet_rows_by_name = [];  // nombre_lower → [row_index, existing_id]
    $sheet_rows_by_slug = [];  // slug_lower   → [row_index, existing_id]
    if (!is_wp_error($sheet_all_raw) && count($sheet_all_raw) > 1) {
        $sh_headers = array_map('strtolower', array_map('trim', $sheet_all_raw[0]));
        $name_col = array_search('tax_name', $sh_headers);
        $slug_col = array_search('tax_slug', $sh_headers);
        // También buscar columnas con nombre de la taxonomía (backendId puede estar mapeado distinto)
        if ($name_col === false) {
            foreach ($sh_headers as $hi => $hv) {
                if (strpos($hv, 'nombre') !== false || strpos($hv, 'name') !== false) { $name_col = $hi; break; }
            }
        }
        for ($ri = 1; $ri < count($sheet_all_raw); $ri++) {
            $sh_row = $sheet_all_raw[$ri];
            $sh_id  = isset($sh_row[0]) ? trim($sh_row[0]) : '';
            if (empty($sh_id)) continue;
            if ($name_col !== false && isset($sh_row[$name_col])) {
                $sheet_rows_by_name[strtolower(trim($sh_row[$name_col]))] = ['row' => $ri + 1, 'id' => $sh_id];
            }
            if ($slug_col !== false && isset($sh_row[$slug_col])) {
                $sheet_rows_by_slug[strtolower(trim($sh_row[$slug_col]))] = ['row' => $ri + 1, 'id' => $sh_id];
            }
        }
    }

    // Construir índice de filas existentes con sus datos actuales
    $existing_rows = [];
    if (!is_wp_error($sheet_all_raw) && count($sheet_all_raw) > 1) {
        for ($ri = 1; $ri < count($sheet_all_raw); $ri++) {
            $er = $sheet_all_raw[$ri];
            $eid = isset($er[0]) ? trim($er[0]) : '';
            if ($eid !== '') {
                $existing_rows[$eid] = ['row_num' => $ri + 1, 'data' => $er];
            }
        }
    }

    $exported = 0;
    foreach ($terms as $term) {
        $item_id = get_term_meta($term->term_id, '_ws_import_id', true);
        if (empty($item_id)) {
            // Buscar si la hoja ya tiene este término por nombre o slug
            $name_key = strtolower($term->name);
            $slug_key = strtolower($term->slug);
            if (isset($sheet_rows_by_name[$name_key])) {
                // Adoptar el ID existente en la hoja
                $item_id = $sheet_rows_by_name[$name_key]['id'];
                update_term_meta($term->term_id, '_ws_import_id', $item_id);
                // Marcar como existente para actualizar, no duplicar
                $existing_ids[$item_id] = true;
            } elseif (isset($sheet_rows_by_slug[$slug_key])) {
                $item_id = $sheet_rows_by_slug[$slug_key]['id'];
                update_term_meta($term->term_id, '_ws_import_id', $item_id);
                $existing_ids[$item_id] = true;
            } else {
                // Generar nuevo ID solo si no existe en la hoja
                $item_id = wpsheets_generate_term_id($taxonomy, $term->term_id);
                update_term_meta($term->term_id, '_ws_import_id', $item_id);
            }
        }

        $mapped_data = ['wp_status_wordpress' => 'publish'];
        foreach ($mapping as $safeCol => $config) {
            $type = $config['type'];
            $opts = $config['options'] ?? [];
            $val  = '';

            if ($type === 'id')           $val = $item_id;
            elseif ($type === 'tax_name') $val = $term->name;
            elseif ($type === 'tax_slug') $val = $term->slug;
            elseif ($type === 'tax_desc') $val = $term->description;
            elseif ($type === 'tax_parent') {
                // Categoría padre: nombre del término padre
                if ($term->parent > 0) {
                    $parent = get_term($term->parent, $taxonomy);
                    $val = (!is_wp_error($parent) && $parent) ? $parent->name : '';
                }
                // attribute_parent: nombre del atributo (pa_*) para Attributes_Woo
                if ($safeCol === 'attribute_parent' && strpos($taxonomy, 'pa_') === 0) {
                    if (function_exists('wc_get_attribute_taxonomies')) {
                        $attr_name = str_replace('pa_', '', $taxonomy);
                        foreach (wc_get_attribute_taxonomies() as $attr) {
                            if ($attr->attribute_name === $attr_name) { $val = $attr->attribute_label; break; }
                        }
                    }
                    if (empty($val)) $val = $taxonomy;
                }
            }
            elseif ($type === 'meta') {
                $mk = $opts['meta_key'] ?? '';
                if ($mk) $val = get_term_meta($term->term_id, $mk, true);
            }
            elseif ($type === 'image_url') {
                $thumb_id = get_term_meta($term->term_id, 'thumbnail_id', true);
                if ($thumb_id) $val = wp_get_attachment_url($thumb_id) ?: '';
            }
            $mapped_data[$safeCol] = (string)($val ?? '');
        }

        $row_values = array_fill(0, count($headers), '');
        foreach ($headers as $idx => $raw_header) {
            $safe = strtolower(preg_replace('/[^a-zA-Z0-9_]/', '_', $raw_header));
            if (isset($mapped_data[$safe])) $row_values[$idx] = $mapped_data[$safe];
            if ($idx === 0) $row_values[0] = $item_id;
        }

        if (isset($existing_ids[$item_id])) {
            // UPDATE: preservar wp_status_wordpress y view_display
            $current_data = $existing_rows[$item_id]['data'] ?? [];
            wpsheets_preserve_control_cols($row_values, $headers, $current_data);
            $row_num = $existing_rows[$item_id]['row_num'] ?? -1;
            if ($row_num > 1) {
                WPSheets_Google_API::update_sheet_data($sid, "'" . $tab . "'!A" . $row_num, [$row_values]);
            }
        } else {
            // INSERT: poner defaults en columnas de control
            foreach ($headers as $idx => $raw_h) {
                $safe_h = strtolower(preg_replace('/[^a-zA-Z0-9_]/', '_', $raw_h));
                if ($safe_h === 'view_display' && ($row_values[$idx] === '' || $row_values[$idx] === false)) {
                    $row_values[$idx] = 'TRUE';
                }
            }
            WPSheets_Google_API::append_sheet_data($sid, "'" . $tab . "'!A1", [$row_values]);
            $existing_ids[$item_id] = true;
        }
        $exported++;
    }
    return $exported;
}


// ============================================================
// HELPER: Actualizar celda wp_status_wordpress en Sheets
// WP → Sheets: en lugar de borrar la fila, cambiamos el estado
// ============================================================
function wpsheets_update_status_in_sheet($sid, $tab, $backend_id, $new_status) {
    // 1. Leer columna A para encontrar la fila
    $col_a = WPSheets_Google_API::get_sheet_data($sid, "'" . $tab . "'!A:A");
    if (is_wp_error($col_a) || empty($col_a)) return false;

    $row_num = -1;
    foreach ($col_a as $i => $row) {
        if (isset($row[0]) && trim($row[0]) === $backend_id) { $row_num = $i + 1; break; }
    }
    if ($row_num < 2) return false; // No encontrada o es el encabezado

    // 2. Leer fila 1 para saber en qué columna está wp_status_wordpress
    $headers_raw = WPSheets_Google_API::get_sheet_data($sid, "'" . $tab . "'!1:1");
    if (is_wp_error($headers_raw) || empty($headers_raw[0])) return false;
    $headers = $headers_raw[0];

    $status_col_letter = '';
    foreach ($headers as $idx => $h) {
        if (trim($h) === 'wp_status_wordpress') {
            // Convertir índice numérico a letra de columna
            $n = $idx;
            $letter = '';
            while ($n >= 0) { $letter = chr($n % 26 + 65) . $letter; $n = intval($n / 26) - 1; }
            $status_col_letter = $letter;
            break;
        }
    }
    if (empty($status_col_letter)) return false;

    // 3. Escribir el nuevo estado en esa celda
    $range = "'" . $tab . "'!" . $status_col_letter . $row_num;
    return WPSheets_Google_API::update_sheet_data($sid, $range, [[$new_status]]);
}

// Helper: dado un post_type, retorna el nombre de la hoja
function wpsheets_get_tab_for_post_type($post_type) {
    $cpts = get_option('wpsheets_cpts', []);
    if (!is_array($cpts)) $cpts = [];
    if (class_exists('WooCommerce')) {
        $cpts[] = ['slug' => 'product',     'sheet' => 'Products_Woo'];
        $cpts[] = ['slug' => 'shop_order',  'sheet' => 'Orders_Woo'];
        $cpts[] = ['slug' => 'shop_coupon', 'sheet' => 'Coupons_Woo'];
    }
    foreach ($cpts as $cpt) {
        if (isset($cpt['slug']) && $cpt['slug'] === $post_type && !empty($cpt['sheet'])) return $cpt['sheet'];
    }
    return '';
}

// Helper: dado un taxonomy slug, retorna el nombre de la hoja
function wpsheets_get_tab_for_taxonomy($taxonomy) {
    $plugin_taxs = get_option('wpsheets_taxonomies', []);
    if (is_array($plugin_taxs)) {
        foreach ($plugin_taxs as $t) {
            if (isset($t['slug']) && $t['slug'] === $taxonomy && !empty($t['sheet'])) return $t['sheet'];
        }
    }
    if (class_exists('WooCommerce')) {
        if ($taxonomy === 'product_cat') return 'Categories_Woo';
        if ($taxonomy === 'product_tag') return 'Tags_Woo';
        if (strpos($taxonomy, 'pa_') === 0) return 'Attributes_Woo';
        foreach (['product_brands', 'pwb-brand', 'yith_product_brand', 'product_brand'] as $bs) {
            if (strpos($taxonomy, $bs) !== false) return 'Brands_Woo';
        }
    }
    return '';
}
// ============================================================
// WP → SHEETS: Estado de vida del registro
// En lugar de borrar filas (rompería el historial),
// actualizamos la columna wp_status_wordpress:
//   - trash   → cuando el post/término se envía a papelera
//   - publish → cuando se restaura o publica
// ============================================================

// Post enviado a papelera desde WordPress
add_action('wp_trash_post', function($post_id) {
    if (defined('WPSHEETS_IS_WEBHOOK') && WPSHEETS_IS_WEBHOOK) return;
    $sid = get_option('wpsheets_spreadsheet_id');
    if (empty($sid)) return;
    $item_id = get_post_meta($post_id, '_ws_import_id', true);
    if (empty($item_id)) return;
    $post = get_post($post_id);
    if (!$post) return;
    $tab = wpsheets_get_tab_for_post_type($post->post_type);
    if (empty($tab)) return;
    wpsheets_update_status_in_sheet($sid, $tab, $item_id, 'trash');
}, 10, 1);

// Post restaurado desde papelera
add_action('untrashed_post', function($post_id) {
    if (defined('WPSHEETS_IS_WEBHOOK') && WPSHEETS_IS_WEBHOOK) return;
    $sid = get_option('wpsheets_spreadsheet_id');
    if (empty($sid)) return;
    $item_id = get_post_meta($post_id, '_ws_import_id', true);
    if (empty($item_id)) return;
    $post = get_post($post_id);
    if (!$post) return;
    $tab = wpsheets_get_tab_for_post_type($post->post_type);
    if (empty($tab)) return;
    wpsheets_update_status_in_sheet($sid, $tab, $item_id, 'publish');
}, 10, 1);

// Término eliminado desde WordPress (no hay papelera para términos → trash directo)
add_action('deleted_term', function($term_id, $tt_id, $taxonomy) {
    if (defined('WPSHEETS_IS_WEBHOOK') && WPSHEETS_IS_WEBHOOK) return;
    if (defined('WPSHEETS_IS_SYNCING') && WPSHEETS_IS_SYNCING) return;
    $sid = get_option('wpsheets_spreadsheet_id');
    if (empty($sid)) return;
    $item_id = get_term_meta($term_id, '_ws_import_id', true);
    if (empty($item_id)) return;
    $tab = wpsheets_get_tab_for_taxonomy($taxonomy);
    if (empty($tab)) return;
    wpsheets_update_status_in_sheet($sid, $tab, $item_id, 'trash');
}, 10, 3);

