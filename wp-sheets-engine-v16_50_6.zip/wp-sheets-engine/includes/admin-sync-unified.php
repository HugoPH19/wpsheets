<?php
if (!defined('ABSPATH')) exit;

// ============================================================
// PÁGINA UNIFICADA: Sincronización
// WP→Sheets (exportar) + Sheets→WP (importar) + Auto-Sync
// ============================================================
function wpsheets_page_sync() {

    // ── Auto-Sync: guardar configuración ───────────────────
    if (isset($_POST['ws_auto_sync_save']) && check_admin_referer('ws_auto_sync_nonce')) {
        $interval = sanitize_text_field($_POST['ws_interval']);
        $enabled  = isset($_POST['ws_auto_sync_enable']) ? 1 : 0;
        update_option('ws_auto_sync_enabled', $enabled);
        update_option('ws_auto_sync_interval', $interval);
        wp_clear_scheduled_hook('wpsheets_cron_auto_sync');
        if ($enabled && $interval && !wp_next_scheduled('wpsheets_cron_auto_sync')) {
            wp_schedule_event(time(), $interval, 'wpsheets_cron_auto_sync');
        }
        echo '<div class="ws-alert ws-alert-success">✅ Auto-Sincronización guardada.</div>';
    }

    $as_enabled  = get_option('ws_auto_sync_enabled', 0);
    $as_interval = get_option('ws_auto_sync_interval', 'hourly');
    $has_woo     = class_exists('WooCommerce');

    // Detectar taxonomía de marcas
    $brand_slugs = ['product_brands', 'pwb-brand', 'yith_product_brand', 'product_brand'];
    $brand_tax   = '';
    if ($has_woo) {
        foreach (get_taxonomies([], 'objects') as $t) {
            foreach ($brand_slugs as $bs) {
                if (strpos($t->name, $bs) !== false) { $brand_tax = $t->name; break 2; }
            }
        }
    }

    $nonce = wp_create_nonce('wpsheets_ajax_nonce');
    ?>
    <div class="wpsheets-wrap">

        <!-- Header -->
        <div class="wpsheets-header">
            <div class="wpsheets-header-title">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#10B981" stroke-width="2">
                    <path d="M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.59-9.21L21.5 8"/>
                </svg>
                <div>
                    <h1>Sincronización</h1>
                    <div class="wpsheets-subtitle">Gestiona el flujo de datos entre WordPress y Google Sheets.</div>
                </div>
            </div>
        </div>

        <div style="display:grid; grid-template-columns:1fr 1fr; gap:24px; align-items:start;">

            <!-- ══ COLUMNA IZQUIERDA: WP → SHEETS ══════════════════ -->
            <div>
                <div style="display:flex; align-items:center; gap:10px; margin-bottom:16px;">
                    <div style="background:#DBEAFE; border-radius:8px; padding:8px 12px; font-size:18px;">⬆️</div>
                    <div>
                        <h2 style="margin:0; font-size:17px; color:#1D4ED8;">WordPress → Google Sheets</h2>
                        <p style="margin:4px 0 0; font-size:12px; color:#64748B;">Exporta datos de WP hacia tus hojas</p>
                    </div>
                </div>

                <!-- Exportar entidades del plugin (CPTs y Taxonomías propias) -->
                <div class="ws-card" style="margin-bottom:16px;">
                    <h3 style="margin-top:0; font-size:15px; color:#334155;">📋 Entidades del Plugin</h3>
                    <p style="font-size:13px; color:#64748B; margin-bottom:14px;">
                        Exporta CPTs o Taxonomías que configuraste en el plugin hacia su hoja vinculada.
                    </p>
                    <div style="display:flex; gap:10px; flex-wrap:wrap; align-items:center;">
                        <select id="ws-export-entity-select" class="ws-select" style="flex:1; max-width:280px;">
                            <?php echo wpsheets_get_grouped_options_html('', false); ?>
                        </select>
                        <button id="ws-export-entity-btn" class="ws-btn ws-btn-primary">
                            ⬆️ Exportar
                        </button>
                    </div>
                    <div id="ws-export-entity-result" class="ws-alert" style="display:none; margin-top:12px;"></div>
                </div>

                <!-- WooCommerce -->
                <?php if ($has_woo): ?>
                <div class="ws-card" style="border-left:4px solid #8B5CF6;">
                    <h3 style="margin-top:0; font-size:15px; color:#4C1D95;">🛒 WooCommerce</h3>
                    <p style="font-size:13px; color:#64748B; margin-bottom:14px;">
                        Crea o restaura las hojas de Woo y exporta todos los datos automáticamente.
                        Si las hojas ya existen, solo actualiza los datos sin borrar lo que tienes.
                    </p>

                    <!-- Botón único inteligente -->
                    <button id="btn-woo-smart-init" class="ws-btn ws-btn-primary" style="background:#8B5CF6; border-color:#8B5CF6; margin-bottom:14px; width:100%;">
                        🔧 Inicializar / Restaurar WooCommerce
                    </button>

                    <!-- Exportar entidad específica -->
                    <div style="border-top:1px solid #EDE9FE; padding-top:14px;">
                        <p style="font-size:12px; color:#6D28D9; font-weight:600; margin:0 0 8px;">Exportar solo una entidad:</p>
                        <div style="display:flex; gap:10px; flex-wrap:wrap; align-items:center;">
                            <select id="woo-export-entity" class="ws-select" style="flex:1;">
                                <option value="product">🛍️ Productos</option>
                                <option value="product_cat">📂 Categorías</option>
                                <option value="product_tag">🏷️ Etiquetas</option>
                                <?php if ($brand_tax): ?>
                                    <option value="brands">⭐ Marcas</option>
                                <?php endif; ?>
                                <?php if (function_exists('wc_get_attribute_taxonomies') && !empty(wc_get_attribute_taxonomies())): ?>
                                    <option value="attributes">⚙️ Atributos</option>
                                <?php endif; ?>
                            </select>
                            <button id="btn-woo-export-partial" class="ws-btn ws-btn-secondary" style="border-color:#8B5CF6; color:#6D28D9;">
                                ⬆️ Exportar
                            </button>
                        </div>
                    </div>

                    <div id="woo-sync-result" class="ws-alert" style="display:none; margin-top:12px;"></div>
                </div>
                <?php endif; ?>
            </div>

            <!-- ══ COLUMNA DERECHA: SHEETS → WP ════════════════════ -->
            <div>
                <div style="display:flex; align-items:center; gap:10px; margin-bottom:16px;">
                    <div style="background:#DCFCE7; border-radius:8px; padding:8px 12px; font-size:18px;">⬇️</div>
                    <div>
                        <h2 style="margin:0; font-size:17px; color:#15803D;">Google Sheets → WordPress</h2>
                        <p style="margin:4px 0 0; font-size:12px; color:#64748B;">Importa o actualiza masivamente desde Sheets</p>
                    </div>
                </div>

                <div class="ws-card">
                    <p style="font-size:13px; color:#64748B; margin-top:0;">
                        Lee todas las filas de la hoja seleccionada y las aplica a WordPress.
                        Útil cuando hiciste cambios masivos en Sheets o cuando el Apps Script no pudo sincronizar.
                    </p>

                    <div class="ws-form-group">
                        <label class="ws-label" style="font-size:13px;">¿Qué deseas sincronizar?</label>
                        <select id="ws-sync-object" class="ws-select">
                            <?php echo wpsheets_get_grouped_options_html(); ?>
                        </select>
                    </div>

                    <div style="display:flex; flex-wrap:wrap; gap:12px; align-items:center; margin-top:16px;">
                        <button id="ws-sync-start-btn" class="ws-btn ws-btn-primary" disabled>
                            🚀 Iniciar Importación
                        </button>
                        <button id="ws-sync-stop-btn" class="ws-btn ws-btn-danger" style="display:none;">
                            🛑 Detener
                        </button>
                        <label style="display:flex; align-items:center; gap:8px; font-size:12px; color:#475569; cursor:pointer; background:#F8FAFC; border:1px solid #E2E8F0; padding:6px 10px; border-radius:6px;">
                            <input type="checkbox" id="ws-sync-create-only" style="width:14px; height:14px;">
                            <span><strong>Solo crear nuevos</strong> — omite los que ya existen en WP</span>
                        </label>
                    </div>

                    <div class="ws-progress-bg" id="ws-sync-progress-bg" style="margin-top:16px;">
                        <div class="ws-progress-bar" id="ws-sync-progress-bar"></div>
                    </div>
                    <div id="ws-sync-status-text" style="font-weight:600; font-size:13px; margin-top:8px; display:none; color:var(--ws-primary);"></div>
                    <div class="ws-log-console" id="ws-sync-log" style="margin-top:12px;">
                        <div style="color:#64748B;">> Consola inactiva. Selecciona una opción e inicia.</div>
                    </div>
                </div>

                <!-- Auto-Sync -->
                <div class="ws-card" style="margin-top:16px; border-left:4px solid #F59E0B;">
                    <h3 style="margin-top:0; font-size:15px; color:#92400E;">⏱️ Auto-Sincronización (Cron)</h3>
                    <p style="font-size:13px; color:#64748B; margin-bottom:14px;">
                        WordPress revisará Sheets automáticamente en segundo plano según el intervalo que elijas.
                    </p>
                    <form method="POST" action="">
                        <?php wp_nonce_field('ws_auto_sync_nonce'); ?>
                        <label style="display:flex; align-items:center; gap:8px; font-size:13px; cursor:pointer; margin-bottom:12px;">
                            <input type="checkbox" name="ws_auto_sync_enable" value="1" <?php checked($as_enabled, 1); ?> style="width:16px; height:16px;">
                            <strong>Activar Auto-Sincronización</strong>
                        </label>
                        <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
                            <select name="ws_interval" class="ws-select" style="flex:1; max-width:220px;">
                                <option value="every_minute"      <?php selected($as_interval,'every_minute');      ?>>Cada 1 minuto (solo pruebas)</option>
                                <option value="every_five_minutes" <?php selected($as_interval,'every_five_minutes');?>>Cada 5 minutos</option>
                                <option value="hourly"             <?php selected($as_interval,'hourly');            ?>>Cada hora</option>
                                <option value="twicedaily"         <?php selected($as_interval,'twicedaily');        ?>>2 veces al día</option>
                                <option value="daily"              <?php selected($as_interval,'daily');             ?>>1 vez al día</option>
                            </select>
                            <button type="submit" name="ws_auto_sync_save" class="ws-btn ws-btn-secondary" style="border-color:#F59E0B; color:#92400E;">
                                Guardar
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
    jQuery(function($) {
        var nonce = '<?php echo $nonce; ?>';

        // ── Exportar entidad del plugin ──────────────────────────
        $('#ws-export-entity-btn').on('click', function(e) {
            e.preventDefault();
            var btn    = $(this);
            var opt    = $('#ws-export-entity-select option:selected');
            var objId  = opt.val();
            var objType = opt.data('type');
            var sheet  = opt.data('sheet') || '';
            var result = $('#ws-export-entity-result');
            if (!sheet) {
                result.removeClass('ws-alert-success').addClass('ws-alert-error')
                    .html('⚠️ Esta entidad no tiene hoja vinculada. Ve a <strong>Entidades</strong> y asigna una pestaña.').show();
                return;
            }
            btn.html('Exportando...').prop('disabled', true);
            result.hide();
            $.post(wpSheets.ajax_url, {
                action: 'wpsheets_export_single_entity',
                nonce: nonce,
                object_id: objId,
                object_type: objType,
                sheet: sheet
            }, function(res) {
                result.removeClass('ws-alert-error ws-alert-success');
                if (res.success) result.addClass('ws-alert-success').html(res.data).show();
                else             result.addClass('ws-alert-error').html(res.data).show();
            }).always(function() { btn.html('⬆️ Exportar').prop('disabled', false); });
        });

        // ── WooCommerce: Inicializar / Restaurar ─────────────────
        $('#btn-woo-smart-init').on('click', function(e) {
            e.preventDefault();
            var btn = $(this);
            btn.html('⏳ Procesando...').prop('disabled', true);
            $('#woo-sync-result').hide();
            $.post(wpSheets.ajax_url, { action: 'wpsheets_init_woocommerce', nonce: wpSheets.nonce }, function(res) {
                var box = $('#woo-sync-result');
                box.removeClass('ws-alert-error ws-alert-success');
                if (res.success) box.addClass('ws-alert-success').html(res.data).show();
                else             box.addClass('ws-alert-error').html(res.data).show();
            }).always(function() { btn.html('🔧 Inicializar / Restaurar WooCommerce').prop('disabled', false); });
        });

        // ── WooCommerce: Exportar entidad específica ─────────────
        $('#btn-woo-export-partial').on('click', function(e) {
            e.preventDefault();
            var btn    = $(this);
            var entity = $('#woo-export-entity').val();
            btn.html('Exportando...').prop('disabled', true);
            $('#woo-sync-result').hide();
            $.post(wpSheets.ajax_url, {
                action: 'wpsheets_woo_export_entity',
                nonce: '<?php echo wp_create_nonce('wpsheets_ajax_nonce'); ?>',
                entity: entity
            }, function(res) {
                var box = $('#woo-sync-result');
                box.removeClass('ws-alert-error ws-alert-success');
                if (res.success) box.addClass('ws-alert-success').html(res.data).show();
                else             box.addClass('ws-alert-error').html(res.data).show();
            }).always(function() { btn.html('⬆️ Exportar').prop('disabled', false); });
        });

        // ── Motor de importación Sheets → WP ────────────────────
        var syncObjId = '', syncObjType = '', syncSheet = '', syncTotal = 0, syncOffset = 0, syncBatchSize = 5;
        var syncMapping = {}, syncHeaders = [], syncCreateOnly = false; var isSyncing = false;

        $('#ws-sync-object').on('change', function() {
            $('#ws-sync-start-btn').prop('disabled', !$(this).val());
        });

        function logSync(msg) {
            var time = new Date().toLocaleTimeString();
            $('#ws-sync-log').append('<div class="ws-log-line"><span style="color:#64748B;">['+time+']</span> ' + msg + '</div>');
            $('#ws-sync-log').scrollTop($('#ws-sync-log')[0].scrollHeight);
        }

        $('#ws-sync-start-btn').on('click', function(e) {
            e.preventDefault();
            if (!confirm('¿Iniciar importación desde Google Sheets?')) return;
            var opt = $('#ws-sync-object option:selected');
            syncObjId   = opt.val();
            syncObjType = opt.data('type');
            syncSheet   = opt.data('sheet') || '';
            syncCreateOnly = $('#ws-sync-create-only').is(':checked');

            if (!syncSheet) {
                logSync('<span class="ws-log-error">⚠️ Esta entidad no tiene hoja vinculada.</span>');
                return;
            }

            $(this).hide(); $('#ws-sync-stop-btn').show();
            $('#ws-sync-object').prop('disabled', true);
            $('#ws-sync-progress-bg, #ws-sync-log, #ws-sync-status-text').show();
            $('#ws-sync-progress-bar').css('width', '0%');
            $('#ws-sync-log').empty();
            logSync('<span class="ws-log-info">PREPARANDO IMPORTACIÓN...</span>');
            isSyncing = true; syncOffset = 0;

            $.post(wpSheets.ajax_url, {
                action: 'wpsheets_sync_prepare', nonce: wpSheets.nonce,
                object_id: syncObjId, sheet: syncSheet
            }, function(res) {
                if (!res.success) { logSync('<span class="ws-log-error">Error: ' + res.data + '</span>'); stopSyncUI(); return; }
                syncTotal = res.data.total_rows; syncHeaders = res.data.headers; syncMapping = res.data.mapping;
                logSync('<span style="color:#fff;">✓ ' + syncTotal + ' filas encontradas. Iniciando...</span>');
                processNextBatch();
            });
        });

        $('#ws-sync-stop-btn').on('click', function(e) {
            e.preventDefault(); isSyncing = false;
            logSync('<span class="ws-log-warn">⚠️ DETENIDO por el usuario.</span>'); stopSyncUI();
        });

        function processNextBatch() {
            if (!isSyncing) return;
            if (syncOffset >= syncTotal) {
                logSync('<br><span style="color:#10B981; font-weight:bold;">✅ ¡COMPLETADO!</span>');
                $('#ws-sync-progress-bar').css('width', '100%');
                $('#ws-sync-status-text').text('100% Completado');
                stopSyncUI(); return;
            }
            var batch = Math.min(syncBatchSize, syncTotal - syncOffset);
            logSync('<span class="ws-log-info">>> Lote: ' + (syncOffset+1) + ' a ' + (syncOffset+batch) + '...</span>');
            $.post(wpSheets.ajax_url, {
                action: 'wpsheets_sync_batch', nonce: wpSheets.nonce,
                object_id: syncObjId, object_type: syncObjType, sheet: syncSheet,
                offset: syncOffset, batch_size: batch, headers: syncHeaders,
                mapping: syncMapping, create_only: syncCreateOnly ? 1 : 0
            }, function(res) {
                if (!res.success) { logSync('<span class="ws-log-error">Error en lote: ' + res.data + '</span>'); stopSyncUI(); return; }
                res.data.logs.forEach(function(l) { logSync('&nbsp;&nbsp;&nbsp;↳ ' + l); });
                syncOffset += batch;
                var pct = Math.round((syncOffset / syncTotal) * 100);
                $('#ws-sync-progress-bar').css('width', pct + '%');
                $('#ws-sync-status-text').text('Importando: ' + pct + '%');
                setTimeout(processNextBatch, 600);
            });
        }

        function stopSyncUI() {
            $('#ws-sync-start-btn').show().text('🚀 Iniciar Importación');
            $('#ws-sync-stop-btn').hide();
            $('#ws-sync-object').prop('disabled', false);
        }
    });
    </script>
    <?php
}

// ============================================================
// AJAX: Exportar una entidad individual (CPT o taxonomía propia)
// ============================================================
add_action('wp_ajax_wpsheets_export_single_entity', function() {
    check_ajax_referer('wpsheets_ajax_nonce', 'nonce');
    $obj_id   = sanitize_text_field($_POST['object_id']);
    $obj_type = sanitize_text_field($_POST['object_type']);
    $sheet    = sanitize_text_field($_POST['sheet']);

    if (empty($obj_id) || empty($sheet)) wp_send_json_error('Faltan parámetros.');

    if ($obj_type === 'cpt') {
        $n = wpsheets_bulk_export_cpt($obj_id, $sheet, $obj_id);
        wp_send_json_success("✅ <strong>{$n} registros</strong> exportados a <strong>{$sheet}</strong>.");
    } elseif ($obj_type === 'tax') {
        $tax_slug = str_replace('tax_', '', $obj_id);
        $map_key  = $obj_id; // "tax_tipo_alimento"
        $n = wpsheets_bulk_export_taxonomy($tax_slug, $sheet, $map_key);
        wp_send_json_success("✅ <strong>{$n} términos</strong> exportados a <strong>{$sheet}</strong>.");
    } else {
        wp_send_json_error('Tipo de entidad desconocido.');
    }
});

// ============================================================
// Auto-Sync en segundo plano (cron)
// ============================================================
add_action('wpsheets_cron_auto_sync', 'wpsheets_execute_background_sync');
function wpsheets_execute_background_sync() {
    error_log('WPSheets Auto-Sync ejecutado: ' . current_time('mysql'));
    // Base para futuras implementaciones de sync masivo en background
}
