<?php
if (!defined('ABSPATH')) exit;

// ============================================================
// PÁGINA UNIFICADA: Entidades
// Combina Post Types + Taxonomías + Campos Dinámicos en tabs
// ============================================================
function wpsheets_page_entities() {
    $active_tab = isset($_GET['entity_tab']) ? sanitize_key($_GET['entity_tab']) : 'cpts';
    $base_url   = admin_url('admin.php?page=wpsheets-entities');
    $tabs       = get_option('wpsheets_spreadsheet_id') ? WPSheets_Google_API::get_spreadsheet_tabs(get_option('wpsheets_spreadsheet_id')) : [];

    // ── Procesar acciones POST / GET antes de renderizar ────
    $alert = '';

    // --- CPTs ---
    if ($active_tab === 'cpts') {
        $cpts = get_option('wpsheets_cpts', []);
        if (isset($_POST['wpsheets_add_cpt']) && check_admin_referer('wpsheets_save_cpt')) {
            $id      = sanitize_text_field($_POST['cpt_id']);
            $new_cpt = [
                'id'       => $id ?: uniqid(),
                'singular' => sanitize_text_field($_POST['singular']),
                'plural'   => sanitize_text_field($_POST['plural']),
                'slug'     => sanitize_title($_POST['slug']),
                'icon'     => sanitize_text_field($_POST['icon']),
                'sheet'    => sanitize_text_field($_POST['sheet']),
            ];
            if ($id) {
                foreach ($cpts as $k => $c) { if ($c['id'] === $id) $cpts[$k] = $new_cpt; }
                $action_label = 'actualizado';
            } else {
                $cpts[]       = $new_cpt;
                $action_label = 'creado';
            }
            update_option('wpsheets_cpts', $cpts);
            update_option('wpsheets_needs_sync', '1');
            $auto_msg = '';
            if (!empty($new_cpt['sheet'])) {
                $mapped = wpsheets_auto_map_cpt($new_cpt['slug'], $new_cpt['sheet']);
                if ($mapped !== false) {
                    $exported  = wpsheets_bulk_export_cpt($new_cpt['slug'], $new_cpt['sheet'], $new_cpt['slug']);
                    $auto_msg  = " Auto-mapeado ({$mapped} columnas).";
                    if ($exported > 0) $auto_msg .= " {$exported} registros exportados.";
                } else {
                    $auto_msg = ' <em>Hoja no encontrada — se mapeará al crearla.</em>';
                }
            }
            $alert = '<div class="ws-alert ws-alert-success">Post Type ' . $action_label . '.' . $auto_msg . '</div>';
        }
        if (isset($_GET['delete_cpt'])) {
            $cpts  = array_values(array_filter($cpts, fn($c) => $c['id'] !== $_GET['delete_cpt']));
            update_option('wpsheets_cpts', $cpts);
            $alert = '<div class="ws-alert ws-alert-success">Post Type eliminado.</div>';
        }
        $cpts = get_option('wpsheets_cpts', []);
    }

    // --- Taxonomías ---
    if ($active_tab === 'taxonomies') {
        $taxs = get_option('wpsheets_taxonomies', []);
        if (isset($_POST['wpsheets_add_tax']) && check_admin_referer('wpsheets_save_tax')) {
            $id      = sanitize_text_field($_POST['tax_id']);
            $new_tax = [
                'id'         => $id ?: uniqid(),
                'singular'   => sanitize_text_field($_POST['singular']),
                'plural'     => sanitize_text_field($_POST['plural']),
                'slug'       => sanitize_title($_POST['slug']),
                'post_types' => isset($_POST['post_types']) ? array_map('sanitize_title', $_POST['post_types']) : [],
                'sheet'      => sanitize_text_field($_POST['sheet']),
            ];
            if ($id) {
                foreach ($taxs as $k => $t) { if ($t['id'] === $id) $taxs[$k] = $new_tax; }
                $tax_action = 'actualizada';
            } else {
                $taxs[]     = $new_tax;
                $tax_action = 'creada';
            }
            update_option('wpsheets_taxonomies', $taxs);
            update_option('wpsheets_needs_sync', '1');
            if (!empty($new_tax['post_types'])) {
                register_taxonomy($new_tax['slug'], $new_tax['post_types'], [
                    'label' => $new_tax['plural'], 'public' => true,
                    'hierarchical' => true, 'show_in_rest' => true,
                ]);
            }
            $tax_auto_msg = '';
            if (!empty($new_tax['sheet'])) {
                $mapped = wpsheets_auto_map_taxonomy($new_tax['slug'], $new_tax['sheet']);
                if ($mapped !== false) {
                    $exported_t   = wpsheets_bulk_export_taxonomy($new_tax['slug'], $new_tax['sheet'], 'tax_' . $new_tax['slug']);
                    $tax_auto_msg = " Auto-mapeado ({$mapped} columnas).";
                    if ($exported_t > 0) $tax_auto_msg .= " {$exported_t} términos exportados.";
                } else {
                    $tax_auto_msg = ' <em>Hoja no encontrada — se mapeará al crearla.</em>';
                }
            }
            $alert = '<div class="ws-alert ws-alert-success">Taxonomía ' . $tax_action . '.' . $tax_auto_msg . '</div>';
        }
        if (isset($_GET['delete_tax'])) {
            $taxs  = array_values(array_filter($taxs, fn($t) => $t['id'] !== $_GET['delete_tax']));
            update_option('wpsheets_taxonomies', $taxs);
            $alert = '<div class="ws-alert ws-alert-success">Taxonomía eliminada.</div>';
        }
        $taxs = get_option('wpsheets_taxonomies', []);
        $cpts = get_option('wpsheets_cpts', []);
    }
    ?>
    <div class="wpsheets-wrap">

        <!-- Header -->
        <div class="wpsheets-header">
            <div class="wpsheets-header-title">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#2563EB" stroke-width="2">
                    <rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/>
                </svg>
                <div>
                    <h1>Entidades</h1>
                    <div class="wpsheets-subtitle">Administra Post Types, Taxonomías y sus mapeos de columnas.</div>
                </div>
            </div>
            <?php if ($active_tab === 'cpts'): ?>
                <button class="ws-btn ws-btn-primary" onclick="jQuery('#cpt-form-container').toggle();">+ Añadir Post Type</button>
            <?php elseif ($active_tab === 'taxonomies'): ?>
                <button class="ws-btn ws-btn-primary" onclick="jQuery('#tax-form-container').toggle();">+ Añadir Taxonomía</button>
            <?php endif; ?>
        </div>

        <?php echo $alert; ?>

        <!-- Tab Navigation -->
        <div style="display:flex; gap:4px; margin-bottom:20px; border-bottom:2px solid #E2E8F0; padding-bottom:0;">
            <?php
            $nav_tabs = [
                'cpts'       => ['🗂️ Post Types',     $base_url . '&entity_tab=cpts'],
                'taxonomies' => ['🏷️ Taxonomías',     $base_url . '&entity_tab=taxonomies'],
                'fields'     => ['⚙️ Campos Dinámicos', $base_url . '&entity_tab=fields'],
            ];
            foreach ($nav_tabs as $slug => [$label, $url]):
                $is_active = ($active_tab === $slug);
                $style = $is_active
                    ? 'background:#fff; border:2px solid #E2E8F0; border-bottom:2px solid #fff; color:#2563EB; font-weight:600; margin-bottom:-2px;'
                    : 'background:transparent; border:none; color:#64748B;';
            ?>
                <a href="<?php echo esc_url($url); ?>"
                   style="padding:10px 20px; border-radius:6px 6px 0 0; text-decoration:none; font-size:14px; <?php echo $style; ?>">
                    <?php echo $label; ?>
                </a>
            <?php endforeach; ?>
        </div>

        <!-- ══ TAB: POST TYPES ══════════════════════════════════════ -->
        <?php if ($active_tab === 'cpts'): ?>
            <div id="cpt-form-container" class="ws-card" style="display:none; border-top:4px solid var(--ws-accent);">
                <h3 id="cpt-form-title" style="margin-top:0;">Añadir Nuevo Post Type</h3>
                <form method="post" id="add-cpt-form">
                    <?php wp_nonce_field('wpsheets_save_cpt'); ?>
                    <input type="hidden" name="cpt_id" id="cpt_id" value="">
                    <div style="display:flex; gap:20px; flex-wrap:wrap;">
                        <div class="ws-form-group" style="flex:1; min-width:180px;"><label class="ws-label">Nombre Plural</label><input type="text" name="plural" id="cpt_plural" required class="ws-input"></div>
                        <div class="ws-form-group" style="flex:1; min-width:180px;"><label class="ws-label">Nombre Singular</label><input type="text" name="singular" id="cpt_singular" required class="ws-input"></div>
                        <div class="ws-form-group" style="flex:1; min-width:140px;"><label class="ws-label">Slug</label><input type="text" name="slug" id="cpt_slug" required class="ws-input"></div>
                        <div class="ws-form-group" style="flex:1; min-width:140px;"><label class="ws-label">Icono Dashicon</label><input type="text" name="icon" id="cpt_icon" value="dashicons-admin-post" class="ws-input"></div>
                    </div>
                    <div class="ws-form-group">
                        <label class="ws-label">Pestaña de Google Sheets Vinculada</label>
                        <select name="sheet" id="cpt_sheet" class="ws-select" style="max-width:320px;">
                            <?php if (!empty($tabs) && !is_wp_error($tabs)): foreach ($tabs as $t) echo "<option value='".esc_attr($t)."'>".esc_html($t)."</option>"; endif; ?>
                        </select>
                    </div>
                    <div style="display:flex; gap:10px;">
                        <button type="submit" name="wpsheets_add_cpt" class="ws-btn ws-btn-primary">Guardar Post Type</button>
                        <button type="button" class="ws-btn ws-btn-secondary" onclick="jQuery('#cpt-form-container').hide();">Cancelar</button>
                    </div>
                </form>
            </div>

            <div class="ws-table-wrapper">
                <table class="ws-table">
                    <thead><tr><th>Nombre</th><th>Slug</th><th>Hoja vinculada</th><th>Icono</th><th>Acciones</th></tr></thead>
                    <tbody>
                    <?php if (empty($cpts)): ?>
                        <tr><td colspan="5" style="text-align:center; color:#94A3B8;">No hay Post Types registrados. Crea el primero.</td></tr>
                    <?php else: foreach ($cpts as $c): ?>
                        <tr>
                            <td><strong><?php echo esc_html($c['plural']); ?></strong><br><small style="color:#94A3B8;"><?php echo esc_html($c['singular']); ?></small></td>
                            <td><span class="ws-badge"><?php echo esc_html($c['slug']); ?></span></td>
                            <td><?php echo $c['sheet'] ? '<span class="ws-badge ws-badge-success">'.esc_html($c['sheet']).'</span>' : '<span style="color:#EF4444; font-size:12px;">⚠️ Sin hoja</span>'; ?></td>
                            <td><span class="dashicons <?php echo esc_attr($c['icon']); ?>"></span></td>
                            <td style="text-align:right;">
                                <button class="ws-btn ws-btn-secondary edit-cpt-btn"
                                    data-id="<?php echo esc_attr($c['id']); ?>"
                                    data-plural="<?php echo esc_attr($c['plural']); ?>"
                                    data-singular="<?php echo esc_attr($c['singular']); ?>"
                                    data-slug="<?php echo esc_attr($c['slug']); ?>"
                                    data-icon="<?php echo esc_attr($c['icon']); ?>"
                                    data-sheet="<?php echo esc_attr($c['sheet']); ?>"
                                    style="padding:6px 12px; margin-right:5px;">Editar</button>
                                <a href="?page=wpsheets-entities&entity_tab=cpts&delete_cpt=<?php echo $c['id']; ?>"
                                   class="ws-btn ws-btn-danger" style="padding:6px 12px;"
                                   onclick="return confirm('¿Eliminar este Post Type?');">Eliminar</a>
                            </td>
                        </tr>
                    <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
            <script>
            jQuery('.edit-cpt-btn').on('click', function() {
                var d = jQuery(this).data();
                jQuery('#cpt_id').val(d.id); jQuery('#cpt_plural').val(d.plural);
                jQuery('#cpt_singular').val(d.singular); jQuery('#cpt_slug').val(d.slug);
                jQuery('#cpt_icon').val(d.icon); jQuery('#cpt_sheet').val(d.sheet);
                jQuery('#cpt-form-title').text('Editar Post Type');
                jQuery('#cpt-form-container').show();
                window.scrollTo(0, 0);
            });
            </script>

        <!-- ══ TAB: TAXONOMÍAS ══════════════════════════════════════ -->
        <?php elseif ($active_tab === 'taxonomies'): ?>
            <div id="tax-form-container" class="ws-card" style="display:none; border-top:4px solid var(--ws-accent);">
                <h3 id="tax-form-title" style="margin-top:0;">Añadir Nueva Taxonomía</h3>
                <form method="post" id="add-tax-form">
                    <?php wp_nonce_field('wpsheets_save_tax'); ?>
                    <input type="hidden" name="tax_id" id="tax_id" value="">
                    <div style="display:flex; gap:20px; flex-wrap:wrap;">
                        <div class="ws-form-group" style="flex:1; min-width:160px;"><label class="ws-label">Nombre Plural</label><input type="text" name="plural" id="tax_plural" required class="ws-input"></div>
                        <div class="ws-form-group" style="flex:1; min-width:160px;"><label class="ws-label">Nombre Singular</label><input type="text" name="singular" id="tax_singular" required class="ws-input"></div>
                        <div class="ws-form-group" style="flex:1; min-width:140px;"><label class="ws-label">Slug</label><input type="text" name="slug" id="tax_slug" required class="ws-input"></div>
                    </div>
                    <div class="ws-form-group">
                        <label class="ws-label">Asignar a Post Types</label>
                        <div style="background:var(--ws-bg); padding:15px; border-radius:6px; border:1px solid var(--ws-border); display:flex; flex-wrap:wrap; gap:12px;">
                            <?php foreach ($cpts as $c): ?>
                                <label style="display:flex; align-items:center; gap:6px; cursor:pointer;">
                                    <input type="checkbox" name="post_types[]" value="<?php echo esc_attr($c['slug']); ?>" class="tax-pt-checkbox">
                                    <?php echo esc_html($c['plural']); ?>
                                </label>
                            <?php endforeach; ?>
                            <label style="display:flex; align-items:center; gap:6px; cursor:pointer;">
                                <input type="checkbox" name="post_types[]" value="post" class="tax-pt-checkbox"> Posts nativos
                            </label>
                        </div>
                    </div>
                    <div class="ws-form-group">
                        <label class="ws-label">Pestaña de Google Sheets Vinculada</label>
                        <select name="sheet" id="tax_sheet" class="ws-select" style="max-width:320px;">
                            <?php if (!empty($tabs) && !is_wp_error($tabs)): foreach ($tabs as $t) echo "<option value='".esc_attr($t)."'>".esc_html($t)."</option>"; endif; ?>
                        </select>
                    </div>
                    <div style="display:flex; gap:10px;">
                        <button type="submit" name="wpsheets_add_tax" class="ws-btn ws-btn-primary">Guardar Taxonomía</button>
                        <button type="button" class="ws-btn ws-btn-secondary" onclick="jQuery('#tax-form-container').hide();">Cancelar</button>
                    </div>
                </form>
            </div>

            <div class="ws-table-wrapper">
                <table class="ws-table">
                    <thead><tr><th>Nombre</th><th>Slug</th><th>Vinculada a</th><th>Hoja</th><th>Acciones</th></tr></thead>
                    <tbody>
                    <?php if (empty($taxs)): ?>
                        <tr><td colspan="5" style="text-align:center; color:#94A3B8;">No hay Taxonomías registradas. Crea la primera.</td></tr>
                    <?php else: foreach ($taxs as $t): ?>
                        <tr>
                            <td><strong><?php echo esc_html($t['plural']); ?></strong><br><small style="color:#94A3B8;"><?php echo esc_html($t['singular']); ?></small></td>
                            <td><span class="ws-badge"><?php echo esc_html($t['slug']); ?></span></td>
                            <td><?php foreach ($t['post_types'] as $pt) echo '<span class="ws-badge" style="margin-right:4px; margin-bottom:2px;">'.esc_html($pt).'</span>'; ?></td>
                            <td><?php echo $t['sheet'] ? '<span class="ws-badge ws-badge-success">'.esc_html($t['sheet']).'</span>' : '<span style="color:#EF4444; font-size:12px;">⚠️ Sin hoja</span>'; ?></td>
                            <td style="text-align:right;">
                                <button class="ws-btn ws-btn-secondary edit-tax-btn"
                                    data-id="<?php echo esc_attr($t['id']); ?>"
                                    data-plural="<?php echo esc_attr($t['plural']); ?>"
                                    data-singular="<?php echo esc_attr($t['singular']); ?>"
                                    data-slug="<?php echo esc_attr($t['slug']); ?>"
                                    data-sheet="<?php echo esc_attr($t['sheet']); ?>"
                                    data-pts='<?php echo json_encode($t['post_types']); ?>'
                                    style="padding:6px 12px; margin-right:5px;">Editar</button>
                                <a href="?page=wpsheets-entities&entity_tab=taxonomies&delete_tax=<?php echo $t['id']; ?>"
                                   class="ws-btn ws-btn-danger" style="padding:6px 12px;"
                                   onclick="return confirm('¿Eliminar esta Taxonomía?');">Eliminar</a>
                            </td>
                        </tr>
                    <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
            <script>
            jQuery('.edit-tax-btn').on('click', function() {
                var d = jQuery(this).data();
                jQuery('#tax_id').val(d.id); jQuery('#tax_plural').val(d.plural);
                jQuery('#tax_singular').val(d.singular); jQuery('#tax_slug').val(d.slug);
                jQuery('#tax_sheet').val(d.sheet);
                jQuery('.tax-pt-checkbox').prop('checked', false);
                var pts = d.pts || [];
                pts.forEach(function(pt) { jQuery('input[value="'+pt+'"]').prop('checked', true); });
                jQuery('#tax-form-title').text('Editar Taxonomía');
                jQuery('#tax-form-container').show();
                window.scrollTo(0, 0);
            });
            </script>

        <!-- ══ TAB: CAMPOS DINÁMICOS ════════════════════════════════ -->
        <?php elseif ($active_tab === 'fields'): ?>
            <div class="ws-card">
                <div class="ws-form-group" style="margin-bottom:0;">
                    <label class="ws-label">Selecciona qué deseas mapear:</label>
                    <select id="ws-field-object-select" class="ws-select" style="max-width:400px;">
                        <?php echo wpsheets_get_grouped_options_html(); ?>
                    </select>
                </div>
            </div>
            <div id="ws-fields-container" class="ws-card" style="display:none; border-top:4px solid var(--ws-accent);">
                <h3 id="ws-fields-title" style="margin-top:0;">Mapeo de Columnas</h3>
                <div id="ws-fields-loading" style="display:none;"><div class="ws-skeleton" style="margin-bottom:10px;"></div><div class="ws-skeleton" style="width:80%;"></div></div>
                <form id="ws-fields-form" style="display:none;">
                    <input type="hidden" name="object_id" id="ws-fields-object-id">
                    <input type="hidden" name="object_type" id="ws-fields-object-type">
                    <div class="ws-table-wrapper">
                        <table class="ws-table">
                            <thead><tr><th style="width:35%;">Columna (Google Sheets)</th><th>Configuración en WordPress</th></tr></thead>
                            <tbody id="ws-fields-body"></tbody>
                        </table>
                    </div>
                    <div style="margin-top:24px; display:flex; align-items:center;">
                        <button type="submit" class="ws-btn ws-btn-primary">Guardar Configuración</button>
                        <span id="ws-fields-save-status" style="margin-left:15px; font-weight:500;"></span>
                    </div>
                </form>
            </div>
        <?php endif; ?>

    </div>
    <?php
}
