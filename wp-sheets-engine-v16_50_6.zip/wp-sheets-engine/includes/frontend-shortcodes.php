<?php
if (!defined('ABSPATH')) exit;

/**
 * WP Sheets Engine - Shortcodes
 * Permite mostrar campos dinámicos y taxonomías usando [ws_data]
 */
add_shortcode('ws_data', 'wpsheets_render_shortcode');
function wpsheets_render_shortcode($atts) {
    global $post;

    $atts = shortcode_atts([
        'key'     => '', // Para campos personalizados (meta) o nativos
        'tax'     => '', // Para sacar las taxonomías asociadas a un post
        'id'      => '', // ID del registro en Google Sheets (columna id)
        'term_id' => ''  // ID de la taxonomía en Google Sheets (columna id)
    ], $atts);

    // --- CASO 1: Consultar una Categoría (Taxonomía) por su ID de Google Sheets ---
    if (!empty($atts['term_id'])) {
        $sheet_term_id = sanitize_text_field($atts['term_id']);

        // Buscar en la BD cuál término tiene ese _ws_import_id
        $terms = get_terms([
            'hide_empty' => false,
            'meta_query' => [
                [
                    'key' => '_ws_import_id',
                    'value' => $sheet_term_id
                ]
            ],
            'number' => 1
        ]);

        if (!empty($terms) && !is_wp_error($terms)) {
            $term = $terms[0];
            $term_db_id = $term->term_id;

            if ($atts['key'] === 'tax_name') return $term->name;
            if ($atts['key'] === 'tax_desc') return $term->description;
            if (!empty($atts['key'])) return get_term_meta($term_db_id, sanitize_text_field($atts['key']), true);
        }
        return '';
    }

    // --- CASO 2: Consultar un Post (Platillo) por su ID de Google Sheets ---
    $post_id = 0;

    if (!empty($atts['id'])) {
        $sheet_post_id = sanitize_text_field($atts['id']);

        // Buscar en la BD cuál post tiene ese _ws_import_id
        $posts = get_posts([
            'post_type' => 'any',
            'meta_key' => '_ws_import_id',
            'meta_value' => $sheet_post_id,
            'posts_per_page' => 1,
            'post_status' => 'any'
        ]);

        if (!empty($posts)) {
            $post_id = $posts[0]->ID;
        } else {
            return ''; // No se encontró el registro
        }
    } else {
        $post_id = isset($post->ID) ? $post->ID : 0;
    }

    if (!$post_id) return '';

    // Si se pide qué categorías tiene asignadas este post
    if (!empty($atts['tax'])) {
        $terms = wp_get_post_terms($post_id, sanitize_text_field($atts['tax']), ['fields' => 'names']);
        return (!is_wp_error($terms) && !empty($terms)) ? implode(', ', $terms) : '';
    }

    // Si se pide el título o contenido nativo del post
    if ($atts['key'] === 'wp_title') {
        return get_the_title($post_id);
    }
    if ($atts['key'] === 'wp_content') {
        $p = get_post($post_id);
        return $p ? apply_filters('the_content', $p->post_content) : '';
    }

    // Si se pide un campo personalizado del post (ej: precio, url_img_platillo)
    if (!empty($atts['key'])) {
        $val = get_post_meta($post_id, sanitize_text_field($atts['key']), true);
        return $val;
    }

    return '';
}




// --- NUEVO SHORTCODE PARA CONDICIONES CSS INTELIGENTES (CLASE GENERAL) ---
// Uso: [ws_condicion term_id="baguette" key="visibilidad_taxonomia"]
add_shortcode('ws_condicion', 'wpsheets_render_condicion');
function wpsheets_render_condicion($atts) {
    $atts = shortcode_atts([
        'id' => '',
        'term_id' => '',
        'key' => '',
        'expected' => 'VERDADERO',
        'clase' => 'ocultar-dinamico' // <--- LA CLASE GENERAL POR DEFECTO
    ], $atts);

    if (empty($atts['key'])) return '';

    $val = '';
    if (!empty($atts['term_id'])) {
        $terms = get_terms([
            'hide_empty' => false, 
            'meta_query' => [['key' => '_ws_import_id', 'value' => sanitize_text_field($atts['term_id'])]], 
            'number' => 1
        ]);
        if (!empty($terms) && !is_wp_error($terms)) {
            $val = get_term_meta($terms[0]->term_id, sanitize_text_field($atts['key']), true);
        }
    } elseif (!empty($atts['id'])) {
        $posts = get_posts([
            'post_type' => 'any', 
            'meta_key' => '_ws_import_id', 
            'meta_value' => sanitize_text_field($atts['id']), 
            'posts_per_page' => 1, 
            'post_status' => 'any'
        ]);
        if (!empty($posts)) {
            $val = get_post_meta($posts[0]->ID, sanitize_text_field($atts['key']), true);
        }
    }

    $val_clean = strtoupper(trim((string)$val));
    $expected_clean = strtoupper(trim((string)$atts['expected']));

    // Si el valor NO coincide con lo esperado (no es verdadero/1/TRUE)
    if ($val_clean !== $expected_clean && $val_clean !== '1' && $val_clean !== 'TRUE') {
        $uid = uniqid('ws_hide_');
        $clase_target = sanitize_html_class($atts['clase']);
        ob_start();
        ?>
        <span id="<?php echo $uid; ?>" class="ws-condicion-fallida" style="display:none;"></span>
        <style>
            /* CSS Moderno: Oculta el contenedor padre que tenga la clase general si contiene este span */
            .<?php echo $clase_target; ?>:has(#<?php echo $uid; ?>) {
                display: none !important;
            }
        </style>
        <script>
            /* JS Fallback: Por si el navegador o Divi no soporta :has() */
            document.addEventListener("DOMContentLoaded", function() {
                var trigger = document.getElementById("<?php echo $uid; ?>");
                if (trigger) {
                    var container = trigger.closest(".<?php echo $clase_target; ?>");
                    if (container) {
                        container.style.setProperty("display", "none", "important");
                    }
                }
            });
        </script>
        <?php
        return ob_get_clean();
    }

    return ''; // Si es VERDADERO, no hace nada y se muestra normal
}
