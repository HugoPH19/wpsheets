<?php
if (!defined('ABSPATH')) exit;
add_action('admin_menu', function() {
    add_menu_page('Sheets Engine', 'Sheets Engine', 'manage_options', 'wpsheets-dashboard', 'wpsheets_page_dashboard', 'dashicons-grid-view', 30);
    add_submenu_page('wpsheets-dashboard', 'Dashboard',      'Dashboard',         'manage_options', 'wpsheets-dashboard', 'wpsheets_page_dashboard');
    add_submenu_page('wpsheets-dashboard', 'Conexión API',   'Conexión API',      'manage_options', 'wpsheets-api',       'wpsheets_page_api');
    add_submenu_page('wpsheets-dashboard', 'Configuración',  '⚙️ Configuración',  'manage_options', 'wpsheets-settings',  'wpsheets_page_settings');
    add_submenu_page('wpsheets-dashboard', 'Entidades',      '🗂️ Entidades',      'manage_options', 'wpsheets-entities',  'wpsheets_page_entities');
    add_submenu_page('wpsheets-dashboard', 'Data Grid Live', '📊 Data Grid',      'manage_options', 'wpsheets-datagrid',  'wpsheets_page_datagrid');
    add_submenu_page('wpsheets-dashboard', 'Sincronización', '🔄 Sincronización', 'manage_options', 'wpsheets-sync',      'wpsheets_page_sync');
});
add_action('admin_init', function() { register_setting('wpsheets_options', 'wpsheets_service_account_json'); register_setting('wpsheets_options', 'wpsheets_spreadsheet_id'); });
function wpsheets_page_api() {
    ?>
    <div class="wpsheets-wrap">
        <div class="wpsheets-header">
            <div class="wpsheets-header-title">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#2563EB" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="17 8 12 3 7 8"></polyline><line x1="12" y1="3" x2="12" y2="15"></line></svg>
                <div><h1>Conexión a Google Sheets</h1><div class="wpsheets-subtitle">Configura las credenciales de la API v4.</div></div>
            </div>
        </div>
        <form method="post" action="options.php" class="ws-card">
            <?php settings_fields('wpsheets_options'); ?>
            <div class="ws-form-group">
                <label class="ws-label">Credenciales Service Account (JSON)</label>
                <textarea name="wpsheets_service_account_json" rows="6" class="ws-textarea"><?php echo esc_textarea(get_option('wpsheets_service_account_json')); ?></textarea>
            </div>
            <div class="ws-form-group">
                <label class="ws-label">ID de la Hoja de Cálculo Principal</label>
                <input type="text" name="wpsheets_spreadsheet_id" value="<?php echo esc_attr(get_option('wpsheets_spreadsheet_id')); ?>" class="ws-input" />
            </div>
            <div style="margin-top: 30px; display: flex; gap: 15px;">
                <button type="submit" class="ws-btn ws-btn-primary">Guardar Configuración</button>
                <button type="button" id="wpsheets-test-btn" class="ws-btn ws-btn-secondary">Probar Conexión</button>
            </div>
            <div id="wpsheets-test-result" class="ws-alert" style="display: none; margin-top: 20px;"></div>
        </form>
    </div>

    <?php if (class_exists('WooCommerce')): ?>
    <div class="ws-card" style="margin-top: 30px; border-top: 4px solid #8B5CF6;">
        <h2 style="margin-top:0; font-size:18px; color:#4C1D95; display:flex; align-items:center; gap:8px;">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>
            Integración WooCommerce (Fase 1)
        </h2>
        <p style="color:#6B7280; font-size:13px;">Detectamos WooCommerce. Crea o restaura las hojas: <strong>Products_Woo, Categories_Woo, Tags_Woo, Brands_Woo, Attributes_Woo, Orders_Woo, Coupons_Woo</strong> — con columnas y auto-mapeo listos. Las hojas existentes <em>no se sobreescriben</em>.</p>
        <button type="button" id="wpsheets-woo-btn" class="ws-btn ws-btn-primary" style="background:#8B5CF6; border-color:#8B5CF6;">Restaurar / Inicializar WooCommerce</button>
        <div id="wpsheets-woo-result" class="ws-alert" style="display: none; margin-top: 15px;"></div>
    </div>

    <script>
    jQuery(document).ready(function($) {
        $('#wpsheets-woo-btn').on('click', function(e) {
            e.preventDefault();
            var btn = $(this);
            btn.text('Inicializando todas las hojas...').prop('disabled', true);
            $('#wpsheets-woo-result').hide();

            $.post(ajaxurl, {
                action: 'wpsheets_init_woocommerce',
                nonce: '<?php echo wp_create_nonce("wpsheets_ajax_nonce"); ?>'
            }, function(res) {
                btn.text('Restaurar / Inicializar WooCommerce').prop('disabled', false);
                var alertBox = $('#wpsheets-woo-result');
                if (res.success) {
                    alertBox.removeClass('ws-alert-error').addClass('ws-alert-success').html(res.data).show();
                } else {
                    alertBox.removeClass('ws-alert-success').addClass('ws-alert-error').html(res.data).show();
                }
            }).fail(function() {
                btn.text('Restaurar / Inicializar WooCommerce').prop('disabled', false);
                $('#wpsheets-woo-result').removeClass('ws-alert-success').addClass('ws-alert-error').html('Error interno del servidor.').show();
            });
        });
    });
    </script>
    <?php endif; ?>
    
    <?php
}
add_action('wp_ajax_wpsheets_test_connection', function() {
    check_ajax_referer('wpsheets_ajax_nonce', 'nonce');
    $sid = get_option('wpsheets_spreadsheet_id');
    if (empty($sid)) { wp_send_json_error('Guarda el ID primero.'); }
    $tabs = WPSheets_Google_API::get_spreadsheet_tabs($sid);
    if (is_wp_error($tabs) || empty($tabs)) { wp_send_json_error('Error de conexión o permisos en Google.'); }
    wp_send_json_success('Conexión establecida con éxito. Pestañas detectadas: <strong>' . implode(', ', $tabs) . '</strong>');
});

add_action('wp_ajax_wpsheets_init_woocommerce', function() {
    check_ajax_referer('wpsheets_ajax_nonce', 'nonce');

    $sid = get_option('wpsheets_spreadsheet_id');
    if (empty($sid)) wp_send_json_error('No has configurado el ID de Google Sheets.');
    if (!class_exists('WooCommerce')) wp_send_json_error('WooCommerce no está activo.');

    // ── Definición de todas las hojas (Prompts 3, 4, 5) ──────────────────
    $sheets = [
        'Products_Woo' => [
            'headers' => [
                '_ws_import_id', 'wp_status_wordpress', 'post_title', 'post_name', 'sku',
                'downloadable', 'virtual', 'visibility', 'stock', 'stock_status',
                'backorders', 'manage_stock', 'regular_price', 'sale_price',
                'weight', 'length', 'width', 'height', 'tax_status', 'tax_class',
                'product_type', 'product_cat', 'product_tag', 'image_url',
                'description', 'short_description'
            ],
        ],
        'Categories_Woo' => [
            'headers' => ['_ws_import_id', 'wp_status_wordpress', 'tax_name', 'tax_slug', 'parent', 'display_type', 'tax_desc', 'image_url'],
        ],
        'Tags_Woo' => [
            'headers' => ['_ws_import_id', 'wp_status_wordpress', 'tax_name', 'tax_slug', 'tax_desc'],
        ],
        'Brands_Woo' => [
            'headers' => ['_ws_import_id', 'wp_status_wordpress', 'tax_name', 'tax_slug', 'parent', 'tax_desc', 'image_url'],
        ],
        'Attributes_Woo' => [
            'headers' => ['_ws_import_id', 'wp_status_wordpress', 'tax_name', 'tax_slug', 'tax_desc', 'attribute_parent'],
        ],
        'Orders_Woo' => [
            'headers' => ['_ws_import_id', 'wp_status_wordpress', 'post_title', 'order_total', 'order_currency', 'billing_first_name', 'billing_last_name', 'billing_email'],
        ],
        'Coupons_Woo' => [
            'headers' => ['_ws_import_id', 'wp_status_wordpress', 'post_title', 'coupon_amount', 'discount_type', 'expiry_date'],
        ],
    ];

    // Obtener pestañas existentes para no sobrescribir
    $existing_tabs = WPSheets_Google_API::get_spreadsheet_tabs($sid);
    if (is_wp_error($existing_tabs)) $existing_tabs = [];

    $created = []; $skipped = [];
    foreach ($sheets as $sheet_name => $def) {
        if (in_array($sheet_name, $existing_tabs)) {
            $skipped[] = $sheet_name;
        } else {
            // Color morado para todas las hojas de WooCommerce
            $woo_color = ['red' => 0.42, 'green' => 0.13, 'blue' => 0.66];
            $res = WPSheets_Google_API::add_sheet_with_headers($sid, $sheet_name, $def['headers'], $woo_color);
            if (!is_wp_error($res)) $created[] = $sheet_name;
        }
    }

    // ── Auto-Mapeo inteligente (Prompt 5) ─────────────────────────────────
    $mapping = get_option('wpsheets_fields_mapping', []);
    if (!is_array($mapping)) $mapping = [];

    // Products_Woo
    // Mapeo completo de WooCommerce — cada campo al tipo/meta correcto
    $woo_field_map = [
        '_ws_import_id'     => ['type' => 'id'],
        'wp_status_wordpress' => ['type' => 'wp_status'],
        'post_title'        => ['type' => 'wp_title'],
        'post_name'         => ['type' => 'wp_slug'],
        'description'       => ['type' => 'wp_content'],
        'short_description' => ['type' => 'wp_excerpt'],
        'image_url'         => ['type' => 'wp_thumbnail'],
        'product_cat'       => ['type' => 'taxonomy',   'options' => ['tax_target' => 'product_cat', 'tax_autocreate' => '1']],
        'product_tag'       => ['type' => 'taxonomy',   'options' => ['tax_target' => 'product_tag', 'tax_autocreate' => '1']],
        'product_type'      => ['type' => 'taxonomy',   'options' => ['tax_target' => 'product_type', 'tax_autocreate' => '0']],
        // Campos WooCommerce (guardados en postmeta con el getter de WC)
        'sku'               => ['type' => 'meta', 'options' => ['meta_key' => '_sku']],
        'regular_price'     => ['type' => 'meta', 'options' => ['meta_key' => '_regular_price']],
        'sale_price'        => ['type' => 'meta', 'options' => ['meta_key' => '_sale_price']],
        'stock'             => ['type' => 'meta', 'options' => ['meta_key' => '_stock']],
        'stock_status'      => ['type' => 'meta', 'options' => ['meta_key' => '_stock_status']],
        'manage_stock'      => ['type' => 'meta', 'options' => ['meta_key' => '_manage_stock']],
        'backorders'        => ['type' => 'meta', 'options' => ['meta_key' => '_backorders']],
        'weight'            => ['type' => 'meta', 'options' => ['meta_key' => '_weight']],
        'length'            => ['type' => 'meta', 'options' => ['meta_key' => '_length']],
        'width'             => ['type' => 'meta', 'options' => ['meta_key' => '_width']],
        'height'            => ['type' => 'meta', 'options' => ['meta_key' => '_height']],
        'tax_status'        => ['type' => 'meta', 'options' => ['meta_key' => '_tax_status']],
        'tax_class'         => ['type' => 'meta', 'options' => ['meta_key' => '_tax_class']],
        'downloadable'      => ['type' => 'meta', 'options' => ['meta_key' => '_downloadable']],
        'virtual'           => ['type' => 'meta', 'options' => ['meta_key' => '_virtual']],
        'visibility'        => ['type' => 'meta', 'options' => ['meta_key' => '_visibility']],
    ];

    $product_map = [];
    foreach ($sheets['Products_Woo']['headers'] as $h) {
        $safeCol = strtolower(preg_replace('/[^a-zA-Z0-9_]/', '_', $h));
        if (isset($woo_field_map[$h])) {
            $def = $woo_field_map[$h];
            $product_map[$safeCol] = [
                'type'     => $def['type'],
                'required' => 0,
                'options'  => $def['options'] ?? [],
            ];
        } else {
            $product_map[$safeCol] = ['type' => 'text', 'required' => 0, 'options' => []];
        }
    }
    if (empty($mapping['product'])) $mapping['product'] = $product_map;
    else $mapping['product'] = $product_map; // siempre actualizar para corregir mapeos viejos

    // Categories_Woo
    $mapping['tax_product_cat'] = [
        '_ws_import_id' => ['type' => 'id',         'required' => 0, 'options' => []],
        'tax_name'      => ['type' => 'tax_name',    'required' => 1, 'options' => []],
        'tax_slug'      => ['type' => 'tax_slug',    'required' => 0, 'options' => []],
        'parent'        => ['type' => 'tax_parent',  'required' => 0, 'options' => []],
        'display_type'  => ['type' => 'meta',        'required' => 0, 'options' => ['meta_key' => 'display_type']],
        'tax_desc'      => ['type' => 'tax_desc',    'required' => 0, 'options' => []],
        'image_url'     => ['type' => 'image_url',   'required' => 0, 'options' => ['meta_key' => 'thumbnail_id']],
    ];

    // Tags_Woo
    $mapping['tax_product_tag'] = [
        '_ws_import_id' => ['type' => 'id',      'required' => 0, 'options' => []],
        'tax_name'      => ['type' => 'tax_name','required' => 1, 'options' => []],
        'tax_slug'      => ['type' => 'tax_slug','required' => 0, 'options' => []],
        'tax_desc'      => ['type' => 'tax_desc','required' => 0, 'options' => []],
    ];

    // Brands_Woo — detectar slug real de la taxonomía de marcas
    $brand_slugs = ['product_brands', 'pwb-brand', 'yith_product_brand', 'product_brand'];
    $brand_tax_slug = '';
    foreach (get_taxonomies([], 'objects') as $t) {
        foreach ($brand_slugs as $bs) { if (strpos($t->name, $bs) !== false) { $brand_tax_slug = $t->name; break 2; } }
    }
    $brand_map_key = $brand_tax_slug ? 'tax_' . $brand_tax_slug : 'tax_brands_woo';
    $mapping[$brand_map_key] = [
        '_ws_import_id' => ['type' => 'id',        'required' => 0, 'options' => []],
        'tax_name'      => ['type' => 'tax_name',  'required' => 1, 'options' => []],
        'tax_slug'      => ['type' => 'tax_slug',  'required' => 0, 'options' => []],
        'parent'        => ['type' => 'tax_parent','required' => 0, 'options' => []],
        'tax_desc'      => ['type' => 'tax_desc',  'required' => 0, 'options' => []],
        'image_url'     => ['type' => 'image_url', 'required' => 0, 'options' => ['meta_key' => 'thumbnail_id']],
    ];

    // Attributes_Woo — mapeo compartido para todos los pa_*
    $mapping['tax_woo_attributes'] = [
        '_ws_import_id' => ['type' => 'id',        'required' => 0, 'options' => []],
        'tax_name'         => ['type' => 'tax_name',  'required' => 1, 'options' => []],
        'tax_slug'         => ['type' => 'tax_slug',  'required' => 0, 'options' => []],
        'tax_desc'         => ['type' => 'tax_desc',  'required' => 0, 'options' => []],
        'attribute_parent' => ['type' => 'tax_parent','required' => 0, 'options' => []],
    ];

    // Orders_Woo & Coupons_Woo (básico)
    $mapping['shop_order'] = [
        '_ws_import_id' => ['type' => 'id',       'required' => 0, 'options' => []],
        'post_title'         => ['type' => 'wp_title', 'required' => 0, 'options' => []],
        'post_status'        => ['type' => 'wp_status','required' => 0, 'options' => []],
        'order_total'        => ['type' => 'meta',     'required' => 0, 'options' => ['meta_key' => '_order_total']],
        'order_currency'     => ['type' => 'meta',     'required' => 0, 'options' => ['meta_key' => '_order_currency']],
        'billing_first_name' => ['type' => 'meta',     'required' => 0, 'options' => ['meta_key' => '_billing_first_name']],
        'billing_last_name'  => ['type' => 'meta',     'required' => 0, 'options' => ['meta_key' => '_billing_last_name']],
        'billing_email'      => ['type' => 'meta',     'required' => 0, 'options' => ['meta_key' => '_billing_email']],
    ];
    $mapping['shop_coupon'] = [
        '_ws_import_id' => ['type' => 'id',       'required' => 0, 'options' => []],
        'post_title'    => ['type' => 'wp_title', 'required' => 0, 'options' => []],
        'post_status'   => ['type' => 'wp_status','required' => 0, 'options' => []],
        'coupon_amount' => ['type' => 'meta',     'required' => 0, 'options' => ['meta_key' => 'coupon_amount']],
        'discount_type' => ['type' => 'meta',     'required' => 0, 'options' => ['meta_key' => 'discount_type']],
        'expiry_date'   => ['type' => 'meta',     'required' => 0, 'options' => ['meta_key' => 'date_expires']],
    ];

    update_option('wpsheets_fields_mapping', $mapping);

    // --- Exportación masiva de datos existentes ---
    $export_results = [];

    // Productos
    $exported_products = wpsheets_bulk_export_cpt('product', 'Products_Woo', 'product');
    if ($exported_products > 0) $export_results[] = "{$exported_products} productos";

    // Categorías
    $exported_cats = wpsheets_bulk_export_taxonomy('product_cat', 'Categories_Woo', 'tax_product_cat');
    if ($exported_cats > 0) $export_results[] = "{$exported_cats} categorías";

    // Etiquetas
    $exported_tags = wpsheets_bulk_export_taxonomy('product_tag', 'Tags_Woo', 'tax_product_tag');
    if ($exported_tags > 0) $export_results[] = "{$exported_tags} etiquetas";

    // Marcas
    $brand_slugs_init = ['product_brands', 'pwb-brand', 'yith_product_brand', 'product_brand'];
    $brand_tax_init = '';
    foreach (get_taxonomies([], 'objects') as $t) {
        foreach ($brand_slugs_init as $bs) {
            if (strpos($t->name, $bs) !== false) { $brand_tax_init = $t->name; break 2; }
        }
    }
    if ($brand_tax_init) {
        $brand_map_init = 'tax_' . $brand_tax_init;
        $exported_brands = wpsheets_bulk_export_taxonomy($brand_tax_init, 'Brands_Woo', $brand_map_init);
        if ($exported_brands > 0) $export_results[] = "{$exported_brands} marcas";
    }

    // Atributos pa_*
    if (function_exists('wc_get_attribute_taxonomies')) {
        $total_attrs = 0;
        foreach (wc_get_attribute_taxonomies() as $attr) {
            $total_attrs += wpsheets_bulk_export_taxonomy('pa_' . $attr->attribute_name, 'Attributes_Woo', 'tax_woo_attributes');
        }
        if ($total_attrs > 0) $export_results[] = "{$total_attrs} términos de atributos";
    }

    $msg = '<strong>✅ Ecosistema WooCommerce inicializado:</strong><br>';
    if (!empty($created)) $msg .= '📄 Hojas creadas: <strong>' . implode(', ', $created) . '</strong><br>';
    if (!empty($skipped)) $msg .= '⏭️ Ya existían (no modificadas): ' . implode(', ', $skipped) . '<br>';
    if (!empty($export_results)) {
        $msg .= '📤 Exportados: <strong>' . implode(', ', $export_results) . '</strong><br>';
    } else {
        $msg .= '📭 No había datos previos para exportar.<br>';
    }
    $msg .= '<em>Auto-mapeo configurado. WordPress ↔ Google Sheets activo.</em>';

    wp_send_json_success($msg);
});


function wpsheets_page_dashboard() {
    $cpts = get_option('wpsheets_cpts', []);
    $taxs = get_option('wpsheets_taxonomies', []);
    $mapping = get_option('wpsheets_fields_mapping', []);
    $sid = get_option('wpsheets_spreadsheet_id', '');

    $cpt_tags = '';
    if (is_array($cpts) && count($cpts) > 0) {
        foreach($cpts as $c) {
            $plural = isset($c['plural']) ? $c['plural'] : 'CPT';
            $cpt_tags .= '<span style="background:#E2E8F0; color:#334155; padding:4px 10px; border-radius:12px; font-size:12px; margin:3px; display:inline-block; font-weight:500;">' . esc_html($plural) . '</span>';
        }
    }
    if (class_exists('WooCommerce')) {
        $cpt_tags .= '<span style="background:#EDE9FE; color:#5B21B6; padding:4px 10px; border-radius:12px; font-size:12px; margin:3px; display:inline-block; font-weight:500;">🛍️ Productos (Woo)</span>';
    }
    if (empty($cpt_tags)) $cpt_tags = '<span style="color:#94A3B8; font-size:13px;">Ninguno</span>';

    $tax_tags = '';
    if (is_array($taxs) && count($taxs) > 0) {
        foreach($taxs as $t) {
            $plural = isset($t['plural']) ? $t['plural'] : 'Tax';
            $tax_tags .= '<span style="background:#E2E8F0; color:#334155; padding:4px 10px; border-radius:12px; font-size:12px; margin:3px; display:inline-block; font-weight:500;">' . esc_html($plural) . '</span>';
        }
    }
    if (class_exists('WooCommerce')) {
        $tax_tags .= '<span style="background:#EDE9FE; color:#5B21B6; padding:4px 10px; border-radius:12px; font-size:12px; margin:3px; display:inline-block; font-weight:500;">📂 Categorías (Woo)</span>';
        $tax_tags .= '<span style="background:#EDE9FE; color:#5B21B6; padding:4px 10px; border-radius:12px; font-size:12px; margin:3px; display:inline-block; font-weight:500;">🏷️ Etiquetas (Woo)</span>';
    }
    if (empty($tax_tags)) $tax_tags = '<span style="color:#94A3B8; font-size:13px;">Ninguna</span>';

    $is_connected = !empty($sid) ? '<span style="color:#10B981; font-weight:bold;">Conectado 🟢</span>' : '<span style="color:#EF4444; font-weight:bold;">Sin Conexión 🔴</span>';
?>
    <div class="wpsheets-wrap">
        <div class="wpsheets-header">
            <div class="wpsheets-header-title">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#2563EB" stroke-width="2"><path d="M3 3v18h18"/><path d="m19 9-5 5-4-4-3 3"/></svg>
                <h1>Dashboard de WP Sheets Engine</h1>
            </div>
            <div class="wpsheets-subtitle">Resumen de tu sistema y atajos rápidos.</div>
        </div>

        <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap:20px; margin-bottom:30px;">
            <!-- Estado API -->
            <div class="ws-card" style="margin:0;">
                <h3 style="margin-top:0; font-size:15px; color:#64748b;">Estado de API</h3>
                <div style="font-size:24px; margin:10px 0;"><?php echo $is_connected; ?></div>
                <a href="?page=wpsheets-api" class="ws-btn ws-btn-secondary" style="font-size:12px; padding:5px 10px;">Configurar</a>
            </div>
            <!-- CPTs -->
            <div class="ws-card" style="margin:0;">
                <h3 style="margin-top:0; font-size:15px; color:#64748b;">Post Types</h3>
                <div style="font-size:32px; font-weight:bold; margin:5px 0; color:#1E293B;"><?php echo $cpt_tags; ?></div>
                <a href="?page=wpsheets-entities&entity_tab=cpts" class="ws-btn ws-btn-secondary" style="font-size:12px; padding:5px 10px;">Gestionar</a>
            </div>
            <!-- Taxonomies -->
            <div class="ws-card" style="margin:0;">
                <h3 style="margin-top:0; font-size:15px; color:#64748b;">Taxonomías</h3>
                <div style="font-size:32px; font-weight:bold; margin:5px 0; color:#1E293B;"><?php echo $tax_tags; ?></div>
                <a href="?page=wpsheets-entities&entity_tab=taxonomies" class="ws-btn ws-btn-secondary" style="font-size:12px; padding:5px 10px;">Gestionar</a>
            </div>
        </div>

        <div style="display:grid; grid-template-columns: 2fr 1fr; gap:20px;">
            <div>
                <!-- Acciones Rápidas -->
                <div class="ws-card">
                    <h2 style="margin-top:0; font-size:18px;">Acciones Rápidas</h2>
                    <div style="display:flex; gap:15px; flex-wrap:wrap; margin-top:20px;">
                        <a href="?page=wpsheets-sync" class="ws-btn ws-btn-primary" style="text-decoration:none;">🔄 Ir a Sincronizar Datos</a>
                        <a href="?page=wpsheets-entities&entity_tab=fields" class="ws-btn ws-btn-secondary" style="text-decoration:none;">⚙️ Mapeo de Columnas</a>
                        <a href="?page=wpsheets-datagrid" class="ws-btn ws-btn-secondary" style="text-decoration:none;">📊 Editor Data Grid</a>
                        <a href="?page=wpsheets-sync" class="ws-btn ws-btn-secondary" style="text-decoration:none; background:#FFFBEB; color:#B45309; border-color:#FCD34D;">⏱️ Configurar Auto-Sync</a>
                    </div>
                </div>

                <?php if (class_exists('WooCommerce')): 
                    $woo_init = get_option('wpsheets_fields_mapping');
                    $is_woo_ready = isset($woo_init['product']);
                ?>
                <div class="ws-card" style="margin-top: 20px; border-top: 4px solid #8B5CF6;">
                    <h2 style="margin-top:0; font-size:18px; color:#4C1D95; display:flex; align-items:center; gap:8px;">
                        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>
                        Módulo WooCommerce
                    </h2>

                    <?php if ($is_woo_ready): ?>
                        <div style="background:#F5F3FF; padding:15px; border-radius:8px; margin-bottom:15px;">
                            <span style="color:#10B981; font-weight:bold; display:flex; align-items:center; gap:5px;">
                                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
                                ¡Conexión Activa y Mapeada!
                            </span>
                            <p style="color:#5B21B6; font-size:13px; margin-top:5px;">La hoja "Productos_WooCommerce" está configurada. ¿Qué deseas hacer?</p>
                        </div>
                        <div style="display:flex; gap:10px;">
                            <a href="?page=wpsheets-sync" class="ws-btn ws-btn-primary" style="background:#8B5CF6; border-color:#8B5CF6; text-decoration:none;">⚙️ Ver Panel de Woo</a>
                            <a href="?page=wpsheets-entities&entity_tab=fields" class="ws-btn ws-btn-secondary" style="text-decoration:none;">Ver Mapeo</a>
                        </div>
                    <?php else: ?>
                        <p style="color:#6B7280; font-size:13px;">Hemos detectado WooCommerce en tu sitio. Haz clic abajo para generar automáticamente la pestaña <strong>Productos_WooCommerce</strong> en tu Google Sheets.</p>
                        <button type="button" id="wpsheets-woo-btn-dash" class="ws-btn ws-btn-primary" style="background:#8B5CF6; border-color:#8B5CF6;">Restaurar / Inicializar WooCommerce</button>
                        <div id="wpsheets-woo-result-dash" class="ws-alert" style="display: none; margin-top: 15px;"></div>
                        <script>
                        jQuery(document).ready(function($) {
                            $('#wpsheets-woo-btn-dash').on('click', function(e) {
                                e.preventDefault();
                                var btn = $(this);
                                btn.text('Inicializando...').prop('disabled', true);
                                $.post(ajaxurl, { action: 'wpsheets_init_woocommerce', nonce: '<?php echo wp_create_nonce("wpsheets_ajax_nonce"); ?>' }, function(res) {
                                    if (res.success) { location.reload(); } else { $('#wpsheets-woo-result-dash').addClass('ws-alert-error').html(res.data).show(); btn.text('Error').prop('disabled', false); }
                                });
                            });
                        });
                        </script>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>

            <!-- Ayuda / Info -->
            <div class="ws-card" style="background:#F8FAFC;">
                <h2 style="margin-top:0; font-size:18px;">💡 Tips de Uso</h2>
                <ul style="color:#475569; font-size:13px; line-height:1.6; padding-left:20px;">
                    <li>Siempre que agregues un nuevo campo en "Campos Dinámicos", recuerda hacer una sincronización.</li>
                    <li>Usa el <strong>Data Grid Live</strong> para editar como si estuvieras en Excel sin salir de WP.</li>
                    <li>Las fotos del carrusel de Divi toman su configuración de diseño directamente desde el constructor.</li>
                </ul>
            </div>
        
            <!-- Webhook Debug Log -->
            <div class="ws-card" style="border-top: 4px solid #F59E0B; margin-top:20px;">
                <h2 style="margin-top:0; font-size:18px; color:#B45309;">🔎 Registro de Diagnóstico (Logs)</h2>
                <p style="color:#475569; font-size:13px;">Si editas en Google Sheets y no ves el cambio en WordPress, revisa el último mensaje recibido del Webhook:</p>
                <div style="background:#1E293B; color:#F8FAFC; padding:15px; border-radius:6px; font-family:monospace; font-size:12px;">
                    <?php echo esc_html(get_option('wpsheets_last_webhook_error', 'Esperando el primer envío de datos desde Google Sheets...')); ?>
                </div>
            </div>

    </div>
    </div>
    <?php
}

// ADMIN NOTICES
add_action('admin_notices', function() {
    // Notice 1: WooCommerce Detected but not initialized
    if (class_exists('WooCommerce') && !get_option('wpsheets_woo_initialized')) {
        $mapping = get_option('wpsheets_fields_mapping', []);
        if (!isset($mapping['product'])) {
            echo '<div style="background: linear-gradient(135deg, #6D28D9 0%, #8B5CF6 100%); color: white; padding: 20px; margin: 15px 15px 15px 0; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); display: flex; align-items: center; justify-content: space-between;">';
            echo '<div style="display:flex; align-items:center; gap:15px;">';
            echo '<span style="font-size:35px; line-height:1;">🚀</span>';
            echo '<div>';
            echo '<h3 style="margin: 0 0 5px 0; color: white; font-size: 18px;">¡WooCommerce Detectado!</h3>';
            echo '<p style="margin: 0; font-size: 14px; opacity: 0.9;">WP Sheets Engine está listo para conectar tus productos con Google Sheets de forma automática.</p>';
            echo '</div></div>';
            echo '<a href="?page=wpsheets-dashboard" style="background: white; color: #6D28D9; text-decoration: none; padding: 12px 24px; border-radius: 6px; font-weight: bold; font-size: 14px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">Inicializar Ahora &rarr;</a>';
            echo '</div>';
        }
    }

    // Notice 2: Needs Sync
    if (get_option('wpsheets_needs_sync') == '1') {
        echo '<div style="background: linear-gradient(135deg, #F59E0B 0%, #FCD34D 100%); color: #78350F; padding: 20px; margin: 15px 15px 15px 0; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); display: flex; align-items: center; justify-content: space-between;">';
        echo '<div style="display:flex; align-items:center; gap:15px;">';
        echo '<span style="font-size:35px; line-height:1;">⚠️</span>';
        echo '<div>';
        echo '<h3 style="margin: 0 0 5px 0; color: #78350F; font-size: 18px;">Cambios Pendientes de Sincronizar</h3>';
        echo '<p style="margin: 0; font-size: 14px; opacity: 0.9;">Detectamos modificaciones en tus estructuras o mapeos. Sincroniza para reflejarlos en tu base de datos.</p>';
        echo '</div></div>';
        echo '<a href="?page=wpsheets-sync" style="background: #78350F; color: white; text-decoration: none; padding: 12px 24px; border-radius: 6px; font-weight: bold; font-size: 14px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">Ir a Sincronizar &rarr;</a>';
        echo '</div>';
    }
});


function wpsheets_page_settings() {
    $secret = get_option('wpsheets_webhook_secret');
    if (empty($secret)) {
        $secret = wp_generate_password(24, false);
        update_option('wpsheets_webhook_secret', $secret);
    }
    $webhook_url = rest_url('wpsheets/v1/webhook');
    ?>
    <div class="wpsheets-wrap">
        <div class="wpsheets-header">
            <div class="wpsheets-header-title">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#2563EB" stroke-width="2"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/></svg>
                <h1>Configuración & Webhooks</h1>
            </div>
            <div class="wpsheets-subtitle">Configura la sincronización en tiempo real mediante Google Apps Script.</div>
        </div>

        <div class="ws-card" style="border-top: 4px solid #10B981;">
            <h2 style="margin-top:0; font-size:18px; color:#047857;">🚀 Sincronización en Tiempo Real (Bidireccional)</h2>
            <p style="color:#475569; font-size:14px; line-height:1.6;">
                Este código de <strong>Google Apps Script</strong> convierte tu Google Sheets en una base de datos reactiva. Al pegarlo en tu hoja, cualquier celda que edites (ya sea un producto de WooCommerce, un Platillo o una Categoría) se enviará <strong>instantáneamente</strong> a tu sitio web sin tener que esperar al Auto-Sync.
            </p>

            <div style="background:#F1F5F9; padding:15px; border-radius:6px; margin:20px 0; border:1px solid #CBD5E1;">
                <div style="margin-bottom:10px;"><strong>📍 Tu URL de Webhook:</strong> <code style="background:#fff; padding:4px 8px; color:#2563EB;"><?php echo esc_url($webhook_url); ?></code></div>
                <div><strong>🔑 Tu Token Secreto:</strong> <code style="background:#fff; padding:4px 8px; color:#EF4444;"><?php echo esc_html($secret); ?></code></div>
            </div>

            <h3 style="font-size:15px; margin-bottom:10px;">Instrucciones de Uso (Paso a Paso):</h3>
            <div style="color:#475569; font-size:14px; line-height:1.8; margin-bottom:20px;">
                <p>Google bloquea las conexiones externas por seguridad si solo pegas el código. Sigue estos 5 pasos exactos para autorizar a tu hoja a hablar con WordPress:</p>
                <ol style="padding-left:20px; background:#F8FAFC; padding:15px 15px 15px 35px; border-radius:8px; border:1px solid #E2E8F0;">
                    <li>Abre tu archivo de Google Sheets y ve al menú <strong>Extensiones → Apps Script</strong>.</li>
                    <li>Borra todo el código existente, <strong>pega el código de abajo</strong> y guarda (💾).</li>
                    <li>Antes de crear los activadores, activa el <strong>Servicio Avanzado</strong>: en el panel izquierdo de Apps Script haz clic en <strong>"Servicios" (+)</strong>, busca <strong>"Google Sheets API"</strong> y haz clic en <strong>Agregar</strong>.</li>
                    <li>En el menú lateral, haz clic en <strong>Reloj 🕒 (Activadores)</strong> y crea <strong>2 activadores</strong>:
                        <table style="font-size:12px; margin-top:8px; border-collapse:collapse; width:100%;">
                            <tr style="background:#E2E8F0;">
                                <td style="padding:6px 10px;"><strong>sincronizarWP</strong></td>
                                <td style="padding:6px 10px;">De la hoja de cálculo</td>
                                <td style="padding:6px 10px;"><strong>Al editar</strong></td>
                                <td style="padding:6px 10px; color:#047857;">Sincronización en tiempo real</td>
                            </tr>
                            <tr style="background:#FEF3C7;">
                                <td style="padding:6px 10px;"><strong>onChangeHandler</strong></td>
                                <td style="padding:6px 10px;">De la hoja de cálculo</td>
                                <td style="padding:6px 10px;"><strong>Al modificar</strong></td>
                                <td style="padding:6px 10px; color:#92400E;">Anti-borrado + auto-init hojas nuevas</td>
                            </tr>
                        </table>
                    </li>
                    <li>Guarda. Google pedirá permisos → "Configuración avanzada" → "Ir a Proyecto" → <strong>Permitir</strong>.</li>
                    <li><strong>Inicializar todas las hojas de una vez:</strong> Regresa a Google Sheets, ve al menú <strong>🤖 WP Sheets Engine → ⚡ Inicializar TODAS las Hojas</strong>. Esto configura <code>_ws_import_id</code>, <code>wp_status_wordpress</code> y chips de color en todas las pestañas simultáneamente.</li>
                </ol>
                <div style="background:#F0FDF4; border:1px solid #BBF7D0; border-radius:6px; padding:12px; margin-top:10px; font-size:13px;">
                    <strong>💡 Flujo de estados (wp_status_wordpress):</strong><br>
                    En lugar de borrar filas (lo cual no se puede detectar), cambia el estado a <code>trash</code> para eliminar en WordPress, <code>draft</code> para ocultar, o <code>publish</code> para publicar. WordPress también actualiza esta columna automáticamente cuando cambias el estado desde el panel de administración.
                </div>
                <p style="color:#10B981; font-weight:bold;">¡Listo! No necesitas crear ninguna implementación o despliegue. Cierra Apps Script y edita cualquier celda para ver la magia.</p>
            </div>

            <div style="position:relative;">
                <button type="button" id="copy-script-btn" style="position:absolute; top:10px; right:10px; background:#3B82F6; color:#fff; border:none; padding:6px 12px; border-radius:4px; cursor:pointer; font-size:12px; display:flex; align-items:center; gap:5px; font-weight:bold; box-shadow:0 2px 4px rgba(0,0,0,0.2); transition:all 0.2s;">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>
                    Copiar Código
                </button>
                <pre id="apps-script-code" style="background:#1E293B; color:#F8FAFC; padding:40px 20px 20px 20px; border-radius:8px; overflow-x:auto; font-size:13px; line-height:1.5;"><code>// ============================================================
// WP SHEETS ENGINE - Vigilante Bidireccional
// Pega COMPLETO en Extensiones > Apps Script
// Requiere: Servicio avanzado "Google Sheets API" activado
// ============================================================

var WEBHOOK_URL    = "<?php echo esc_url_raw($webhook_url); ?>";
var WEBHOOK_SECRET = "<?php echo esc_js($secret); ?>";

// Columnas fijas que siempre se crean al inicializar
var FIXED_COLS     = ["_ws_import_id", "wp_status_wordpress", "view_display"];

// ============================================================
// A. MENU
// ============================================================
function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu("WP Sheets Engine")
    .addItem("Inicializar TODAS las Hojas", "inicializarTodasLasHojas")
    .addItem("Inicializar Hoja Activa", "inicializarHojaActiva")
    .addToUi();
  _cacheTodasLasHojas();
  // Guardar lista de hojas conocidas (para detectar hojas nuevas en onChange)
  var _sheets = SpreadsheetApp.getActiveSpreadsheet().getSheets();
  var _names  = _sheets.map(function(s) { return s.getName(); });
  PropertiesService.getScriptProperties().setProperty("ws_known_sheets", JSON.stringify(_names));
}

// ============================================================
// B. INICIALIZADORES
// ============================================================
function inicializarTodasLasHojas() {
  var sheets = SpreadsheetApp.getActiveSpreadsheet().getSheets();
  for (var i = 0; i < sheets.length; i++) {
    _inicializarHoja(sheets[i]);
  }
  _cacheTodasLasHojas();
  SpreadsheetApp.getUi().alert("Listo. " + sheets.length + " hojas inicializadas.");
}

function inicializarHojaActiva() {
  _inicializarHoja(SpreadsheetApp.getActiveSheet());
  _cacheHoja(SpreadsheetApp.getActiveSheet());
  SpreadsheetApp.getUi().alert("Hoja inicializada.");
}

function _inicializarHoja(sheet) {
  var maxRow  = sheet.getMaxRows();

  // ── 1. Columna A: _ws_import_id ─────────────────────────
  var lastCol = Math.max(sheet.getLastColumn(), 1);
  var headerA = String(sheet.getRange(1, 1).getValue()).trim();
  var hasId   = (headerA === "_ws_import_id" || headerA === "backendId");
  if (!hasId) {
    if (headerA !== "") { sheet.insertColumnBefore(1); lastCol++; }
    sheet.getRange(1, 1).setValue("_ws_import_id");
  }

  // ── 2. Columna B: wp_status_wordpress ───────────────────
  var headers   = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
  var statusCol = _findOrInsertHeader(sheet, headers, "wp_status_wordpress", 2);
  lastCol = sheet.getLastColumn();

  // ── 3. Columna C (o siguiente libre): view_display ──────
  headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
  var viewCol = _findOrInsertHeader(sheet, headers, "view_display", 3);
  lastCol = sheet.getLastColumn();

  // ── 4. Rellenar filas sin status ni view_display ─────────
  var lastRow = sheet.getLastRow();
  if (lastRow > 1) {
    // wp_status_wordpress
    var stRange = sheet.getRange(2, statusCol, lastRow - 1, 1);
    var stVals  = stRange.getValues();
    var stChanged = false;
    for (var r = 0; r < stVals.length; r++) {
      if (String(stVals[r][0]).trim() === "") { stVals[r][0] = "publish"; stChanged = true; }
    }
    if (stChanged) stRange.setValues(stVals);

    // view_display
    var vdRange = sheet.getRange(2, viewCol, lastRow - 1, 1);
    var vdVals  = vdRange.getValues();
    var vdChanged = false;
    for (var rv = 0; rv < vdVals.length; rv++) {
      if (String(vdVals[rv][0]).trim() === "") { vdVals[rv][0] = "TRUE"; vdChanged = true; }
    }
    if (vdChanged) vdRange.setValues(vdVals);
  }

  // ── 5. Desplegables ─────────────────────────────────────
  var statusValidation = SpreadsheetApp.newDataValidation()
    .requireValueInList(["publish", "draft", "trash"], true)
    .setAllowInvalid(false).build();
  sheet.getRange(2, statusCol, maxRow - 1, 1).setDataValidation(statusValidation);

  var viewValidation = SpreadsheetApp.newDataValidation()
    .requireValueInList(["TRUE", "FALSE"], true)
    .setAllowInvalid(false).build();
  sheet.getRange(2, viewCol, maxRow - 1, 1).setDataValidation(viewValidation);

  // ── 6. Colores condicionales ─────────────────────────────
  var fullStatus = sheet.getRange(2, statusCol, maxRow - 1, 1);
  var rules = sheet.getConditionalFormatRules();
  // Evitar duplicar reglas
  var filteredRules = rules.filter(function(r) {
    var rngs = r.getRanges();
    return !(rngs.length === 1 &&
             rngs[0].getColumn() === statusCol &&
             rngs[0].getRow() === 2);
  });
  filteredRules.push(
    SpreadsheetApp.newConditionalFormatRule().whenTextEqualTo("publish")
      .setBackground("#b7e1cd").setFontColor("#006622").setRanges([fullStatus]).build(),
    SpreadsheetApp.newConditionalFormatRule().whenTextEqualTo("draft")
      .setBackground("#fce8b2").setFontColor("#b26b00").setRanges([fullStatus]).build(),
    SpreadsheetApp.newConditionalFormatRule().whenTextEqualTo("trash")
      .setBackground("#f4c7c3").setFontColor("#990000").setRanges([fullStatus]).build()
  );
  sheet.setConditionalFormatRules(filteredRules);

  // ── 7. Proteger columna A ────────────────────────────────
  try {
    sheet.getRange(2, 1, maxRow - 1, 1)
      .protect().setDescription("ID - No editar").setWarningOnly(true);
  } catch(e) {}

  // ── 8. Formato del encabezado ────────────────────────────
  var totalCols = sheet.getLastColumn();
  var headerRange = sheet.getRange(1, 1, 1, totalCols);
  headerRange.setFontWeight("bold").setBackground("#f3f4f6");
  sheet.setFrozenRows(1);

  // ── 9. Convertir a tabla nativa (requiere Sheets API) ────
  _convertirATabla(sheet);
}

// Helper: buscar columna por encabezado o insertarla en posición preferida
function _findOrInsertHeader(sheet, headers, headerName, preferredPos) {
  for (var i = 0; i < headers.length; i++) {
    if (String(headers[i]).trim() === headerName) return i + 1;
  }
  // No existe: insertar en la posición preferida (si hay suficientes columnas)
  var totalCols = sheet.getLastColumn();
  if (preferredPos <= totalCols + 1) {
    if (preferredPos <= totalCols) {
      sheet.insertColumnBefore(preferredPos);
    }
    sheet.getRange(1, preferredPos).setValue(headerName);
    return preferredPos;
  }
  // Si no hay suficientes columnas, agregar al final
  var newCol = totalCols + 1;
  sheet.getRange(1, newCol).setValue(headerName);
  return newCol;
}

// ── 9. Tabla nativa con Sheets API avanzada ─────────────────
function _convertirATabla(sheet) {
  try {
    var lastRow = sheet.getLastRow();
    var lastCol = sheet.getLastColumn();
    if (lastRow < 1 || lastCol < 1) return;

    var ss     = sheet.getParent();
    var ssId   = ss.getId();
    var sheetId = sheet.getSheetId();
    var sheetName = sheet.getName();

    // Nombre de tabla = nombre de la hoja (solo alfanumérico y _)
    var tableName = sheetName.replace(/[^a-zA-Z0-9_]/g, "_");

    // Verificar si ya existe una tabla en esta hoja
    try {
      var existing = Sheets.spreadsheets.get(ssId, {
        ranges: [sheetName],
        fields: "sheets.bandedRanges"
      });
      // Si ya tiene banding, no agregar otro
      if (existing.sheets && existing.sheets[0] &&
          existing.sheets[0].bandedRanges && existing.sheets[0].bandedRanges.length > 0) {
        return;
      }
    } catch(ex) {}

    // Aplicar banding (tabla de color) usando Sheets API
    var bandingRequest = {
      addBanding: {
        bandedRange: {
          range: {
            sheetId:          sheetId,
            startRowIndex:    0,
            startColumnIndex: 0,
            endRowIndex:      Math.max(lastRow, 50),
            endColumnIndex:   lastCol
          },
          rowProperties: {
            headerColor:         { red: 0.176, green: 0.192, blue: 0.208 }, // #2D3134 oscuro
            firstBandColor:      { red: 1.0,   green: 1.0,   blue: 1.0   }, // blanco
            secondBandColor:     { red: 0.953, green: 0.969, blue: 0.988 }  // #F3F7FC azul pálido
          }
        }
      }
    };

    Sheets.spreadsheets.batchUpdate({ requests: [bandingRequest] }, ssId);

    // Hacer el texto del header blanco (contrasta con el fondo oscuro)
    sheet.getRange(1, 1, 1, lastCol)
      .setFontColor("#FFFFFF")
      .setFontWeight("bold")
      .setBackground("#2D3134");

  } catch(err) {
    // Si falla la API avanzada, solo aplicar estilo básico (no es un error crítico)
    Logger.log("_convertirATabla: " + err.toString());
    sheet.getRange(1, 1, 1, sheet.getLastColumn())
      .setFontWeight("bold").setBackground("#334155").setFontColor("#FFFFFF");
  }
}

// ============================================================
// C. SINCRONIZACION EN TIEMPO REAL
//    Trigger: sincronizarWP > Al editar
// ============================================================
function sincronizarWP(e) {
  if (!e || !e.range) return;

  var sheet    = e.source.getActiveSheet();
  var tabName  = sheet.getName();
  var row      = e.range.getRow();
  var lastCol  = sheet.getLastColumn();

  if (row === 1) return;

  // ── Protección de columna A (ID): revertir si el usuario la editó ────────
  var editedCol = e.range.getColumn();
  if (editedCol === 1) {
    var oldVal = (e.oldValue !== undefined && e.oldValue !== null) ? String(e.oldValue).trim() : "";
    var newVal = String(e.range.getValue()).trim();
    if (oldVal !== "" && oldVal !== newVal) {
      // Tenía un ID previo y el usuario lo cambió → revertir
      e.range.setValue(oldVal);
      e.source.toast(
        "La columna de ID (_ws_import_id) no se puede editar manualmente. " +
        "Si necesitas un ID nuevo, borra la fila y créala vacía.",
        "ID protegido 🔒", 6
      );
      return; // No enviar al webhook
    }
  }

  var headers   = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
  var rowValues = sheet.getRange(row, 1, 1, lastCol).getValues()[0];

  // Detectar columnas de control
  var statusCol = -1, viewCol = -1;
  for (var h = 0; h < headers.length; h++) {
    var hTrim = String(headers[h]).trim();
    if (hTrim === "wp_status_wordpress") statusCol = h + 1;
    if (hTrim === "view_display")        viewCol   = h + 1;
  }

  // Auto-generar _ws_import_id si columna A está vacía
  var currentId = String(rowValues[0]).trim();
  if (currentId === "" || currentId === "0") {
    var newId = Utilities.getUuid().replace(/-/g, "").substring(0, 16);
    sheet.getRange(row, 1).setValue(newId);
    rowValues[0] = newId;
    currentId    = newId;
  }

  // Auto-rellenar wp_status_wordpress
  if (statusCol > 0 && String(rowValues[statusCol - 1]).trim() === "") {
    sheet.getRange(row, statusCol).setValue("publish");
    rowValues[statusCol - 1] = "publish";
  }

  // Auto-rellenar view_display
  if (viewCol > 0 && String(rowValues[viewCol - 1]).trim() === "") {
    sheet.getRange(row, viewCol).setValue("TRUE");
    rowValues[viewCol - 1] = "TRUE";
  }

  // Actualizar cache
  _cacheGuardarFila(tabName, rowValues, headers);

  // Construir payload
  var rowData  = {};
  var idHeader = String(headers[0]).trim();
  for (var i = 0; i < headers.length; i++) {
    var hName = String(headers[i]).trim();
    if (hName) rowData[hName] = (rowValues[i] !== undefined ? String(rowValues[i]) : "");
  }

  var payload = {
    secret:    WEBHOOK_SECRET,
    tab_name:  tabName,
    id_column: idHeader,
    row_data:  rowData
  };

  var options = {
    method:             "post",
    contentType:        "application/json",
    payload:            JSON.stringify(payload),
    muteHttpExceptions: true
  };

  // Columna de log: la que empieza con "Estado" o la primera después de los datos
  var logCol = lastCol + 1;
  for (var lh = 0; lh < headers.length; lh++) {
    if (String(headers[lh]).trim().toLowerCase().startsWith("estado")) {
      logCol = lh + 1; break;
    }
  }

  try {
    var resp = UrlFetchApp.fetch(WEBHOOK_URL, options);
    var code = resp.getResponseCode();
    var msg  = code === 200 ? "OK " + new Date().toLocaleTimeString() : "ERROR HTTP " + code;
    sheet.getRange(row, logCol).setValue(msg);
    // Limpiar el log después de 4 segundos para no acumular
    Utilities.sleep(4000);
    sheet.getRange(row, logCol).clearContent();
  } catch (err) {
    sheet.getRange(row, logCol).setValue("FALLA: " + err.toString().substring(0, 60));
    Utilities.sleep(4000);
    sheet.getRange(row, logCol).clearContent();
  }
}

// ============================================================
// D. PROTECCION ANTI-BORRADO + AUTO-INIT HOJA NUEVA
//    Trigger: onChangeHandler > Al modificar
// ============================================================
function onChangeHandler(e) {
  if (!e) return;
  var changeType = e.changeType || "";

  // ── Hoja nueva insertada: inicializar automáticamente ────
  if (changeType === "INSERT_SHEET") {
    var ss          = e.source;
    var props       = PropertiesService.getScriptProperties();
    var knownJson   = props.getProperty("ws_known_sheets") || "[]";
    var knownSheets = {};
    try { var arr = JSON.parse(knownJson); for (var ki = 0; ki < arr.length; ki++) knownSheets[arr[ki]] = true; } catch(ex) {}

    var allSheets = ss.getSheets();
    var newSheet  = null;

    // Detectar la hoja que NO estaba en la lista guardada
    for (var si = 0; si < allSheets.length; si++) {
      var sName = allSheets[si].getName();
      if (!knownSheets[sName]) {
        newSheet = allSheets[si];
        break;
      }
    }

    // Si no la detectamos por cache, usar la activa como fallback
    if (!newSheet) newSheet = ss.getActiveSheet();

    if (newSheet) {
      var headerA = newSheet.getLastColumn() > 0
        ? String(newSheet.getRange(1, 1).getValue()).trim() : "";
      if (headerA !== "_ws_import_id" && headerA !== "backendId") {
        Utilities.sleep(1000); // Dar tiempo a que Sheets registre la hoja
        _inicializarHoja(newSheet);
        _cacheHoja(newSheet);
        ss.toast("Hoja '" + newSheet.getName() + "' inicializada con WP Sheets Engine.", "WP Sheets Engine", 5);
      }
    }

    // Actualizar lista de hojas conocidas
    var updatedNames = allSheets.map(function(s) { return s.getName(); });
    props.setProperty("ws_known_sheets", JSON.stringify(updatedNames));
    return;
  }

  // ── Filas eliminadas: protección anti-borrado ────────────
  if (changeType !== "REMOVE_ROW") return;

  var ss      = e.source;
  var sheet   = ss.getActiveSheet();
  var tabName = sheet.getName();

  // IDs actuales en la hoja
  var lastRow    = sheet.getLastRow();
  var currentIds = {};
  if (lastRow > 1) {
    var colA = sheet.getRange(2, 1, lastRow - 1, 1).getValues();
    for (var i = 0; i < colA.length; i++) {
      var v = String(colA[i][0]).trim();
      if (v) currentIds[v] = true;
    }
  }

  // Comparar contra cache
  var props      = PropertiesService.getScriptProperties();
  var allKeys    = props.getKeys();
  var prefix     = "ws_" + tabName + "_";
  var reinserted = 0;

  for (var k = 0; k < allKeys.length; k++) {
    var key = allKeys[k];
    if (key.indexOf(prefix) !== 0) continue;
    var raw = props.getProperty(key);
    if (!raw) continue;
    var cached;
    try { cached = JSON.parse(raw); } catch(ex) { continue; }

    var cachedId     = String(cached.id || "").trim();
    var cachedStatus = String(cached.status || "publish").trim().toLowerCase();
    var cachedData   = cached.rowData || [];

    if (!cachedId || currentIds[cachedId]) continue;

    if (cachedStatus === "trash") {
      props.deleteProperty(key);
    } else {
      // Re-insertar la fila
      if (cachedData.length > 0) {
        var nextRow = sheet.getLastRow() + 1;
        var range   = sheet.getRange(nextRow, 1, 1, cachedData.length);
        range.setValues([cachedData]);
        // Amarillo 3 segundos, luego quitar
        range.setBackground("#fff3cd");
        Utilities.sleep(3000);
        range.setBackground(null);
      }
      reinserted++;
    }
  }

  if (reinserted > 0) {
    ss.toast(
      reinserted + " fila(s) restaurada(s). Para eliminar de WordPress, cambia wp_status_wordpress a 'trash' primero.",
      "Borrado bloqueado", 8
    );
  }
}

// ============================================================
// E. CACHE (anti-borrado y auto-init)
// ============================================================
function _cacheTodasLasHojas() {
  var sheets = SpreadsheetApp.getActiveSpreadsheet().getSheets();
  for (var i = 0; i < sheets.length; i++) { _cacheHoja(sheets[i]); }
}

function _cacheHoja(sheet) {
  var lastRow = sheet.getLastRow();
  var lastCol = sheet.getLastColumn();
  if (lastRow < 2 || lastCol < 1) return;

  var tabName = sheet.getName();
  var headers = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
  var statusIdx = -1;
  for (var h = 0; h < headers.length; h++) {
    if (String(headers[h]).trim() === "wp_status_wordpress") { statusIdx = h; break; }
  }

  var allData = sheet.getRange(2, 1, lastRow - 1, lastCol).getValues();
  var props   = PropertiesService.getScriptProperties();

  for (var r = 0; r < allData.length; r++) {
    var row    = allData[r];
    var id     = String(row[0]).trim();
    if (!id || id === "0") continue;
    var status = statusIdx >= 0 ? String(row[statusIdx]).trim() : "publish";
    var key    = "ws_" + tabName + "_" + id;
    var val    = JSON.stringify({ id: id, status: status, rowData: row });
    if (val.length < 8500) { try { props.setProperty(key, val); } catch(ex) {} }
  }
}

function _cacheGuardarFila(tabName, rowValues, headers) {
  var id = String(rowValues[0]).trim();
  if (!id || id === "0") return;
  var statusIdx = -1;
  for (var i = 0; i < headers.length; i++) {
    if (String(headers[i]).trim() === "wp_status_wordpress") { statusIdx = i; break; }
  }
  var status = statusIdx >= 0 ? String(rowValues[statusIdx]).trim() : "publish";
  var key    = "ws_" + tabName + "_" + id;
  var val    = JSON.stringify({ id: id, status: status, rowData: rowValues });
  if (val.length < 8500) { try { PropertiesService.getScriptProperties().setProperty(key, val); } catch(ex) {} }
}</code></pre>
            </div>
            <script>
            document.addEventListener('DOMContentLoaded', function() {
                var copyBtn = document.getElementById('copy-script-btn');
                if(copyBtn) {
                    copyBtn.addEventListener('click', function() {
                        var code = document.getElementById('apps-script-code').innerText;
                        navigator.clipboard.writeText(code).then(function() {
                            var originalHTML = copyBtn.innerHTML;
                            copyBtn.innerHTML = '¡Copiado! ✅';
                            copyBtn.style.background = '#10B981';
                            setTimeout(function() {
                                copyBtn.innerHTML = originalHTML;
                                copyBtn.style.background = '#3B82F6';
                            }, 2000);
                        });
                    });
                }
            });
            </script>
        
            <!-- Webhook Debug Log -->
            <div class="ws-card" style="border-top: 4px solid #F59E0B; margin-top:20px;">
                <h2 style="margin-top:0; font-size:18px; color:#B45309;">🔎 Registro de Diagnóstico (Logs)</h2>
                <p style="color:#475569; font-size:13px;">Si editas en Google Sheets y no ves el cambio en WordPress, revisa el último mensaje recibido del Webhook:</p>
                <div style="background:#1E293B; color:#F8FAFC; padding:15px; border-radius:6px; font-family:monospace; font-size:12px;">
                    <?php echo esc_html(get_option('wpsheets_last_webhook_error', 'Esperando el primer envío de datos desde Google Sheets...')); ?>
                </div>
            </div>

    </div>
    </div>
    <?php
}
