<?php
if (!defined('ABSPATH')) exit;

function wpsheets_page_woo() {
    if (!class_exists('WooCommerce')) {
        echo '<div class="wrap"><h1>WooCommerce no está activo</h1></div>';
        return;
    }

    $args = [
        'post_type' => 'product',
        'post_status' => 'any',
        'meta_key' => '_wpsheets_dummy',
        'meta_value' => '1',
        'posts_per_page' => -1,
        'fields' => 'ids'
    ];
    $dummy_products = get_posts($args);
    $dummy_count = count($dummy_products);
    ?>
    <div class="wpsheets-wrap">
        <div class="wpsheets-header">
            <div class="wpsheets-header-title">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#8B5CF6" stroke-width="2"><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>
                <h1>Panel de Desarrollo WooCommerce</h1>
            </div>
            <div class="wpsheets-subtitle">Herramientas de pruebas avanzadas (Dummy Data Generator).</div>
        </div>

        <div style="display:grid; grid-template-columns: 2fr 1fr; gap:20px;">
            <!-- Herramientas de Prueba Avanzadas -->
            <div class="ws-card">
                <h2 style="margin-top:0; font-size:18px; color:#4C1D95;">🧪 Generador Avanzado de Productos</h2>
                <p style="color:#475569; font-size:13px;">Crea conjuntos de 5 productos completos con configuraciones reales (precios, stock, peso, envío, atributos). Útil para probar Divi, filtros y carritos.</p>

                <form id="dummy-form" style="background:#F8FAFC; padding:20px; border-radius:8px; border:1px solid #E2E8F0; margin:20px 0;">
                    <div style="display:grid; grid-template-columns: 1fr 1fr; gap:15px; margin-bottom:20px;">
                        <label style="display:flex; align-items:center; gap:10px; cursor:pointer;">
                            <input type="checkbox" name="dummy_types[]" value="simple" checked style="width:18px; height:18px;">
                            <span style="font-weight:600; color:#334155;">5 Productos Simples</span>
                            <span style="font-size:12px; color:#64748B;">(Físicos con peso y dimensiones)</span>
                        </label>
                        <label style="display:flex; align-items:center; gap:10px; cursor:pointer;">
                            <input type="checkbox" name="dummy_types[]" value="variable" checked style="width:18px; height:18px;">
                            <span style="font-weight:600; color:#334155;">5 Productos Variables</span>
                            <span style="font-size:12px; color:#64748B;">(Atributos: Color y Talla)</span>
                        </label>
                        <label style="display:flex; align-items:center; gap:10px; cursor:pointer;">
                            <input type="checkbox" name="dummy_types[]" value="digital" style="width:18px; height:18px;">
                            <span style="font-weight:600; color:#334155;">5 Productos Digitales</span>
                            <span style="font-size:12px; color:#64748B;">(Descargables / Virtuales)</span>
                        </label>
                        <label style="display:flex; align-items:center; gap:10px; cursor:pointer;">
                            <input type="checkbox" name="dummy_types[]" value="grouped" style="width:18px; height:18px;">
                            <span style="font-weight:600; color:#334155;">5 Productos Agrupados</span>
                            <span style="font-size:12px; color:#64748B;">(Packs de productos simples)</span>
                        </label>
                    </div>

                    <div style="display:flex; gap:10px; border-top:1px solid #E2E8F0; padding-top:15px;">
                        <button type="submit" id="btn-create-dummy" class="ws-btn ws-btn-primary" style="background:#8B5CF6; border-color:#8B5CF6;">
                            🚀 Generar Productos de Prueba
                        </button>
                    </div>
                </form>
                <div id="dummy-result" class="ws-alert" style="display:none;"></div>
            </div>

            
            
            <!-- Inicializar / Restaurar WooCommerce -->
            <div class="ws-card" style="grid-column: 1 / -1; margin-top: 10px; border-left: 4px solid #8B5CF6;">
                <h2 style="margin-top:0; font-size:18px; color:#4C1D95;">🔧 Inicializar / Restaurar Ecosistema WooCommerce</h2>
                <p style="color:#475569; font-size:13px;">Crea o restaura las hojas en Google Sheets: <strong>Products_Woo, Categories_Woo, Tags_Woo, Brands_Woo, Attributes_Woo, Orders_Woo, Coupons_Woo</strong>. Las hojas existentes no se sobreescriben. También configura el auto-mapeo completo.</p>
                <button id="btn-init-woo-panel" class="ws-btn ws-btn-primary" style="background:#8B5CF6; border-color:#8B5CF6;">
                    🔧 Restaurar / Inicializar WooCommerce
                </button>
                <div id="init-woo-result" class="ws-alert" style="display:none; margin-top:15px;"></div>
            </div>

            <!-- Exportar entidades a Google Sheets -->
            <div class="ws-card" style="grid-column: 1 / -1; margin-top: 10px; border-left: 4px solid #3B82F6;">
                <h2 style="margin-top:0; font-size:18px; color:#1D4ED8;">⬆️ Exportar Datos a Google Sheets</h2>
                <p style="color:#475569; font-size:13px;">Exporta datos existentes de WordPress hacia las hojas de Google Sheets. Selecciona qué quieres exportar o usa "Exportar Todo" para hacerlo todo a la vez.</p>

                <div style="display:flex; gap:15px; flex-wrap:wrap; align-items:center; margin-bottom:15px;">
                    <select id="woo-export-entity" class="ws-select" style="max-width:320px;">
                        <option value="all">📦 Exportar Todo (todas las hojas Woo)</option>
                        <option value="product">🛍️ Solo Productos → Products_Woo</option>
                        <option value="product_cat">📂 Solo Categorías → Categories_Woo</option>
                        <option value="product_tag">🏷️ Solo Etiquetas → Tags_Woo</option>
                        <?php
                        $brand_slugs_woo = ['product_brands','pwb-brand','yith_product_brand','product_brand'];
                        $has_brand = false;
                        foreach (get_taxonomies([], 'objects') as $wt) {
                            foreach ($brand_slugs_woo as $bs) {
                                if (strpos($wt->name, $bs) !== false) { $has_brand = true; break 2; }
                            }
                        }
                        if ($has_brand): ?>
                        <option value="brands">⭐ Solo Marcas → Brands_Woo</option>
                        <?php endif;
                        if (function_exists('wc_get_attribute_taxonomies') && !empty(wc_get_attribute_taxonomies())): ?>
                        <option value="attributes">⚙️ Solo Atributos → Attributes_Woo</option>
                        <?php endif; ?>
                    </select>
                    <button id="btn-export-entity" class="ws-btn ws-btn-primary" style="background:#3B82F6; border-color:#3B82F6;">
                        ⬆️ Exportar Selección
                    </button>
                </div>
                <div id="export-result" class="ws-alert" style="display:none; margin-top:15px;"></div>
            </div>

            <!-- Panel Lateral de Control -->
            <div>
                <div class="ws-card">
                    <h2 style="margin-top:0; font-size:18px; color:#EF4444;">🗑️ Limpieza</h2>
                    <div style="background:#FEF2F2; padding:15px; border-radius:8px; margin:15px 0; text-align:center;">
                        <strong style="font-size:32px; color:#991B1B; display:block;"><?php echo $dummy_count; ?></strong>
                        <span style="color:#B91C1C; font-size:13px; font-weight:600;">Productos Dummy Activos</span>
                    </div>
                    <?php if ($dummy_count > 0): ?>
                    <button id="btn-delete-dummy" class="ws-btn ws-btn-secondary" style="width:100%; justify-content:center; color:#EF4444; border-color:#EF4444;">
                        Borrar Datos Dummy
                    </button>
                    <p style="font-size:11px; color:#64748B; text-align:center; margin-top:10px;">Solo se borrarán los productos generados por esta herramienta.</p>
                    <?php else: ?>
                    <p style="font-size:12px; color:#64748B; text-align:center;">No hay datos de prueba generados actualmente.</p>
                    <?php endif; ?>
                </div>

                <div class="ws-card">
                    <h2 style="margin-top:0; font-size:18px;">📊 Estadísticas Reales</h2>
                    <ul style="color:#475569; font-size:13px; line-height:2.2; margin:0; padding:0; list-style:none;">
                        <li style="border-bottom:1px solid #E2E8F0; padding-bottom:5px;">🛍️ Total Catálogo: <strong><?php echo wp_count_posts('product')->publish; ?></strong></li>
                        <li style="border-bottom:1px solid #E2E8F0; padding-bottom:5px; margin-top:5px;">📁 Categorías: <strong><?php echo wp_count_terms('product_cat'); ?></strong></li>
                        <li style="margin-top:5px;">🏷️ Etiquetas: <strong><?php echo wp_count_terms('product_tag'); ?></strong></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <script>
    jQuery(document).ready(function($) {
        $('#dummy-form').on('submit', function(e) {
            e.preventDefault();
            var types = [];
            $('input[name="dummy_types[]"]:checked').each(function() { types.push($(this).val()); });
            if(types.length === 0) { alert('Selecciona al menos un tipo de producto'); return; }

            var btn = $('#btn-create-dummy');
            btn.html('⏳ Generando (Esto tomará unos segundos)...').prop('disabled', true);
            $('#dummy-result').hide();

            $.post(ajaxurl, { 
                action: 'wpsheets_create_advanced_dummy', 
                nonce: '<?php echo wp_create_nonce("wpsheets_ajax_nonce"); ?>',
                types: types
            }, function(res) {
                if (res.success) { location.reload(); } 
                else { $('#dummy-result').addClass('ws-alert-error').html(res.data).show(); btn.html('🚀 Generar Productos').prop('disabled', false); }
            }).fail(function() {
                $('#dummy-result').addClass('ws-alert-error').html('Error de servidor timeout').show();
                btn.html('🚀 Generar Productos').prop('disabled', false);
            });
        });

        $('#btn-delete-dummy').on('click', function(e) {
            e.preventDefault();
            if(!confirm('¿Borrar todos los productos de prueba?')) return;
            var btn = $(this);
            btn.text('Borrando...').prop('disabled', true);
            $.post(ajaxurl, { action: 'wpsheets_delete_dummy_woo', nonce: '<?php echo wp_create_nonce("wpsheets_ajax_nonce"); ?>' }, function(res) {
                if (res.success) { location.reload(); } 
                else { alert('Error: ' + res.data); btn.text('Borrar').prop('disabled', false); }
            });
        });
    
        
        // Inicializar WooCommerce
        $('#btn-init-woo-panel').on('click', function(e) {
            e.preventDefault();
            var btn = $(this);
            btn.html('Inicializando...').prop('disabled', true);
            $('#init-woo-result').hide();
            $.post(ajaxurl, { action: 'wpsheets_init_woocommerce', nonce: wpSheets.nonce }, function(res) {
                var box = $('#init-woo-result');
                box.removeClass('ws-alert-error ws-alert-success');
                if (res.success) box.addClass('ws-alert-success').html(res.data).show();
                else             box.addClass('ws-alert-error').html(res.data).show();
            }).always(function() { btn.html('🔧 Restaurar / Inicializar WooCommerce').prop('disabled', false); });
        });

        // Exportar entidad seleccionada
        $('#btn-export-entity').on('click', function(e) {
            e.preventDefault();
            var btn    = $(this);
            var entity = $('#woo-export-entity').val();
            btn.html('Exportando...').prop('disabled', true);
            $('#export-result').hide();
            $.post(ajaxurl, {
                action: 'wpsheets_woo_export_entity',
                nonce:  '<?php echo wp_create_nonce("wpsheets_ajax_nonce"); ?>',
                entity: entity
            }, function(res) {
                var box = $('#export-result');
                box.removeClass('ws-alert-error ws-alert-success');
                if (res.success) box.addClass('ws-alert-success').html(res.data).show();
                else             box.addClass('ws-alert-error').html(res.data).show();
            }).always(function() { btn.html('⬆️ Exportar Selección').prop('disabled', false); });
        });

        $('#btn-inject-sheet').on('click', function(e) {
            e.preventDefault();
            var btn = $(this);
            btn.text('Inyectando a Google Sheets...').prop('disabled', true);
            $('#inject-result').hide();
            $.post(ajaxurl, { action: 'wpsheets_inject_sheet_dummies', nonce: '<?php echo wp_create_nonce("wpsheets_ajax_nonce"); ?>' }, function(res) {
                if (res.success) { $('#inject-result').removeClass('ws-alert-error').addClass('ws-alert-success').html(res.data).show(); } 
                else { $('#inject-result').removeClass('ws-alert-success').addClass('ws-alert-error').html(res.data).show(); }
                btn.text('📝 Inyectar Datos en Google Sheets').prop('disabled', false);
            });
        });
});
    </script>
    <?php
}

// AJAX: Generador Avanzado
add_action('wp_ajax_wpsheets_create_advanced_dummy', function() {
    check_ajax_referer('wpsheets_ajax_nonce', 'nonce');
    if (!class_exists('WooCommerce')) wp_send_json_error('WooCommerce no está activo');

    $types = isset($_POST['types']) ? (array) $_POST['types'] : [];
    if (empty($types)) wp_send_json_error('No seleccionaste ningún tipo');

    // Helper functions for random data
    
    require_once(ABSPATH . 'wp-admin/includes/media.php');
    require_once(ABSPATH . 'wp-admin/includes/file.php');
    require_once(ABSPATH . 'wp-admin/includes/image.php');

    // Descargar una imagen genérica para todos (para no hacer timeout descargando 20)
    $img_url = 'https://picsum.photos/800/800.jpg';
    $img_id = media_sideload_image($img_url, 0, 'Imagen Dummy Generada', 'id');
    if (is_wp_error($img_id)) { $img_id = ''; }

    function get_random_cat() {

        $cats = ['Electrónica Dummy', 'Ropa Dummy', 'Hogar Dummy', 'Digital Dummy'];
        $name = $cats[array_rand($cats)];
        $term = term_exists($name, 'product_cat');
        if (!$term) { $term = wp_insert_term($name, 'product_cat'); }
        return is_array($term) ? $term['term_id'] : $term;
    }

    $created = 0;

    // 1. SIMPLES (Físicos con peso y medidas)
    if (in_array('simple', $types)) {
        for ($i=1; $i<=5; $i++) {
            $p = new WC_Product_Simple();
            $p->set_name("Dummy Físico - Producto Simple {$i}");
            $p->set_status('publish');
            $p->set_description("Este es un producto físico de prueba completo. Cuenta con dimensiones, peso y configuración de inventario. Generado por WP Sheets Engine.");
            $p->set_short_description("Producto físico con peso de prueba {$i}");
            $p->set_sku("DMY-SMP-" . rand(1000, 9999));
            $p->set_regular_price(rand(100, 900) . '.00');
            if (rand(0,1)) $p->set_sale_price((float)$p->get_regular_price() * 0.8);

            $p->set_manage_stock(true);
            $p->set_stock_quantity(rand(5, 50));
            $p->set_stock_status('instock');

            // Medidas físicas
            $p->set_weight(rand(1, 10) . '.5');
            $p->set_length(rand(10, 50));
            $p->set_width(rand(10, 30));
            $p->set_height(rand(5, 20));

            $p->set_category_ids([get_random_cat()]);
            if(!empty($img_id)) $p->set_image_id($img_id);
            $p->add_meta_data('_wpsheets_dummy', '1', true);
            $p->save();
            $created++;
        }
    }

    // 2. DIGITALES (Virtual / Descargable)
    if (in_array('digital', $types)) {
        for ($i=1; $i<=5; $i++) {
            $p = new WC_Product_Simple();
            $p->set_name("Dummy Digital - Ebook / Curso {$i}");
            $p->set_status('publish');
            $p->set_virtual(true);
            $p->set_downloadable(true);
            $p->set_description("Producto virtual y descargable. No tiene costo de envío ni dimensiones. Generado por WP Sheets Engine.");
            $p->set_sku("DMY-DIG-" . rand(1000, 9999));
            $p->set_regular_price(rand(50, 300) . '.00');

            $download = new WC_Product_Download();
            $download->set_id(md5(uniqid()));
            $download->set_name("Archivo de Prueba {$i}");
            $download->set_file(site_url('/wp-content/dummy-file.pdf'));
            $p->set_downloads([$download]);
            $p->set_download_limit(0); // ilimitado

            $p->set_category_ids([get_random_cat()]);
            if(!empty($img_id)) $p->set_image_id($img_id);
            $p->add_meta_data('_wpsheets_dummy', '1', true);
            $p->save();
            $created++;
        }
    }

    // 3. VARIABLES (Con Atributos)
    if (in_array('variable', $types)) {
        for ($i=1; $i<=5; $i++) {
            $p = new WC_Product_Variable();
            $p->set_name("Dummy Variable - Camiseta/Zapato {$i}");
            $p->set_status('publish');
            $p->set_sku("DMY-VAR-" . rand(1000, 9999));
            $p->set_category_ids([get_random_cat()]);

            $colors = ['Rojo', 'Azul', 'Negro'];
            $sizes = ['S', 'M', 'L'];

            $attr1 = new WC_Product_Attribute();
            $attr1->set_id(0); $attr1->set_name('Color');
            $attr1->set_options($colors); $attr1->set_position(0);
            $attr1->set_visible(true); $attr1->set_variation(true);

            $attr2 = new WC_Product_Attribute();
            $attr2->set_id(0); $attr2->set_name('Talla');
            $attr2->set_options($sizes); $attr2->set_position(1);
            $attr2->set_visible(true); $attr2->set_variation(true);

            $p->set_attributes([$attr1, $attr2]);
            if(!empty($img_id)) $p->set_image_id($img_id);
            $p->add_meta_data('_wpsheets_dummy', '1', true);
            $parent_id = $p->save();

            // Crear solo un par de variaciones reales para no saturar el servidor
            foreach (['Rojo', 'Azul'] as $color) {
                foreach (['S', 'M'] as $size) {
                    $v = new WC_Product_Variation();
                    $v->set_parent_id($parent_id);
                    $v->set_attributes(['color' => $color, 'talla' => $size]);
                    $v->set_regular_price(rand(150, 400) . '.00');
                    $v->set_manage_stock(true);
                    $v->set_stock_quantity(rand(2, 10));
                    $v->set_weight(rand(1,5) . '.0');
                    $v->set_length(rand(10,30));
                    $v->set_width(rand(10,20));
                    $v->set_height(rand(5,15));
                    $v->set_description('Descripción específica para la variación de color '.$color.' y talla '.$size.'. Incluye medidas exactas.');
                    if(!empty($img_id)) $v->set_image_id($img_id); // Variaciones también tienen peso
                    $v->add_meta_data('_wpsheets_dummy', '1', true);
                    $v->save();
                }
            }
            $created++;
        }
    }

    // 4. AGRUPADOS (Packs)
    if (in_array('grouped', $types)) {
        // Obtenemos 3 simples creados para agruparlos
        $simples = get_posts(['post_type' => 'product', 'meta_key' => '_wpsheets_dummy', 'posts_per_page' => 3, 'fields' => 'ids']);

        for ($i=1; $i<=5; $i++) {
            $p = new WC_Product_Grouped();
            $p->set_name("Dummy Pack - Colección Agrupada {$i}");
            $p->set_status('publish');
            $p->set_description("Este es un producto agrupado. Permite al cliente comprar varios productos simples desde una misma página.");
            $p->set_sku("DMY-GRP-" . rand(1000, 9999));
            $p->set_category_ids([get_random_cat()]);

            if (!empty($simples)) {
                $p->set_children($simples);
            }

            if(!empty($img_id)) $p->set_image_id($img_id);
            $p->add_meta_data('_wpsheets_dummy', '1', true);
            $p->save();
            $created++;
        }
    }

    wp_send_json_success("Generados $created productos base (más sus variaciones).");
});

add_action('wp_ajax_wpsheets_delete_dummy_woo', function() {
    check_ajax_referer('wpsheets_ajax_nonce', 'nonce');

    $args = [
        'post_type' => ['product', 'product_variation'],
        'post_status' => 'any',
        'meta_key' => '_wpsheets_dummy',
        'meta_value' => '1',
        'posts_per_page' => -1,
        'fields' => 'ids'
    ];
    $products = get_posts($args);
    foreach($products as $pid) {
        wp_delete_post($pid, true); // true = force delete
    }
    wp_send_json_success('Borrados con éxito');
});


// AJAX: Inyectar a Google Sheets
add_action('wp_ajax_wpsheets_inject_sheet_dummies', function() {
    check_ajax_referer('wpsheets_ajax_nonce', 'nonce');
    $sid = get_option('wpsheets_spreadsheet_id');
    if (empty($sid)) wp_send_json_error('No tienes configurado tu ID de Google Sheets.');

    // 28 columns matching the Headers created previously
    $rows = [
        ['DUMMY-GS-1', 'Gorra Minimalista', 'gorra-min', 'publish', 'SKU-GS-1', '0', '0', 'visible', '50', 'instock', 'no', 'yes', '300', '250', '0.1', '15', '10', '5', 'taxable', '', 'simple', 'Accesorios', 'moda', '', '', '', '', ''],
        ['DUMMY-GS-2', 'Reloj Inteligente', 'rel-int', 'publish', 'SKU-GS-2', '0', '0', 'visible', '15', 'instock', 'no', 'yes', '1500', '', '0.3', '10', '10', '10', 'taxable', '', 'simple', 'Electrónica', 'gadget', '', '', '', '', ''],
        ['DUMMY-GS-3', 'Ebook Emprendimiento', 'ebook-emp', 'publish', 'SKU-GS-3', '1', '1', 'visible', '', 'instock', 'no', 'no', '200', '', '', '', '', '', 'taxable', '', 'simple', 'Digital', 'libro', '', '', '', '', '']
    ];

    $res = WPSheets_Google_API::update_sheet_data($sid, 'Productos_WooCommerce!A2', $rows);
    if (is_wp_error($res)) wp_send_json_error('Error API Google: ' . $res->get_error_message());

    wp_send_json_success('✅ ¡Éxito! Abre tu Google Sheets o el Data Grid y verás 3 productos listos para ser editados y sincronizados.');
});


add_action('wp_ajax_wpsheets_export_woo_mass', function() {
    check_ajax_referer('wpsheets_ajax_nonce', 'nonce');
    if (!class_exists('WooCommerce')) wp_send_json_error('WooCommerce no está activo');

    $sid = get_option('wpsheets_spreadsheet_id');
    if (empty($sid)) wp_send_json_error('No tienes configurado tu ID de Google Sheets.');

    // 1. Fetch headers
    $headers_raw = WPSheets_Google_API::get_sheet_data($sid, 'Productos_WooCommerce!1:1');
    if (is_wp_error($headers_raw) || empty($headers_raw[0])) wp_send_json_error('No se pudieron leer los encabezados de tu hoja.');
    $headers = $headers_raw[0];

    // 2. Get all products
    $args = [
        'post_type' => ['product', 'product_variation'],
        'post_status' => 'any',
        'posts_per_page' => -1,
        'fields' => 'ids'
    ];
    $products = get_posts($args);
    if (empty($products)) wp_send_json_error('No hay productos en WooCommerce para exportar.');

    // 3. Build mass payload
    $mapping_all = get_option('wpsheets_fields_mapping', []);
    $mapping = isset($mapping_all['product']) ? $mapping_all['product'] : [];

    $rows_to_append = [];
    foreach ($products as $pid) {
        $product = wc_get_product($pid);
        if (!$product) continue;

        $item_id = get_post_meta($pid, '_ws_import_id', true);
        if (empty($item_id)) {
            $item_id = 'PRODUCT-' . $pid . '-' . rand(100,999);
            update_post_meta($pid, '_ws_import_id', $item_id);
        }

        $row_values = array_fill(0, count($headers), '');
        $post = get_post($pid);

        // Simple mapping
        foreach ($headers as $index => $raw_header) {
            $safeHeader = strtolower(preg_replace('/[^a-zA-Z0-9_]/', '_', $raw_header));
            if ($index === 0) {
                $row_values[0] = $item_id;
                continue;
            }

            
            // Si el encabezado coincide con nuestra configuración de mapeo
            if (isset($mapping[$safeHeader])) {
                $config = $mapping[$safeHeader];
                $type = $config['type'];
                $opts = $config['options'] ?? [];

                if ($type === 'wp_title') $row_values[$index] = $post->post_title;
                elseif ($type === 'wp_content') $row_values[$index] = $post->post_content;
                elseif ($type === 'wp_excerpt') $row_values[$index] = $post->post_excerpt;
                elseif ($type === 'wp_status') $row_values[$index] = $post->post_status;
                elseif ($type === 'wp_slug') $row_values[$index] = $post->post_name;
                elseif ($type === 'taxonomy') {
                    $tax_slug = $opts['tax_slug'] ?? '';
                    if ($tax_slug) {
                        $terms = get_the_terms($pid, $tax_slug);
                        if (!empty($terms) && !is_wp_error($terms)) {
                            $term_names = [];
                            foreach($terms as $term) { $term_names[] = $term->name; }
                            $row_values[$index] = implode(', ', $term_names);
                        }
                    }
                }
                elseif ($type === 'meta' || $type === 'acf') {
                    $meta_key = $opts['meta_key'] ?? '';
                    if ($meta_key) {
                        if ($meta_key === '_price') $row_values[$index] = $product->get_price();
                        elseif ($meta_key === '_regular_price') $row_values[$index] = $product->get_regular_price();
                        elseif ($meta_key === '_sale_price') $row_values[$index] = $product->get_sale_price();
                        elseif ($meta_key === '_stock') $row_values[$index] = $product->get_stock_quantity();
                        elseif ($meta_key === '_stock_status') $row_values[$index] = $product->get_stock_status();
                        elseif ($meta_key === '_sku') $row_values[$index] = $product->get_sku();
                        elseif ($meta_key === '_weight') $row_values[$index] = $product->get_weight();
                        else $row_values[$index] = get_post_meta($pid, $meta_key, true);
                    }
                }
            }

        }
        $rows_to_append[] = $row_values;
    }

    // 4. Send to Google Sheets (Append everything)
    $res = WPSheets_Google_API::append_sheet_data($sid, 'Productos_WooCommerce!A1', $rows_to_append);
    if (is_wp_error($res)) wp_send_json_error('Error exportando: ' . $res->get_error_message());

    wp_send_json_success('✅ ¡Exportación completada! ' . count($rows_to_append) . ' productos enviados a Google Sheets.');
});

// ============================================================
// AJAX: Exportar entidades WooCommerce usando funciones bulk
// ============================================================
add_action('wp_ajax_wpsheets_woo_export_entity', function() {
    check_ajax_referer('wpsheets_ajax_nonce', 'nonce');
    if (!class_exists('WooCommerce')) wp_send_json_error('WooCommerce no activo.');

    $entity  = sanitize_text_field($_POST['entity'] ?? 'all');
    $results = [];

    $brand_slugs = ['product_brands', 'pwb-brand', 'yith_product_brand', 'product_brand'];
    $brand_tax   = '';
    foreach (get_taxonomies([], 'objects') as $t) {
        foreach ($brand_slugs as $bs) {
            if (strpos($t->name, $bs) !== false) { $brand_tax = $t->name; break 2; }
        }
    }

    if (in_array($entity, ['all', 'product'])) {
        $n = wpsheets_bulk_export_cpt('product', 'Products_Woo', 'product');
        if ($n > 0) $results[] = "<strong>{$n} productos</strong> exportados a Products_Woo";
    }
    if (in_array($entity, ['all', 'product_cat'])) {
        $n = wpsheets_bulk_export_taxonomy('product_cat', 'Categories_Woo', 'tax_product_cat');
        if ($n > 0) $results[] = "<strong>{$n} categorías</strong> exportadas a Categories_Woo";
    }
    if (in_array($entity, ['all', 'product_tag'])) {
        $n = wpsheets_bulk_export_taxonomy('product_tag', 'Tags_Woo', 'tax_product_tag');
        if ($n > 0) $results[] = "<strong>{$n} etiquetas</strong> exportadas a Tags_Woo";
    }
    if ($brand_tax && in_array($entity, ['all', 'brands'])) {
        $mapping_all = get_option('wpsheets_fields_mapping', []);
        $bkey = isset($mapping_all['tax_' . $brand_tax]) ? 'tax_' . $brand_tax : 'tax_brands_woo';
        $n = wpsheets_bulk_export_taxonomy($brand_tax, 'Brands_Woo', $bkey);
        if ($n > 0) $results[] = "<strong>{$n} marcas</strong> exportadas a Brands_Woo";
    }
    if (function_exists('wc_get_attribute_taxonomies') && in_array($entity, ['all', 'attributes'])) {
        $total = 0;
        foreach (wc_get_attribute_taxonomies() as $attr) {
            $total += wpsheets_bulk_export_taxonomy('pa_' . $attr->attribute_name, 'Attributes_Woo', 'tax_woo_attributes');
        }
        if ($total > 0) $results[] = "<strong>{$total} valores de atributos</strong> exportados a Attributes_Woo";
    }

    if (empty($results)) {
        wp_send_json_error('Sin datos para exportar. Verifica que las hojas están inicializadas y que hay datos en WordPress.');
    }
    wp_send_json_success('✅ Exportación completada:<br>' . implode('<br>', $results));
});

