<?php
if (!defined('ABSPATH')) exit;
function wpsheets_page_tax() {
    $taxs = get_option('wpsheets_taxonomies', []);
    if (isset($_POST['wpsheets_add_tax']) && check_admin_referer('wpsheets_save_tax')) { $id = sanitize_text_field($_POST['tax_id']); $new_tax = ['id' => $id ? $id : uniqid(), 'singular' => sanitize_text_field($_POST['singular']), 'plural' => sanitize_text_field($_POST['plural']), 'slug' => sanitize_title($_POST['slug']), 'post_types' => isset($_POST['post_types']) ? array_map('sanitize_title', $_POST['post_types']) : [], 'sheet' => sanitize_text_field($_POST['sheet'])]; if ($id) { foreach($taxs as $k => $t) { if($t['id'] === $id) $taxs[$k] = $new_tax; } $tax_action = 'actualizada'; } else { $taxs[] = $new_tax; $tax_action = 'creada'; }
        update_option('wpsheets_taxonomies', $taxs); update_option('wpsheets_needs_sync', '1');
        // Necesario: registrar la taxonomía ahora para que auto-sync funcione
        if (!empty($new_tax['post_types'])) {
            register_taxonomy($new_tax['slug'], $new_tax['post_types'], ['label' => $new_tax['plural'], 'public' => true, 'hierarchical' => true, 'show_in_rest' => true]);
        }
        // Auto-mapeo inteligente si hay hoja vinculada
        $tax_auto_msg = '';
        if (!empty($new_tax['sheet'])) {
            $mapped = wpsheets_auto_map_taxonomy($new_tax['slug'], $new_tax['sheet']);
            if ($mapped !== false) {
                $exported_t = wpsheets_bulk_export_taxonomy($new_tax['slug'], $new_tax['sheet'], 'tax_' . $new_tax['slug']);
                $tax_auto_msg = " Auto-mapeado ({$mapped} columnas).";
                if ($exported_t > 0) $tax_auto_msg .= " {$exported_t} términos exportados a Google Sheets.";
            } else {
                $tax_auto_msg = ' <em>Hoja no encontrada — mapea manualmente cuando la crees.</em>';
            }
        }
        echo '<div class="ws-alert ws-alert-success">Taxonomía ' . $tax_action . '.' . $tax_auto_msg . '</div>'; }
    if (isset($_GET['delete_tax'])) { $taxs = array_filter($taxs, function($t) { return $t['id'] !== $_GET['delete_tax']; }); update_option('wpsheets_taxonomies', array_values($taxs)); echo '<div class="ws-alert ws-alert-success">Taxonomía eliminada.</div>'; }
    $cpts = get_option('wpsheets_cpts', []); $tabs = get_option('wpsheets_spreadsheet_id') ? WPSheets_Google_API::get_spreadsheet_tabs(get_option('wpsheets_spreadsheet_id')) : [];
    ?>
    <div class="wpsheets-wrap">
        <div class="wpsheets-header"><div class="wpsheets-header-title"><svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#2563EB" stroke-width="2"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path></svg><div><h1>Constructor de Taxonomías</h1><div class="wpsheets-subtitle">Crea y edita categorías o etiquetas.</div></div></div><button class="ws-btn ws-btn-primary" onclick="document.getElementById('tax-form-title').innerText='Añadir Nueva Taxonomía'; document.getElementById('add-tax-form').reset(); document.getElementById('tax_id').value=''; jQuery('input[name=\'post_types[]\']').prop('checked', false); jQuery('#form-container').toggle();">Añadir Nueva</button></div>
        <div id="form-container" class="ws-card" style="display:none; border-top: 4px solid var(--ws-accent);"><h3 id="tax-form-title" style="margin-top:0;">Añadir Nueva Taxonomía</h3><form method="post" id="add-tax-form"><?php wp_nonce_field('wpsheets_save_tax'); ?><input type="hidden" name="tax_id" id="tax_id" value=""><div style="display:flex; gap:20px;"><div class="ws-form-group" style="flex:1;"><label class="ws-label">Nombre Plural</label><input type="text" name="plural" id="tax_plural" required class="ws-input"></div><div class="ws-form-group" style="flex:1;"><label class="ws-label">Nombre Singular</label><input type="text" name="singular" id="tax_singular" required class="ws-input"></div><div class="ws-form-group" style="flex:1;"><label class="ws-label">Slug</label><input type="text" name="slug" id="tax_slug" required class="ws-input"></div></div><div class="ws-form-group"><label class="ws-label">Asignar a Post Types</label><div style="background:var(--ws-bg); padding:15px; border-radius:6px; border:1px solid var(--ws-border);"><?php foreach($cpts as $c): ?><label style="margin-right:15px;"><input type="checkbox" name="post_types[]" value="<?php echo esc_attr($c['slug']); ?>" class="tax-pt-checkbox"> <?php echo esc_html($c['plural']); ?></label><?php endforeach; ?><label><input type="checkbox" name="post_types[]" value="post" class="tax-pt-checkbox"> Posts nativos</label></div></div><div class="ws-form-group"><label class="ws-label">Pestaña Vinculada</label><select name="sheet" id="tax_sheet" class="ws-select"><?php if(!empty($tabs) && !is_wp_error($tabs)): foreach($tabs as $t) echo "<option value='".esc_attr($t)."'>".esc_html($t)."</option>"; endif; ?></select></div><button type="submit" name="wpsheets_add_tax" class="ws-btn ws-btn-primary">Guardar Taxonomía</button> <button type="button" class="ws-btn ws-btn-secondary" onclick="jQuery('#form-container').hide();">Cancelar</button></form></div>
        <div class="ws-table-wrapper"><table class="ws-table"><thead><tr><th>Nombre</th><th>Slug</th><th>Vinculado a</th><th>Pestaña (Sheet)</th><th>Acciones</th></tr></thead><tbody><?php if(empty($taxs)): ?><tr><td colspan="5" style="text-align:center;">No hay Taxonomías.</td></tr><?php else: foreach($taxs as $t): ?><tr><td><strong><?php echo esc_html($t['plural']); ?></strong></td><td><span class="ws-badge"><?php echo esc_html($t['slug']); ?></span></td><td><?php foreach($t['post_types'] as $pt) echo '<span class="ws-badge" style="margin-right:4px;">'.$pt.'</span>'; ?></td><td><span class="ws-badge ws-badge-success"><?php echo esc_html($t['sheet']); ?></span></td><td style="text-align:right;"><button class="ws-btn ws-btn-secondary edit-tax-btn" data-id="<?php echo esc_attr($t['id']); ?>" data-plural="<?php echo esc_attr($t['plural']); ?>" data-singular="<?php echo esc_attr($t['singular']); ?>" data-slug="<?php echo esc_attr($t['slug']); ?>" data-sheet="<?php echo esc_attr($t['sheet']); ?>" data-pts='<?php echo json_encode($t['post_types']); ?>' style="padding: 6px 12px; margin-right:5px;">Editar</button><a href="?page=wpsheets-tax&delete_tax=<?php echo $t['id']; ?>" class="ws-btn ws-btn-danger" style="padding: 6px 12px;" onclick="return confirm('¿Seguro?');">Borrar</a></td></tr><?php endforeach; endif; ?></tbody></table></div>
    </div>
    <?php
}
