<?php
if (!defined('ABSPATH')) exit;
function wpsheets_page_cpts() {
    $cpts = get_option('wpsheets_cpts', []);
    if (isset($_POST['wpsheets_add_cpt']) && check_admin_referer('wpsheets_save_cpt')) {
        $id = sanitize_text_field($_POST['cpt_id']);
        $new_cpt = ['id' => $id ? $id : uniqid(), 'singular' => sanitize_text_field($_POST['singular']), 'plural' => sanitize_text_field($_POST['plural']), 'slug' => sanitize_title($_POST['slug']), 'icon' => sanitize_text_field($_POST['icon']), 'sheet' => sanitize_text_field($_POST['sheet'])];
        if ($id) { foreach($cpts as $k => $c) { if($c['id'] === $id) $cpts[$k] = $new_cpt; } $action_label = 'actualizado'; } else { $cpts[] = $new_cpt; $action_label = 'creado'; }
        update_option('wpsheets_cpts', $cpts); update_option('wpsheets_needs_sync', '1');

        // Auto-mapeo inteligente si hay hoja vinculada
        $auto_msg = '';
        if (!empty($new_cpt['sheet'])) {
            $mapped = wpsheets_auto_map_cpt($new_cpt['slug'], $new_cpt['sheet']);
            if ($mapped !== false) {
                // Auto-sincronizar (exportar datos WP → Sheets)
                $exported = wpsheets_bulk_export_cpt($new_cpt['slug'], $new_cpt['sheet'], $new_cpt['slug']);
                $auto_msg = " Auto-mapeado ({$mapped} columnas).";
                if ($exported > 0) $auto_msg .= " {$exported} registros exportados a Google Sheets.";
            } else {
                $auto_msg = ' <em>Hoja no encontrada en Google Sheets — mapea manualmente cuando la crees.</em>';
            }
        }
        echo '<div class="ws-alert ws-alert-success">Post Type ' . $action_label . '.' . $auto_msg . '</div>';
    }
    if (isset($_GET['delete_cpt'])) { $cpts = array_filter($cpts, function($c) { return $c['id'] !== $_GET['delete_cpt']; }); update_option('wpsheets_cpts', array_values($cpts)); echo '<div class="ws-alert ws-alert-success">Post Type eliminado.</div>'; }
    $tabs = get_option('wpsheets_spreadsheet_id') ? WPSheets_Google_API::get_spreadsheet_tabs(get_option('wpsheets_spreadsheet_id')) : [];
    ?>
    <div class="wpsheets-wrap">
        <div class="wpsheets-header"><div class="wpsheets-header-title"><svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#2563EB" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline></svg><div><h1>Constructor de Post Types</h1><div class="wpsheets-subtitle">Crea y edita tus CPTs vinculados a hojas de cálculo.</div></div></div><button class="ws-btn ws-btn-primary" onclick="document.getElementById('cpt-form-title').innerText='Añadir Nuevo CPT'; document.getElementById('add-cpt-form').reset(); document.getElementById('cpt_id').value=''; jQuery('#form-container').toggle();">Añadir Nuevo CPT</button></div>
        <div id="form-container" class="ws-card" style="display:none; border-top: 4px solid var(--ws-accent);"><h3 id="cpt-form-title" style="margin-top:0;">Añadir Nuevo CPT</h3><form method="post" id="add-cpt-form"><?php wp_nonce_field('wpsheets_save_cpt'); ?><input type="hidden" name="cpt_id" id="cpt_id" value=""><div style="display:flex; gap:20px;"><div class="ws-form-group" style="flex:1;"><label class="ws-label">Nombre Plural</label><input type="text" name="plural" id="cpt_plural" required class="ws-input"></div><div class="ws-form-group" style="flex:1;"><label class="ws-label">Nombre Singular</label><input type="text" name="singular" id="cpt_singular" required class="ws-input"></div></div><div style="display:flex; gap:20px;"><div class="ws-form-group" style="flex:1;"><label class="ws-label">Slug</label><input type="text" name="slug" id="cpt_slug" required class="ws-input"></div><div class="ws-form-group" style="flex:1;"><label class="ws-label">Icono Dashicon</label><input type="text" name="icon" id="cpt_icon" value="dashicons-admin-post" class="ws-input"></div></div><div class="ws-form-group"><label class="ws-label">Pestaña Vinculada</label><select name="sheet" id="cpt_sheet" class="ws-select"><?php if(!empty($tabs) && !is_wp_error($tabs)): foreach($tabs as $t) echo "<option value='".esc_attr($t)."'>".esc_html($t)."</option>"; else: ?><option value="">Error cargando hojas.</option><?php endif; ?></select></div><button type="submit" name="wpsheets_add_cpt" class="ws-btn ws-btn-primary">Guardar Post Type</button> <button type="button" class="ws-btn ws-btn-secondary" onclick="jQuery('#form-container').hide();">Cancelar</button></form></div>
        <div class="ws-table-wrapper"><table class="ws-table"><thead><tr><th>Nombre</th><th>Slug</th><th>Pestaña (Sheet)</th><th>Icono</th><th>Acciones</th></tr></thead><tbody><?php if(empty($cpts)): ?><tr><td colspan="5" style="text-align:center;">No hay Post Types.</td></tr><?php else: foreach($cpts as $c): ?><tr><td><strong><?php echo esc_html($c['plural']); ?></strong></td><td><span class="ws-badge"><?php echo esc_html($c['slug']); ?></span></td><td><span class="ws-badge ws-badge-success"><?php echo esc_html($c['sheet']); ?></span></td><td><span class="dashicons <?php echo esc_attr($c['icon']); ?>"></span></td><td style="text-align:right;"><button class="ws-btn ws-btn-secondary edit-cpt-btn" data-id="<?php echo esc_attr($c['id']); ?>" data-plural="<?php echo esc_attr($c['plural']); ?>" data-singular="<?php echo esc_attr($c['singular']); ?>" data-slug="<?php echo esc_attr($c['slug']); ?>" data-icon="<?php echo esc_attr($c['icon']); ?>" data-sheet="<?php echo esc_attr($c['sheet']); ?>" style="padding: 6px 12px; margin-right:5px;">Editar</button><a href="?page=wpsheets-cpts&delete_cpt=<?php echo $c['id']; ?>" class="ws-btn ws-btn-danger" style="padding: 6px 12px;" onclick="return confirm('¿Seguro?');">Borrar</a></td></tr><?php endforeach; endif; ?></tbody></table></div>
    </div>
    <?php
}
