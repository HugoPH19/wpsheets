<?php
if (!defined('ABSPATH')) exit;
add_action('init', 'wpsheets_register_dynamic_elements', 1);
function wpsheets_register_dynamic_elements() {
    $cpts = get_option('wpsheets_cpts', []);
    if (!is_array($cpts)) $cpts = [];
    foreach ($cpts as $cpt) {
        if (!isset($cpt['slug'])) continue; register_post_type($cpt['slug'], ['labels' => ['name' => sanitize_text_field($cpt['plural']), 'singular_name' => sanitize_text_field($cpt['singular'])], 'public' => true, 'has_archive' => true, 'show_in_rest' => true, 'menu_icon' => sanitize_text_field($cpt['icon']), 'supports' => ['title', 'editor', 'thumbnail', 'custom-fields']]);
    }
    $taxs = get_option('wpsheets_taxonomies', []);
    if (!is_array($taxs)) $taxs = [];
    foreach ($taxs as $tax) {
        if (!isset($tax['slug']) || !isset($tax['post_types'])) continue; register_taxonomy($tax['slug'], $tax['post_types'], ['labels' => ['name' => sanitize_text_field($tax['plural']), 'singular_name' => sanitize_text_field($tax['singular'])], 'public' => true, 'hierarchical' => true, 'show_in_rest' => true]);
    }
}


// --- AGREGAR COLUMNAS EN EL ADMIN ---
add_action('admin_init', 'wpsheets_setup_admin_columns');
function wpsheets_setup_admin_columns() {
    $cpts = get_option('wpsheets_cpts', []);
    if (!is_array($cpts)) $cpts = [];
    foreach ($cpts as $cpt) {
        if (!isset($cpt['slug'])) continue;
        $slug = $cpt['slug'];
        add_filter("manage_{$slug}_posts_columns", 'wpsheets_add_cpt_custom_columns');
        add_action("manage_{$slug}_posts_custom_column", 'wpsheets_fill_cpt_custom_columns', 10, 2);
    }

    $taxs = get_option('wpsheets_taxonomies', []);
    if (!is_array($taxs)) $taxs = [];
    foreach ($taxs as $tax) {
        if (!isset($tax['slug'])) continue;
        $slug = $tax['slug'];
        add_filter("manage_edit-{$slug}_columns", 'wpsheets_add_tax_custom_columns');
        add_filter("manage_{$slug}_custom_column", 'wpsheets_fill_tax_custom_columns', 10, 3);
    }
}

function wpsheets_add_cpt_custom_columns($columns) {
    if (!is_array($columns)) return $columns;
    $new_columns = [];
    foreach($columns as $key => $title) {
        if ($key == 'title') {
            $new_columns[$key] = $title;
            $new_columns['ws_id'] = 'ID (Sheets)';
            $new_columns['ws_shortcode'] = 'Datos (Mostrar)';
            $new_columns['ws_condicion'] = 'Condición (Ocultar)';
            $new_columns['ws_image'] = 'Imagen';
        } else {
            $new_columns[$key] = $title;
        }
    }
    return $new_columns;
}

function wpsheets_fill_cpt_custom_columns($column, $post_id) {
    $js_copy = "navigator.clipboard.writeText(this.value); this.style.backgroundColor='#dcfce3'; this.style.color='#000'; setTimeout(()=>{this.style.backgroundColor=''; this.style.color='';}, 400);";
    $input_style = "cursor:pointer; width: 100%; max-width: 250px; font-family: monospace; font-size: 11px; padding: 4px 6px; border-radius:3px; border:1px solid #ccc; transition: all 0.2s;";

    if ($column == 'ws_id') {
        $ws_id = get_post_meta($post_id, '_ws_import_id', true);
        echo $ws_id ? "<strong>" . esc_html($ws_id) . "</strong>" : '-';
    }
    if ($column == 'ws_shortcode') {
        $ws_id = get_post_meta($post_id, '_ws_import_id', true);
        if ($ws_id) {
            $val = '[ws_data id="' . $ws_id . '" key="wp_title"]';
            echo '<input type="text" readonly="readonly" value="' . esc_attr($val) . '" onclick="' . esc_attr($js_copy) . '" style="' . esc_attr($input_style) . '" title="Clic para copiar">';
        } else {
            echo '-';
        }
    }
    if ($column == 'ws_condicion') {
        $ws_id = get_post_meta($post_id, '_ws_import_id', true);
        if ($ws_id) {
            $val = '[ws_condicion id="' . $ws_id . '" key="visibilidad"]';
            echo '<input type="text" readonly="readonly" value="' . esc_attr($val) . '" onclick="' . esc_attr($js_copy) . '" style="' . esc_attr($input_style) . ' border-color:#fca5a5;" title="Clic para copiar">';
        } else {
            echo '-';
        }
    }
    if ($column == 'ws_image') {
        if (has_post_thumbnail($post_id)) {
            echo get_the_post_thumbnail($post_id, [50, 50], ['style' => 'border-radius: 4px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);']);
        } else {
            echo '<span style="color:#ccc;">Sin imagen</span>';
        }
    }
}

function wpsheets_add_tax_custom_columns($columns) {
    if (!is_array($columns)) return $columns;
    $new_columns = [];
    foreach($columns as $key => $title) {
        if ($key == 'name') {
            $new_columns[$key] = $title;
            $new_columns['ws_id'] = 'ID (Sheets)';
            $new_columns['ws_shortcode'] = 'Datos (Mostrar)';
            $new_columns['ws_condicion'] = 'Condición (Ocultar)';
        } else {
            $new_columns[$key] = $title;
        }
    }
    return $new_columns;
}

function wpsheets_fill_tax_custom_columns($content, $column_name, $term_id) {
    $js_copy = "navigator.clipboard.writeText(this.value); this.style.backgroundColor='#dcfce3'; this.style.color='#000'; setTimeout(()=>{this.style.backgroundColor=''; this.style.color='';}, 400);";
    $input_style = "cursor:pointer; width: 100%; max-width: 250px; font-family: monospace; font-size: 11px; padding: 4px 6px; border-radius:3px; border:1px solid #ccc; transition: all 0.2s;";

    if ($column_name == 'ws_id') {
        $ws_id = get_term_meta($term_id, '_ws_import_id', true);
        return $ws_id ? "<strong>" . esc_html($ws_id) . "</strong>" : '-';
    }
    if ($column_name == 'ws_shortcode') {
        $ws_id = get_term_meta($term_id, '_ws_import_id', true);
        if ($ws_id) {
            $val = '[ws_data term_id="' . $ws_id . '" key="tax_name"]';
            return '<input type="text" readonly="readonly" value="' . esc_attr($val) . '" onclick="' . esc_attr($js_copy) . '" style="' . esc_attr($input_style) . '" title="Clic para copiar">';
        } else {
            return '-';
        }
    }
    if ($column_name == 'ws_condicion') {
        $ws_id = get_term_meta($term_id, '_ws_import_id', true);
        if ($ws_id) {
            $val = '[ws_condicion term_id="' . $ws_id . '" key="visibilidad_taxonomia"]';
            return '<input type="text" readonly="readonly" value="' . esc_attr($val) . '" onclick="' . esc_attr($js_copy) . '" style="' . esc_attr($input_style) . ' border-color:#fca5a5;" title="Clic para copiar">';
        } else {
            return '-';
        }
    }
    return $content;
}


// ============================================================
// SELECTOR UNIVERSAL AGRUPADO (Prompt 2)
// Uso: echo wpsheets_get_grouped_options_html();
// en: Data Grid, Campos Dinámicos, Sincronizar, Panel Woo
// ============================================================
function wpsheets_get_grouped_options_html($selected_val = '') {
    $html = '<option value="">-- Elegir Opción --</option>';

    $cpts = get_option('wpsheets_cpts', []);
    $taxs = get_option('wpsheets_taxonomies', []);
    if (!is_array($cpts)) $cpts = [];
    if (!is_array($taxs)) $taxs = [];

    // ── 1. SHEETS ENGINE (CPTs del usuario + sus Taxonomías) ──────────────
    if (!empty($cpts) || !empty($taxs)) {
        $html .= '<optgroup label="🚀 Sheets Engine">';
        foreach ($cpts as $cpt) {
            if (empty($cpt['slug'])) continue;
            $sel = ($selected_val === $cpt['slug']) ? 'selected' : '';
            $html .= sprintf(
                '<option value="%s" data-type="cpt" data-sheet="%s" %s>-- %s (Post-type)</option>',
                esc_attr($cpt['slug']), esc_attr($cpt['sheet'] ?? ''), $sel, esc_html($cpt['plural'])
            );
            // Taxonomías ligadas a este CPT
            foreach ($taxs as $tax) {
                if (empty($tax['slug'])) continue;
                $tax_pts = isset($tax['post_types']) ? $tax['post_types']
                         : (isset($tax['cpt'])       ? [$tax['cpt']] : []);
                if (!in_array($cpt['slug'], $tax_pts)) continue;
                $t_val = 'tax_' . $tax['slug'];
                $sel_t = ($selected_val === $t_val) ? 'selected' : '';
                $no_sheet_warn = empty($tax['sheet']) ? ' ⚠️ (sin hoja)' : '';
                $html .= sprintf(
                    '<option value="%s" data-type="tax" data-sheet="%s" %s>&nbsp;&nbsp;&nbsp;--- %s (Taxonomía)%s</option>',
                    esc_attr($t_val), esc_attr($tax['sheet'] ?? ''), $sel_t, esc_html($tax['plural']), $no_sheet_warn
                );
            }
        }
        // Taxonomías sin CPT asignado (ligadas a "post" u otros)
        foreach ($taxs as $tax) {
            if (empty($tax['slug'])) continue;
            $tax_pts = isset($tax['post_types']) ? $tax['post_types']
                     : (isset($tax['cpt'])       ? [$tax['cpt']] : []);
            $linked = false;
            foreach ($cpts as $cpt) {
                if (in_array($cpt['slug'], $tax_pts)) { $linked = true; break; }
            }
            if (!$linked) {
                $t_val = 'tax_' . $tax['slug'];
                $sel_t = ($selected_val === $t_val) ? 'selected' : '';
                $no_sheet_warn = empty($tax['sheet']) ? ' ⚠️ (sin hoja)' : '';
                $html .= sprintf(
                    '<option value="%s" data-type="tax" data-sheet="%s" %s>&nbsp;&nbsp;&nbsp;--- %s (Taxonomía)%s</option>',
                    esc_attr($t_val), esc_attr($tax['sheet'] ?? ''), $sel_t, esc_html($tax['plural']), $no_sheet_warn
                );
            }
        }
        $html .= '</optgroup>';
    }

    // ── 2. WOOCOMMERCE ────────────────────────────────────────────────────
    if (class_exists('WooCommerce')) {
        $html .= '<optgroup label="🛒 WooCommerce">';

        $woo_items = [
            ['val' => 'product',         'type' => 'cpt', 'sheet' => 'Products_Woo',    'label' => '🛍️ Productos'],
            ['val' => 'tax_product_cat', 'type' => 'tax', 'sheet' => 'Categories_Woo',  'label' => '&nbsp;&nbsp;&nbsp;--- 📂 Categorías'],
            ['val' => 'tax_product_tag', 'type' => 'tax', 'sheet' => 'Tags_Woo',        'label' => '&nbsp;&nbsp;&nbsp;--- 🏷️ Etiquetas'],
        ];

        // Marcas (WC nativo product_brands, PWB, YITH, etc.)
        $brand_slugs = ['product_brands', 'pwb-brand', 'yith_product_brand', 'product_brand'];
        foreach (get_taxonomies([], 'objects') as $t) {
            foreach ($brand_slugs as $bs) {
                if (strpos($t->name, $bs) !== false) {
                    $woo_items[] = ['val' => 'tax_' . $t->name, 'type' => 'tax', 'sheet' => 'Brands_Woo', 'label' => '&nbsp;&nbsp;&nbsp;--- ⭐ Marcas'];
                    break 2;
                }
            }
        }

        // Todos los atributos pa_* → Attributes_Woo (una sola hoja)
        $has_attrs = false;
        if (function_exists('wc_get_attribute_taxonomies') && !empty(wc_get_attribute_taxonomies())) {
            $has_attrs = true;
        } else {
            foreach (get_taxonomies([], 'names') as $t) {
                if (strpos($t, 'pa_') === 0) { $has_attrs = true; break; }
            }
        }
        if ($has_attrs) {
            $woo_items[] = ['val' => 'tax_woo_attributes', 'type' => 'tax', 'sheet' => 'Attributes_Woo', 'label' => '&nbsp;&nbsp;&nbsp;--- ⚙️ Atributos (todos)'];
        }

        $woo_items[] = ['val' => 'shop_order',  'type' => 'cpt', 'sheet' => 'Orders_Woo',  'label' => '📦 Órdenes'];
        $woo_items[] = ['val' => 'shop_coupon', 'type' => 'cpt', 'sheet' => 'Coupons_Woo', 'label' => '🎟️ Cupones'];

        foreach ($woo_items as $item) {
            $sel = ($selected_val === $item['val']) ? 'selected' : '';
            $html .= sprintf(
                '<option value="%s" data-type="%s" data-sheet="%s" %s>%s</option>',
                esc_attr($item['val']), esc_attr($item['type']),
                esc_attr($item['sheet']), $sel, $item['label']
            );
        }
        $html .= '</optgroup>';
    }

    // ── 3. SISTEMA WORDPRESS (deshabilitados) ─────────────────────────────
    $html .= '<optgroup label="⚙️ WordPress (Próximamente)">';
    $html .= '<option value="" disabled style="color:#94a3b8;">-- Entradas del Blog</option>';
    $html .= '<option value="" disabled style="color:#94a3b8;">&nbsp;&nbsp;&nbsp;--- Categorías Blog</option>';
    $html .= '<option value="" disabled style="color:#94a3b8;">&nbsp;&nbsp;&nbsp;--- Etiquetas Blog</option>';
    $html .= '</optgroup>';

    // ── 4. OTROS CPTs DETECTADOS (deshabilitados) ─────────────────────────
    $skip = ['product', 'shop_order', 'shop_coupon', 'post', 'page', 'attachment', 'revision', 'nav_menu_item', 'wp_block', 'wp_template', 'wp_template_part', 'wp_navigation'];
    if (!empty($cpts)) foreach ($cpts as $c) { if (!empty($c['slug'])) $skip[] = $c['slug']; }
    $others = [];
    foreach (get_post_types(['public' => true, '_builtin' => false], 'objects') as $cpt) {
        if (!in_array($cpt->name, $skip)) $others[] = $cpt;
    }
    if (!empty($others)) {
        $html .= '<optgroup label="🔧 Otros CPTs (Próximamente)">';
        foreach ($others as $o) {
            $html .= sprintf('<option value="" disabled style="color:#94a3b8;">-- %s</option>', esc_html($o->label));
        }
        $html .= '</optgroup>';
    }

    return $html;
}


// ============================================================
// AUTO-MAPEO INTELIGENTE (Prompt 4)
// Genera el mapeo de campos para un CPT o Taxonomía del plugin
// basándose en las columnas reales de la hoja de Google Sheets.
// ============================================================
function wpsheets_auto_map_cpt($cpt_slug, $sheet_name) {
    $sid = get_option('wpsheets_spreadsheet_id');
    if (empty($sid) || empty($sheet_name)) return false;

    $headers_raw = WPSheets_Google_API::get_sheet_data($sid, "'" . $sheet_name . "'!1:1");
    if (is_wp_error($headers_raw) || empty($headers_raw[0])) return false;
    $headers = $headers_raw[0];

    // Mapa de columnas conocidas a sus tipos
    $known = [
        '_ws_import_id'    => 'id',
        'backendid'        => 'id',
        'wp_status_wordpress' => 'wp_status',
        'post_title'       => 'wp_title',
        'nombre'           => 'wp_title',
        'titulo'           => 'wp_title',
        'title'            => 'wp_title',
        'post_content'     => 'wp_content',
        'descripcion'      => 'wp_content',
        'description'      => 'wp_content',
        'contenido'        => 'wp_content',
        'post_excerpt'     => 'wp_excerpt',
        'extracto'         => 'wp_excerpt',
        'excerpt'          => 'wp_excerpt',
        'post_name'        => 'wp_slug',
        'slug'             => 'wp_slug',
        'image_url'        => 'wp_thumbnail',
        'imagen'           => 'wp_thumbnail',
        'image'            => 'wp_thumbnail',
        'foto'             => 'wp_thumbnail',
        'thumbnail'        => 'wp_thumbnail',
    ];

    // Obtener taxonomías registradas para este CPT (para autodetección)
    $registered_taxs = get_object_taxonomies($cpt_slug, 'objects');

    $mapping = [];
    foreach ($headers as $h) {
        $safeCol = strtolower(preg_replace('/[^a-zA-Z0-9_]/', '_', $h));
        $hLower  = strtolower(trim($h));
        $cfg     = ['type' => 'text', 'required' => 0, 'options' => []];

        if (isset($known[$hLower])) {
            $cfg['type'] = $known[$hLower];
        } elseif (isset($known[$safeCol])) {
            $cfg['type'] = $known[$safeCol];
        } else {
            // Detectar si es una taxonomía por nombre de columna
            foreach ($registered_taxs as $tax) {
                if ($hLower === $tax->name || $hLower === strtolower($tax->label) ||
                    strpos($hLower, str_replace('-','_', $tax->name)) !== false) {
                    $cfg['type'] = 'taxonomy';
                    $cfg['options'] = ['tax_target' => $tax->name, 'tax_autocreate' => '1'];
                    break;
                }
            }
        }
        $mapping[$safeCol] = $cfg;
    }

    $all_mapping = get_option('wpsheets_fields_mapping', []);
    if (!is_array($all_mapping)) $all_mapping = [];
    $all_mapping[$cpt_slug] = $mapping;
    update_option('wpsheets_fields_mapping', $all_mapping);
    return count($mapping);
}

function wpsheets_auto_map_taxonomy($tax_slug, $sheet_name) {
    $sid = get_option('wpsheets_spreadsheet_id');
    if (empty($sid) || empty($sheet_name)) return false;

    $headers_raw = WPSheets_Google_API::get_sheet_data($sid, "'" . $sheet_name . "'!1:1");
    if (is_wp_error($headers_raw) || empty($headers_raw[0])) return false;
    $headers = $headers_raw[0];

    $known_tax = [
        '_ws_import_id'       => 'id',
        'backendid'           => 'id',
        'wp_status_wordpress' => 'wp_status',
        'tax_name'            => 'tax_name',
        'nombre'              => 'tax_name',
        'nombre_taxonomia'    => 'tax_name',
        'name'                => 'tax_name',
        'tax_slug'            => 'tax_slug',
        'slug'                => 'tax_slug',
        'tax_desc'            => 'tax_desc',
        'descripcion'         => 'tax_desc',
        'descripcion_taxonomia' => 'tax_desc',
        'description'         => 'tax_desc',
        'image_url'           => 'image_url',
        'imagen'              => 'image_url',
        'parent'              => 'tax_parent',
        'parent_name'         => 'tax_parent',
        'categoria_padre'     => 'tax_parent',
    ];

    $mapping = [];
    foreach ($headers as $h) {
        $safeCol = strtolower(preg_replace('/[^a-zA-Z0-9_]/', '_', $h));
        $hLower  = strtolower(trim($h));
        $cfg     = ['type' => 'text', 'required' => 0, 'options' => []];

        if (isset($known_tax[$hLower])) {
            $cfg['type'] = $known_tax[$hLower];
        } elseif (isset($known_tax[$safeCol])) {
            $cfg['type'] = $known_tax[$safeCol];
        }
        $mapping[$safeCol] = $cfg;
    }

    $all_mapping = get_option('wpsheets_fields_mapping', []);
    if (!is_array($all_mapping)) $all_mapping = [];
    $all_mapping['tax_' . $tax_slug] = $mapping;
    update_option('wpsheets_fields_mapping', $all_mapping);
    return count($mapping);
}

