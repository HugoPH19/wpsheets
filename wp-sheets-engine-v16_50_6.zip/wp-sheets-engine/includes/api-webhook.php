<?php
if (!defined('ABSPATH')) exit;

add_action('rest_api_init', function () {
    register_rest_route('wpsheets/v1', '/webhook', [
        'methods' => 'POST',
        'callback' => 'wpsheets_handle_webhook',
        'permission_callback' => '__return_true'
    ]);
});

function wpsheets_handle_webhook(WP_REST_Request $request) {
    if(!defined('WPSHEETS_IS_WEBHOOK')) define('WPSHEETS_IS_WEBHOOK', true);
    $params = $request->get_json_params();
    $log_msg = "[" . current_time('mysql') . "] Webhook recibido. ";

    // action=delete no necesita row_data
    $is_delete_action = (!empty($params['action']) && $params['action'] === 'delete');
    if (empty($params['secret']) || empty($params['tab_name']) || (!$is_delete_action && empty($params['row_data']))) {
        update_option('wpsheets_last_webhook_error', $log_msg . "Faltan parámetros.");
        return new WP_Error('missing_data', 'Faltan parámetros requeridos', ['status' => 400]);
    }

    $stored_secret = get_option('wpsheets_webhook_secret');
    if (empty($stored_secret) || $params['secret'] !== $stored_secret) {
        update_option('wpsheets_last_webhook_error', $log_msg . "Token inválido.");
        return new WP_Error('invalid_secret', 'Token de seguridad inválido', ['status' => 401]);
    }


    // ── ACCIÓN: ELIMINAR REGISTRO ────────────────────────────────────────
    if ($is_delete_action) {
        $tab_del     = sanitize_text_field($params['tab_name'] ?? '');
        $backend_id  = sanitize_text_field($params['backendId'] ?? '');

        if (empty($backend_id)) {
            return new WP_Error('missing_id', 'Falta backendId para eliminar', ['status' => 400]);
        }

        // Mapear pestaña → tipo/slug
        $del_cpts = get_option('wpsheets_cpts', []);
        $del_taxs = get_option('wpsheets_taxonomies', []);
        if (!is_array($del_cpts)) $del_cpts = [];
        if (!is_array($del_taxs)) $del_taxs = [];
        if (class_exists('WooCommerce')) {
            $del_cpts[] = ['slug' => 'product',     'sheet' => 'Products_Woo'];
            $del_cpts[] = ['slug' => 'shop_order',  'sheet' => 'Orders_Woo'];
            $del_cpts[] = ['slug' => 'shop_coupon', 'sheet' => 'Coupons_Woo'];
            $del_taxs[] = ['slug' => 'product_cat', 'sheet' => 'Categories_Woo'];
            $del_taxs[] = ['slug' => 'product_tag', 'sheet' => 'Tags_Woo'];
            foreach (get_taxonomies([], 'objects') as $wh_dt) {
                foreach (['product_brands', 'pwb-brand', 'yith_product_brand', 'product_brand'] as $bs) {
                    if (strpos($wh_dt->name, $bs) !== false) {
                        $del_taxs[] = ['slug' => $wh_dt->name, 'sheet' => 'Brands_Woo']; break;
                    }
                }
            }
            if (function_exists('wc_get_attribute_taxonomies')) {
                foreach (wc_get_attribute_taxonomies() as $wh_attr) {
                    $del_taxs[] = ['slug' => 'pa_' . $wh_attr->attribute_name, 'sheet' => 'Attributes_Woo'];
                }
            }
        }

        $del_obj_id = ''; $del_obj_type = '';
        foreach ($del_cpts as $dc) {
            if (isset($dc['sheet']) && $dc['sheet'] === $tab_del) { $del_obj_id = $dc['slug']; $del_obj_type = 'cpt'; break; }
        }
        if (!$del_obj_type) {
            foreach ($del_taxs as $dt) {
                if (isset($dt['sheet']) && $dt['sheet'] === $tab_del) { $del_obj_id = $dt['slug']; $del_obj_type = 'tax'; break; }
            }
        }

        if (!$del_obj_type) {
            update_option('wpsheets_last_webhook_error', $log_msg . "Delete: hoja '{$tab_del}' no mapeada.");
            return new WP_Error('unmapped_tab', 'Hoja no mapeada para delete', ['status' => 400]);
        }

        if ($del_obj_type === 'cpt') {
            $del_posts = get_posts([
                'post_type' => $del_obj_id, 'meta_key' => '_ws_import_id', 'meta_value' => $backend_id,
                'posts_per_page' => 1, 'post_status' => 'any', 'fields' => 'ids',
            ]);
            if (!empty($del_posts)) {
                wp_delete_post($del_posts[0], true);
                update_option('wpsheets_last_webhook_error', $log_msg . "✅ Borrado: {$del_obj_id} (backendId: {$backend_id}).");
                return rest_ensure_response(['success' => true, 'message' => "Eliminado: {$backend_id}"]);
            }
        } else {
            // Para Attributes_Woo buscamos en todos los pa_*
            $del_taxonomies_search = [$del_obj_id];
            if ($tab_del === 'Attributes_Woo' && function_exists('wc_get_attribute_taxonomies')) {
                $del_taxonomies_search = array_map(fn($a) => 'pa_' . $a->attribute_name, wc_get_attribute_taxonomies());
            }
            foreach ($del_taxonomies_search as $del_tax_s) {
                $del_terms = get_terms(['taxonomy' => $del_tax_s, 'hide_empty' => false,
                    'meta_query' => [['key' => '_ws_import_id', 'value' => $backend_id]]]);
                if (!is_wp_error($del_terms) && !empty($del_terms)) {
                    wp_delete_term($del_terms[0]->term_id, $del_tax_s);
                    update_option('wpsheets_last_webhook_error', $log_msg . "✅ Término borrado (backendId: {$backend_id}).");
                    return rest_ensure_response(['success' => true, 'message' => "Término eliminado: {$backend_id}"]);
                }
            }
        }
        update_option('wpsheets_last_webhook_error', $log_msg . "⚠️ No encontrado para delete: {$backend_id}.");
        return rest_ensure_response(['success' => false, 'message' => 'No encontrado']);
    }

    $tab = sanitize_text_field($params['tab_name']);
    $raw_row_data = $params['row_data'];
    $id_column_raw = isset($params['id_column']) ? $params['id_column'] : '';

    // Limpiar todos los encabezados de Google Sheets a `safeCol`
    $row_data = [];
    $safe_id_column = '';

    if (is_array($raw_row_data)) {
        foreach ($raw_row_data as $raw_header => $value) {
            $safeCol = strtolower(preg_replace('/[^a-zA-Z0-9_]/', '_', $raw_header));
            if (!empty($safeCol)) {
                $row_data[$safeCol] = $value;
                if ($raw_header === $id_column_raw) {
                    $safe_id_column = $safeCol;
                }
            }
        }
    }

    // Fallback: backendId (columna estándar) o _ws_import_id (compatibilidad)
    if (empty($safe_id_column)) {
        if (isset($row_data['backendid']))     $safe_id_column = 'backendid';
        elseif (isset($row_data['_ws_import_id'])) $safe_id_column = '_ws_import_id';
    }

    $item_id = !empty($safe_id_column) && isset($row_data[$safe_id_column]) ? sanitize_text_field($row_data[$safe_id_column]) : '';


    if (empty($item_id)) {
        update_option('wpsheets_last_webhook_error', $log_msg . "La fila editada no tiene un '_ws_import_id'.");
        return new WP_Error('missing_id', 'La fila no tiene _ws_import_id', ['status' => 400]);
    }

    $cpts = get_option('wpsheets_cpts', []);
    $taxs = get_option('wpsheets_taxonomies', []);
    if (!is_array($cpts)) $cpts = [];
    if (!is_array($taxs)) $taxs = [];

    if (class_exists('WooCommerce')) {
        $cpts[] = ['slug' => 'product',     'sheet' => 'Products_Woo'];
        $cpts[] = ['slug' => 'shop_order',  'sheet' => 'Orders_Woo'];
        $cpts[] = ['slug' => 'shop_coupon', 'sheet' => 'Coupons_Woo'];
        $taxs[] = ['slug' => 'product_cat', 'sheet' => 'Categories_Woo'];
        $taxs[] = ['slug' => 'product_tag', 'sheet' => 'Tags_Woo'];
        // Marcas
        $brand_slugs_wh = ['product_brands', 'pwb-brand', 'yith_product_brand', 'product_brand'];
        foreach (get_taxonomies([], 'objects') as $wh_t) {
            foreach ($brand_slugs_wh as $bs) {
                if (strpos($wh_t->name, $bs) !== false) {
                    $taxs[] = ['slug' => $wh_t->name, 'sheet' => 'Brands_Woo']; break;
                }
            }
        }
        // Atributos pa_* → Attributes_Woo
        if (function_exists('wc_get_attribute_taxonomies')) {
            foreach (wc_get_attribute_taxonomies() as $attr) {
                $taxs[] = ['slug' => 'pa_' . $attr->attribute_name, 'sheet' => 'Attributes_Woo'];
            }
        }
    }

    $obj_id = ''; $obj_type = '';
    foreach($cpts as $c) { if(isset($c['sheet']) && $c['sheet'] === $tab) { $obj_id = $c['slug']; $obj_type = 'cpt'; break; } }
    if(!$obj_type) {
        foreach($taxs as $t) { if(isset($t['sheet']) && $t['sheet'] === $tab) { $obj_id = $t['slug']; $obj_type = 'tax'; break; } }
    }

    if (!$obj_type) {
        update_option('wpsheets_last_webhook_error', $log_msg . "La pestaña '{$tab}' no está en la configuración del plugin.");
        return new WP_Error('unmapped_tab', 'Pestaña no mapeada', ['status' => 400]);
    }

    $mapping_all = get_option('wpsheets_fields_mapping', []);

    // Determinar clave de mapeo correcta
    // obj_id viene sin prefijo "tax_" (ej: "product_cat")
    // pero el mapeo se guarda CON prefijo (ej: "tax_product_cat") — Bug 2 fix
    $mapping_key = $obj_id;

    if ($obj_type === 'tax') {
        $tax_raw = $obj_id; // e.g. "product_cat", "product_tag", "pa_color"
        // Atributos pa_* → mapeo compartido
        if (strpos($tax_raw, 'pa_') === 0) {
            $mapping_key = 'tax_woo_attributes';
        } else {
            // Marcas
            $brand_slugs_wh2 = ['product_brands', 'pwb-brand', 'yith_product_brand', 'product_brand'];
            $is_brand = false;
            foreach ($brand_slugs_wh2 as $bs) {
                if (strpos($tax_raw, $bs) !== false) { $is_brand = true; break; }
            }
            if ($is_brand) {
                $mapping_key = 'tax_brands_woo';
            } else {
                // Taxonomías normales: intentar con prefijo "tax_" primero (donde se guardan)
                $mapping_key = 'tax_' . $tax_raw; // "tax_product_cat", "tax_tipo_menu", etc.
            }
        }
    }

    // Buscar mapeo: clave calculada → sin prefijo → clave directa
    $mapping = $mapping_all[$mapping_key]
            ?? $mapping_all[$obj_id]
            ?? $mapping_all['tax_' . $obj_id]
            ?? [];

    if (empty($mapping)) {
        update_option('wpsheets_last_webhook_error', $log_msg . "Sin mapeo para '{$tab}' (intenté: '{$mapping_key}').");
        return new WP_Error('no_mapping', 'No hay mapeo configurado para esta hoja', ['status' => 400]);
    }

    if ($obj_type === 'cpt') {
        $existing_post = get_posts(['post_type' => $obj_id, 'meta_key' => '_ws_import_id', 'meta_value' => $item_id, 'posts_per_page' => 1, 'post_status' => 'any']);
        $post_title    = $item_id; $post_content = ''; $post_excerpt = ''; $meta_input = [];

        // Leer wp_status_wordpress directamente de row_data (columna de control)
        $desired_status = 'publish';
        if (!empty($row_data['wp_status_wordpress'])) {
            $raw_status     = strtolower(trim($row_data['wp_status_wordpress']));
            $desired_status = in_array($raw_status, ['publish', 'draft', 'private', 'pending', 'trash']) ? $raw_status : 'publish';
        }

        // Si piden trash → enviar a papelera y salir (no procesar más)
        if ($desired_status === 'trash') {
            if (!empty($existing_post)) {
                if(!defined('WPSHEETS_IS_WEBHOOK')) define('WPSHEETS_IS_WEBHOOK', true);
                wp_trash_post($existing_post[0]->ID);
            }
            update_option('wpsheets_last_webhook_error', $log_msg . "🗑️ Post a papelera: {$item_id}");
            return rest_ensure_response(['success' => true, 'message' => 'Post enviado a papelera.']);
        }

        foreach($mapping as $col_key => $config) {
            $val = isset($row_data[$col_key]) ? $row_data[$col_key] : '';
            if($config['type'] === 'wp_title' && !empty($val)) $post_title = $val;
            elseif($config['type'] === 'wp_content') $post_content = $val;
            elseif($config['type'] === 'wp_excerpt') $post_excerpt = $val;
            elseif($config['type'] === 'id' || $col_key === 'wp_status_wordpress') continue; // no a meta
            elseif($config['type'] !== 'taxonomy') { $meta_input[$col_key] = $val; }
        }

        $post_data = [
            'post_title'   => $post_title,
            'post_content' => $post_content,
            'post_excerpt' => $post_excerpt,
            'post_status'  => $desired_status,
            'post_type'    => $obj_id,
        ];

        if(!empty($existing_post)) {
            $pid = $existing_post[0]->ID;

            // Restaurar desde papelera si necesario
            if ($existing_post[0]->post_status === 'trash' && $desired_status !== 'trash') {
                // wp_untrash_post deja el post en 'draft' — luego update_post lo pondrá al estado deseado
                wp_untrash_post($pid);
                // Refrescar el objeto después del untrash
                clean_post_cache($pid);
            }

            $post_data['ID'] = $pid;
            wp_update_post($post_data);
        } else {
            // Antes de crear uno nuevo, verificar en papelera por si get_posts lo omitió
            $trashed = get_posts([
                'post_type'      => $obj_id,
                'post_status'    => 'trash',
                'meta_key'       => '_ws_import_id',
                'meta_value'     => $item_id,
                'posts_per_page' => 1,
                'fields'         => 'ids',
            ]);
            if (!empty($trashed)) {
                $pid = $trashed[0];
                wp_untrash_post($pid);
                clean_post_cache($pid);
                $post_data['ID'] = $pid;
                wp_update_post($post_data);
            } else {
                $pid = wp_insert_post($post_data);
                update_post_meta($pid, '_ws_import_id', $item_id);
            }
        }

        foreach($meta_input as $mk => $mv) update_post_meta($pid, $mk, $mv);

        if ($obj_id === 'product' && function_exists('wc_get_product')) {
            $product = wc_get_product($pid);
            if ($product) $product->save();
        }

    } else {
        // actual_taxonomy = slug real de la taxonomía (sin prefijo tax_)
        $actual_taxonomy = $obj_id; // obj_id ya viene sin prefijo (ej: 'product_cat')

        // Para Attributes_Woo: determinar taxonomía real desde attribute_parent
        if ($tab === 'Attributes_Woo' && isset($row_data['attribute_parent'])) {
            $attr_parent_val = sanitize_text_field($row_data['attribute_parent']);
            // attribute_parent puede ser el slug pa_* o el label; intentar ambos
            if (strpos($attr_parent_val, 'pa_') === 0 && taxonomy_exists($attr_parent_val)) {
                $actual_taxonomy = $attr_parent_val;
            } else {
                // Buscar por label
                if (function_exists('wc_get_attribute_taxonomies')) {
                    foreach (wc_get_attribute_taxonomies() as $attr) {
                        if (strcasecmp($attr->attribute_label, $attr_parent_val) === 0 || strcasecmp($attr->attribute_name, $attr_parent_val) === 0) {
                            $actual_taxonomy = 'pa_' . $attr->attribute_name; break;
                        }
                    }
                }
            }
        }

        $term_name      = $item_id; $term_desc = ''; $term_slug = '';
        $term_parent_id = 0; $meta_input = [];
        $desired_status = !empty($row_data['wp_status_wordpress']) ? sanitize_text_field($row_data['wp_status_wordpress']) : 'publish';
        foreach ($mapping as $col_key => $config) {
            $val = isset($row_data[$col_key]) ? $row_data[$col_key] : '';
            if ($config['type'] === 'tax_name' && !empty($val))    $term_name = $val;
            elseif ($config['type'] === 'tax_desc')                 $term_desc = $val;
            elseif ($config['type'] === 'tax_slug' && !empty($val)) $term_slug = sanitize_title($val);
            elseif ($config['type'] === 'tax_parent' && !empty($val)) {
                $parent_term = term_exists($val, $actual_taxonomy);
                if ($parent_term) $term_parent_id = is_array($parent_term) ? intval($parent_term['term_id']) : intval($parent_term);
            }
            elseif ($config['type'] === 'meta' && !empty($config['options']['meta_key'])) {
                $meta_input[$config['options']['meta_key']] = $val;
            }
            elseif ($config['type'] === 'image_url' && !empty($val)) {
                $meta_input['_ws_image_url_pending'] = $val; // procesado en outbound
            }
            elseif ($config['type'] !== 'id' && $col_key !== 'attribute_parent') {
                $meta_input[$col_key] = $val;
            }
        }

        // Trash desde Sheets → borrar término en WP
        if ($desired_status === 'trash') {
            $trash_terms = get_terms(['taxonomy' => $actual_taxonomy, 'hide_empty' => false,
                'meta_query' => [['key' => '_ws_import_id', 'value' => $item_id]]]);
            if (!is_wp_error($trash_terms) && !empty($trash_terms)) {
                wp_delete_term($trash_terms[0]->term_id, $actual_taxonomy);
                update_option('wpsheets_last_webhook_error', $log_msg . "🗑️ Término borrado: {$item_id}");
            }
            return rest_ensure_response(['success' => true, 'message' => 'Término eliminado.']);
        }

        $term_args = ['description' => $term_desc];
        if ($term_slug)      $term_args['slug']   = $term_slug;
        if ($term_parent_id) $term_args['parent'] = $term_parent_id;

        $existing_terms = get_terms(['taxonomy' => $actual_taxonomy, 'hide_empty' => false,
            'meta_query' => [['key' => '_ws_import_id', 'value' => $item_id]]]);

        if (!empty($existing_terms) && !is_wp_error($existing_terms)) {
            $term_db_id = $existing_terms[0]->term_id;
            wp_update_term($term_db_id, $actual_taxonomy, array_merge(['name' => $term_name], $term_args));
        } else {
            $inserted = wp_insert_term($term_name, $actual_taxonomy, $term_args);
            if (!is_wp_error($inserted)) {
                $term_db_id = $inserted['term_id'];
                update_term_meta($term_db_id, '_ws_import_id', $item_id);
            }
        }
        if (isset($term_db_id)) {
            foreach ($meta_input as $mk => $mv) update_term_meta($term_db_id, $mk, $mv);
        }
    }

    update_option('wpsheets_last_webhook_error', $log_msg . '¡Éxito! ID procesado: ' . $item_id);
    return rest_ensure_response(['success' => true, 'message' => 'Sincronización en tiempo real completada.']);
}
