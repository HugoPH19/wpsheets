<?php
if (!defined('ABSPATH')) exit;
class WPSheets_Google_API {
    public static function get_access_token() {
        $token = get_transient('wpsheets_access_token');
        if ($token) return $token;
        $json_string = get_option('wpsheets_service_account_json');
        if (empty($json_string)) return new WP_Error('no_credentials', 'Falta el JSON de credenciales.');
        $creds = json_decode($json_string, true);
        if (!$creds || empty($creds['private_key'])) return new WP_Error('invalid_json', 'JSON inválido.');
        $header = json_encode(['alg' => 'RS256', 'typ' => 'JWT']);
        $now = time();
        $claim = json_encode(['iss' => $creds['client_email'], 'scope' => 'https://www.googleapis.com/auth/spreadsheets', 'aud' => $creds['token_uri'], 'exp' => $now + 3600, 'iat' => $now]);
        $signature_input = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($header)) . '.' . str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($claim));
        $signature = '';
        if (!openssl_sign($signature_input, $signature, $creds['private_key'], 'SHA256')) return new WP_Error('sign_error', 'Error al firmar el JWT.');
        $jwt = $signature_input . '.' . str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signature));
        $response = wp_remote_post($creds['token_uri'], ['body' => ['grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer', 'assertion' => $jwt]]);
        if (is_wp_error($response)) return $response;
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if (isset($body['access_token'])) { set_transient('wpsheets_access_token', $body['access_token'], 3000); return $body['access_token']; }
        return new WP_Error('auth_failed', 'Error de Google.');
    }

    public static function get_sheet_data($spreadsheet_id, $range) {
        $token = self::get_access_token();
        if (is_wp_error($token)) return $token;
        $response = wp_remote_get("https://sheets.googleapis.com/v4/spreadsheets/{$spreadsheet_id}/values/{$range}", ['headers' => ['Authorization' => 'Bearer ' . $token]]);
        if (is_wp_error($response)) return $response;
        $body = json_decode(wp_remote_retrieve_body($response), true);
        return $body['values'] ?? [];
    }

    public static function get_spreadsheet_tabs($spreadsheet_id) {
        $token = self::get_access_token();
        if (is_wp_error($token)) return [];
        $response = wp_remote_get("https://sheets.googleapis.com/v4/spreadsheets/{$spreadsheet_id}?fields=sheets.properties.title", ['headers' => ['Authorization' => 'Bearer ' . $token]]);
        if (is_wp_error($response)) return [];
        $body = json_decode(wp_remote_retrieve_body($response), true);
        $tabs = [];
        if (!empty($body['sheets'])) foreach($body['sheets'] as $sheet) $tabs[] = $sheet['properties']['title'];
        return $tabs;
    }

    // NUEVO: Función para escribir/actualizar celdas en Google Sheets
    public static function update_sheet_data($spreadsheet_id, $range, $values) {
        $token = self::get_access_token();
        if (is_wp_error($token)) return $token;

        $body = [
            'range' => $range,
            'majorDimension' => 'ROWS',
            'values' => $values
        ];

        $response = wp_remote_request("https://sheets.googleapis.com/v4/spreadsheets/{$spreadsheet_id}/values/{$range}?valueInputOption=USER_ENTERED", [
            'method' => 'PUT',
            'headers' => [
                'Authorization' => 'Bearer ' . $token,
                'Content-Type' => 'application/json'
            ],
            'body' => json_encode($body)
        ]);

        if (is_wp_error($response)) return $response;
        $response_code = wp_remote_retrieve_response_code($response);
        if ($response_code !== 200) {
            $error_body = json_decode(wp_remote_retrieve_body($response), true);
            return new WP_Error('google_api_error', 'Error ' . $response_code . ': ' . ($error_body['error']['message'] ?? 'Desconocido'));
        }

        return true;
    }

    public static function append_row($spreadsheet_id, $range, $values) {
        $token = self::get_access_token();
        if (is_wp_error($token)) return $token;
        $url = "https://sheets.googleapis.com/v4/spreadsheets/{$spreadsheet_id}/values/{$range}:append?valueInputOption=USER_ENTERED";
        $body = json_encode(['values' => [$values]]);
        $response = wp_remote_post($url, [
            'headers' => ['Authorization' => 'Bearer ' . $token, 'Content-Type' => 'application/json'],
            'body'    => $body,
            'method'  => 'POST'
        ]);
        if (is_wp_error($response)) return $response;
        $code = wp_remote_retrieve_response_code($response);
        if ($code !== 200) {
            $err = json_decode(wp_remote_retrieve_body($response), true);
            return new WP_Error('api_error', $err['error']['message'] ?? 'Error desconocido');
        }
        return json_decode(wp_remote_retrieve_body($response), true);
    }


    public static function delete_dimension($spreadsheet_id, $sheet_id, $dimension, $start_index) {
        $token = self::get_access_token();
        if (is_wp_error($token)) return $token;
        $url = "https://sheets.googleapis.com/v4/spreadsheets/{$spreadsheet_id}:batchUpdate";

        $request = [
            'deleteDimension' => [
                'range' => [
                    'sheetId' => intval($sheet_id),
                    'dimension' => $dimension,
                    'startIndex' => intval($start_index),
                    'endIndex' => intval($start_index) + 1
                ]
            ]
        ];

        $body = json_encode(['requests' => [$request]]);
        $response = wp_remote_post($url, [
            'headers' => ['Authorization' => 'Bearer ' . $token, 'Content-Type' => 'application/json'],
            'body'    => $body,
            'method'  => 'POST'
        ]);
        if (is_wp_error($response)) return $response;
        $code = wp_remote_retrieve_response_code($response);
        if ($code !== 200) {
            $err = json_decode(wp_remote_retrieve_body($response), true);
            return new WP_Error('api_error', isset($err['error']['message']) ? $err['error']['message'] : 'Error desconocido al borrar');
        }
        return true;
    }

}
