<?php
if (!defined('ABSPATH')) exit;

function wpsheets_page_fields() {
    $cpts = get_option('wpsheets_cpts', []);
    $taxs = get_option('wpsheets_taxonomies', []);
    ?>
    <div class="wpsheets-wrap">
        <div class="wpsheets-header">
            <div class="wpsheets-header-title">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#2563EB" stroke-width="2"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline></svg>
                <div><h1>Campos Dinámicos</h1><div class="wpsheets-subtitle">Mapea las columnas de tus Post Types Y Taxonomías hacia WordPress.</div></div>
            </div>
        </div>

        <div class="ws-card">
            <div class="ws-form-group" style="margin-bottom:0;">
                <label class="ws-label">Selecciona qué deseas mapear:</label>
                <select id="ws-field-object-select" class="ws-select" style="max-width: 400px;">
                    <option value="">-- Elegir Opción --</option>
                    <optgroup label="📝 Post Types (Ej: Platillos)">
                        <?php foreach($cpts as $c) echo "<option value='".esc_attr($c['slug'])."' data-type='cpt' data-sheet='".esc_attr($c['sheet'])."'>".esc_html($c['plural'])."</option>"; ?>
                    </optgroup>
                    <optgroup label="🏷️ Taxonomías (Ej: Categorías de Menú)">
                        <?php foreach($taxs as $t) echo "<option value='tax_".esc_attr($t['slug'])."' data-type='tax' data-sheet='".esc_attr($t['sheet'])."'>".esc_html($t['plural'])."</option>"; ?>
                    </optgroup>
                </select>
            </div>
        </div>

        <div id="ws-fields-container" class="ws-card" style="display:none; border-top: 4px solid var(--ws-accent);">
            <h3 id="ws-fields-title">Mapeo de Columnas</h3>
            <div id="ws-fields-loading" style="display:none;"><div class="ws-skeleton" style="margin-bottom:10px;"></div><div class="ws-skeleton" style="margin-bottom:10px; width:80%;"></div></div>

            <form id="ws-fields-form" style="display:none;">
                <input type="hidden" name="object_id" id="ws-fields-object-id">
                <input type="hidden" name="object_type" id="ws-fields-object-type">

                <div class="ws-table-wrapper">
                    <table class="ws-table">
                        <thead><tr><th style="width: 35%;">Columna (Google Sheets)</th><th style="width: 65%;">Configuración de Campo en WordPress</th></tr></thead>
                        <tbody id="ws-fields-body"></tbody>
                    </table>
                </div>
                <div style="margin-top: 24px; display: flex; align-items: center;">
                    <button type="submit" class="ws-btn ws-btn-primary">Guardar Configuración Completa</button>
                    <span id="ws-fields-save-status" style="margin-left:15px; font-weight:500;"></span>
                </div>
            </form>
        </div>
    </div>
    <?php
}

add_action('wp_ajax_wpsheets_get_object_columns', function() {
    check_ajax_referer('wpsheets_ajax_nonce', 'nonce');
    $obj_id = sanitize_text_field($_POST['object_id']);
    $sheet = sanitize_text_field($_POST['sheet']);
    $sid = get_option('wpsheets_spreadsheet_id');

    $data = WPSheets_Google_API::get_sheet_data($sid, "'" . $sheet . "'!1:1"); 
    if(is_wp_error($data) || empty($data[0])) wp_send_json_error('No se leyeron columnas. Verifica la hoja en Google Sheets.');

    $taxonomies = get_taxonomies(['public' => true], 'objects'); $tax_list = [];
    foreach($taxonomies as $tax) $tax_list[] = ['slug' => $tax->name, 'label' => $tax->label];

    $post_types = get_post_types(['public' => true], 'objects'); $pt_list = [];
    foreach($post_types as $pt) $pt_list[] = ['slug' => $pt->name, 'label' => $pt->label];

    $mapping = get_option('wpsheets_fields_mapping', []);

    wp_send_json_success([
        'columns' => $data[0], 
        'mapping' => isset($mapping[$obj_id]) ? $mapping[$obj_id] : [],
        'taxonomies' => $tax_list,
        'post_types' => $pt_list
    ]);
});

add_action('wp_ajax_wpsheets_save_field_mapping', function() {
    check_ajax_referer('wpsheets_ajax_nonce', 'nonce');
    $obj_id = sanitize_text_field($_POST['object_id']); // e.g. "platillos" or "tax_tipo_alimento"
    $fields_raw = isset($_POST['fields']) ? $_POST['fields'] : [];

    $clean_fields = [];
    foreach($fields_raw as $k => $v) {
        $clean_fields[sanitize_text_field($k)] = [
            'type' => sanitize_text_field($v['type'] ?? 'text'),
            'required' => isset($v['required']) ? 1 : 0,
            'options' => isset($v['options']) ? wpsheets_clean_array($v['options']) : []
        ];
    }

    $mapping = get_option('wpsheets_fields_mapping', []);
    $mapping[$obj_id] = $clean_fields;
    update_option('wpsheets_fields_mapping', $mapping);

    wp_send_json_success('Configuración guardada correctamente.');
});

function wpsheets_clean_array($array) {
    $clean = [];
    if(is_array($array)) foreach($array as $k => $v) $clean[sanitize_text_field($k)] = is_array($v) ? wpsheets_clean_array($v) : sanitize_text_field($v);
    return $clean;
}
