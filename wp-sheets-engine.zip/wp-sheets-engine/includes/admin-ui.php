<?php
if (!defined('ABSPATH')) exit;
add_action('admin_menu', function() {
    add_menu_page('Sheets Engine', 'Sheets Engine', 'manage_options', 'wpsheets-api', 'wpsheets_page_api', 'dashicons-grid-view', 30);
    add_submenu_page('wpsheets-api', 'Conexión API', 'Conexión API', 'manage_options', 'wpsheets-api', 'wpsheets_page_api');
    add_submenu_page('wpsheets-api', 'Post Types', 'Post Types', 'manage_options', 'wpsheets-cpts', 'wpsheets_page_cpts');
    add_submenu_page('wpsheets-api', 'Taxonomías', 'Taxonomías', 'manage_options', 'wpsheets-tax', 'wpsheets_page_tax');
    add_submenu_page('wpsheets-api', 'Campos Dinámicos', 'Campos Dinámicos', 'manage_options', 'wpsheets-fields', 'wpsheets_page_fields');
    add_submenu_page('wpsheets-api', 'Data Grid Live', 'Data Grid (Live)', 'manage_options', 'wpsheets-datagrid', 'wpsheets_page_datagrid');
    add_submenu_page('wpsheets-api', 'Sincronizar Datos', 'Sincronizar', 'manage_options', 'wpsheets-sync', 'wpsheets_page_sync');
    add_submenu_page('wpsheets-api', 'Auto-Sync (Cron)', 'Auto-Sync', 'manage_options', 'wpsheets-auto-sync', 'wpsheets_page_auto_sync'); // NUEVO
});
add_action('admin_init', function() { register_setting('wpsheets_options', 'wpsheets_service_account_json'); register_setting('wpsheets_options', 'wpsheets_spreadsheet_id'); });
function wpsheets_page_api() {
    ?>
    <div class="wpsheets-wrap">
        <div class="wpsheets-header">
            <div class="wpsheets-header-title">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#2563EB" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="17 8 12 3 7 8"></polyline><line x1="12" y1="3" x2="12" y2="15"></line></svg>
                <div><h1>Conexión a Google Sheets</h1><div class="wpsheets-subtitle">Configura las credenciales de la API v4.</div></div>
            </div>
        </div>
        <form method="post" action="options.php" class="ws-card">
            <?php settings_fields('wpsheets_options'); ?>
            <div class="ws-form-group">
                <label class="ws-label">Credenciales Service Account (JSON)</label>
                <textarea name="wpsheets_service_account_json" rows="6" class="ws-textarea"><?php echo esc_textarea(get_option('wpsheets_service_account_json')); ?></textarea>
            </div>
            <div class="ws-form-group">
                <label class="ws-label">ID de la Hoja de Cálculo Principal</label>
                <input type="text" name="wpsheets_spreadsheet_id" value="<?php echo esc_attr(get_option('wpsheets_spreadsheet_id')); ?>" class="ws-input" />
            </div>
            <div style="margin-top: 30px; display: flex; gap: 15px;">
                <button type="submit" class="ws-btn ws-btn-primary">Guardar Configuración</button>
                <button type="button" id="wpsheets-test-btn" class="ws-btn ws-btn-secondary">Probar Conexión</button>
            </div>
            <div id="wpsheets-test-result" class="ws-alert" style="display: none; margin-top: 20px;"></div>
        </form>
    </div>
    <?php
}
add_action('wp_ajax_wpsheets_test_connection', function() {
    check_ajax_referer('wpsheets_ajax_nonce', 'nonce');
    $sid = get_option('wpsheets_spreadsheet_id');
    if (empty($sid)) { wp_send_json_error('Guarda el ID primero.'); }
    $tabs = WPSheets_Google_API::get_spreadsheet_tabs($sid);
    if (is_wp_error($tabs) || empty($tabs)) { wp_send_json_error('Error de conexión o permisos en Google.'); }
    wp_send_json_success('Conexión establecida con éxito. Pestañas detectadas: <strong>' . implode(', ', $tabs) . '</strong>');
});
