<?php
if (!defined('ABSPATH')) exit;
add_action('init', 'wpsheets_register_dynamic_elements', 1);
function wpsheets_register_dynamic_elements() {
    $cpts = get_option('wpsheets_cpts', []);
    if (!is_array($cpts)) $cpts = [];
    foreach ($cpts as $cpt) {
        if (!isset($cpt['slug'])) continue; register_post_type($cpt['slug'], ['labels' => ['name' => sanitize_text_field($cpt['plural']), 'singular_name' => sanitize_text_field($cpt['singular'])], 'public' => true, 'has_archive' => true, 'show_in_rest' => true, 'menu_icon' => sanitize_text_field($cpt['icon']), 'supports' => ['title', 'editor', 'thumbnail', 'custom-fields']]);
    }
    $taxs = get_option('wpsheets_taxonomies', []);
    if (!is_array($taxs)) $taxs = [];
    foreach ($taxs as $tax) {
        if (!isset($tax['slug']) || !isset($tax['post_types'])) continue; register_taxonomy($tax['slug'], $tax['post_types'], ['labels' => ['name' => sanitize_text_field($tax['plural']), 'singular_name' => sanitize_text_field($tax['singular'])], 'public' => true, 'hierarchical' => true, 'show_in_rest' => true]);
    }
}


// --- AGREGAR COLUMNAS EN EL ADMIN ---
add_action('admin_init', 'wpsheets_setup_admin_columns');
function wpsheets_setup_admin_columns() {
    $cpts = get_option('wpsheets_cpts', []);
    if (!is_array($cpts)) $cpts = [];
    foreach ($cpts as $cpt) {
        if (!isset($cpt['slug'])) continue;
        $slug = $cpt['slug'];
        add_filter("manage_{$slug}_posts_columns", 'wpsheets_add_cpt_custom_columns');
        add_action("manage_{$slug}_posts_custom_column", 'wpsheets_fill_cpt_custom_columns', 10, 2);
    }

    $taxs = get_option('wpsheets_taxonomies', []);
    if (!is_array($taxs)) $taxs = [];
    foreach ($taxs as $tax) {
        if (!isset($tax['slug'])) continue;
        $slug = $tax['slug'];
        add_filter("manage_edit-{$slug}_columns", 'wpsheets_add_tax_custom_columns');
        add_filter("manage_{$slug}_custom_column", 'wpsheets_fill_tax_custom_columns', 10, 3);
    }
}

function wpsheets_add_cpt_custom_columns($columns) {
    if (!is_array($columns)) return $columns;
    $new_columns = [];
    foreach($columns as $key => $title) {
        if ($key == 'title') {
            $new_columns[$key] = $title;
            $new_columns['ws_id'] = 'ID (Sheets)';
            $new_columns['ws_shortcode'] = 'Datos (Mostrar)';
            $new_columns['ws_condicion'] = 'Condición (Ocultar)';
            $new_columns['ws_image'] = 'Imagen';
        } else {
            $new_columns[$key] = $title;
        }
    }
    return $new_columns;
}

function wpsheets_fill_cpt_custom_columns($column, $post_id) {
    $js_copy = "navigator.clipboard.writeText(this.value); this.style.backgroundColor='#dcfce3'; this.style.color='#000'; setTimeout(()=>{this.style.backgroundColor=''; this.style.color='';}, 400);";
    $input_style = "cursor:pointer; width: 100%; max-width: 250px; font-family: monospace; font-size: 11px; padding: 4px 6px; border-radius:3px; border:1px solid #ccc; transition: all 0.2s;";

    if ($column == 'ws_id') {
        $ws_id = get_post_meta($post_id, '_ws_import_id', true);
        echo $ws_id ? "<strong>" . esc_html($ws_id) . "</strong>" : '-';
    }
    if ($column == 'ws_shortcode') {
        $ws_id = get_post_meta($post_id, '_ws_import_id', true);
        if ($ws_id) {
            $val = '[ws_data id="' . $ws_id . '" key="wp_title"]';
            echo '<input type="text" readonly="readonly" value="' . esc_attr($val) . '" onclick="' . esc_attr($js_copy) . '" style="' . esc_attr($input_style) . '" title="Clic para copiar">';
        } else {
            echo '-';
        }
    }
    if ($column == 'ws_condicion') {
        $ws_id = get_post_meta($post_id, '_ws_import_id', true);
        if ($ws_id) {
            $val = '[ws_condicion id="' . $ws_id . '" key="visibilidad"]';
            echo '<input type="text" readonly="readonly" value="' . esc_attr($val) . '" onclick="' . esc_attr($js_copy) . '" style="' . esc_attr($input_style) . ' border-color:#fca5a5;" title="Clic para copiar">';
        } else {
            echo '-';
        }
    }
    if ($column == 'ws_image') {
        if (has_post_thumbnail($post_id)) {
            echo get_the_post_thumbnail($post_id, [50, 50], ['style' => 'border-radius: 4px; box-shadow: 0 1px 3px rgba(0,0,0,0.1);']);
        } else {
            echo '<span style="color:#ccc;">Sin imagen</span>';
        }
    }
}

function wpsheets_add_tax_custom_columns($columns) {
    if (!is_array($columns)) return $columns;
    $new_columns = [];
    foreach($columns as $key => $title) {
        if ($key == 'name') {
            $new_columns[$key] = $title;
            $new_columns['ws_id'] = 'ID (Sheets)';
            $new_columns['ws_shortcode'] = 'Datos (Mostrar)';
            $new_columns['ws_condicion'] = 'Condición (Ocultar)';
        } else {
            $new_columns[$key] = $title;
        }
    }
    return $new_columns;
}

function wpsheets_fill_tax_custom_columns($content, $column_name, $term_id) {
    $js_copy = "navigator.clipboard.writeText(this.value); this.style.backgroundColor='#dcfce3'; this.style.color='#000'; setTimeout(()=>{this.style.backgroundColor=''; this.style.color='';}, 400);";
    $input_style = "cursor:pointer; width: 100%; max-width: 250px; font-family: monospace; font-size: 11px; padding: 4px 6px; border-radius:3px; border:1px solid #ccc; transition: all 0.2s;";

    if ($column_name == 'ws_id') {
        $ws_id = get_term_meta($term_id, '_ws_import_id', true);
        return $ws_id ? "<strong>" . esc_html($ws_id) . "</strong>" : '-';
    }
    if ($column_name == 'ws_shortcode') {
        $ws_id = get_term_meta($term_id, '_ws_import_id', true);
        if ($ws_id) {
            $val = '[ws_data term_id="' . $ws_id . '" key="tax_name"]';
            return '<input type="text" readonly="readonly" value="' . esc_attr($val) . '" onclick="' . esc_attr($js_copy) . '" style="' . esc_attr($input_style) . '" title="Clic para copiar">';
        } else {
            return '-';
        }
    }
    if ($column_name == 'ws_condicion') {
        $ws_id = get_term_meta($term_id, '_ws_import_id', true);
        if ($ws_id) {
            $val = '[ws_condicion term_id="' . $ws_id . '" key="visibilidad_taxonomia"]';
            return '<input type="text" readonly="readonly" value="' . esc_attr($val) . '" onclick="' . esc_attr($js_copy) . '" style="' . esc_attr($input_style) . ' border-color:#fca5a5;" title="Clic para copiar">';
        } else {
            return '-';
        }
    }
    return $content;
}
