<?php
if (!defined('ABSPATH')) exit;

function wpsheets_page_sync() {
    $cpts = get_option('wpsheets_cpts', []);
    $taxs = get_option('wpsheets_taxonomies', []);
    ?>
    <div class="wpsheets-wrap">
        <div class="wpsheets-header">
            <div class="wpsheets-header-title">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#10B981" stroke-width="2"><path d="M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.59-9.21L21.5 8"/></svg>
                <div><h1>Motor de Sincronización</h1><div class="wpsheets-subtitle">Importa tus Platillos (CPTs) o tus Categorías (Taxonomías) directamente desde Google Sheets.</div></div>
            </div>
        </div>

        <div class="ws-card">
            <div class="ws-form-group">
                <label class="ws-label">Selecciona qué deseas sincronizar:</label>
                <select id="ws-sync-object" class="ws-select" style="max-width: 400px;">
                    <option value="">-- Elegir Opción --</option>
                    <optgroup label="📝 Post Types (Ej: Platillos)">
                        <?php foreach($cpts as $c) echo "<option value='".esc_attr($c['slug'])."' data-type='cpt' data-sheet='".esc_attr($c['sheet'])."'>".esc_html($c['plural'])."</option>"; ?>
                    </optgroup>
                    <optgroup label="🏷️ Taxonomías (Ej: Categorías de Menú)">
                        <?php foreach($taxs as $t) echo "<option value='tax_".esc_attr($t['slug'])."' data-type='tax' data-sheet='".esc_attr($t['sheet'])."'>".esc_html($t['plural'])."</option>"; ?>
                    </optgroup>
                </select>
            </div>

            <div style="margin-top: 20px;">
                <button id="ws-sync-start-btn" class="ws-btn ws-btn-primary" disabled>🚀 Iniciar Sincronización</button>
                <button id="ws-sync-stop-btn" class="ws-btn ws-btn-danger" style="display:none;">🛑 Detener Proceso</button>
            </div>

            <div class="ws-progress-bg" id="ws-sync-progress-bg"><div class="ws-progress-bar" id="ws-sync-progress-bar"></div></div>
            <div id="ws-sync-status-text" style="font-weight: 600; font-size: 14px; margin-top: 10px; display: none; color: var(--ws-primary);"></div>
            <div class="ws-log-console" id="ws-sync-log"><div style="color: #64748B;">> Consola inactiva. Selecciona una opción e inicia la sincronización...</div></div>
        </div>
    </div>
    <?php
}

add_action('wp_ajax_wpsheets_sync_prepare', function() {
    check_ajax_referer('wpsheets_ajax_nonce', 'nonce');
    $obj_id = sanitize_text_field($_POST['object_id']);
    $sheet = sanitize_text_field($_POST['sheet']);
    $sid = get_option('wpsheets_spreadsheet_id');

    $data = WPSheets_Google_API::get_sheet_data($sid, "'" . $sheet . "'!A1:ZZ");
    if (is_wp_error($data) || empty($data)) wp_send_json_error('No se pudieron leer los datos de la hoja.');

    $headers = array_shift($data); 
    $total_rows = count($data);

    if ($total_rows === 0) wp_send_json_error('La hoja está vacía.');

    $mapping = get_option('wpsheets_fields_mapping', []);
    if(empty($mapping[$obj_id])) wp_send_json_error('Faltan reglas de mapeo. Ve a la pestaña "Campos Dinámicos" y guárdalas primero.');

    wp_send_json_success(['total_rows' => $total_rows, 'headers' => $headers, 'mapping' => $mapping[$obj_id]]);
});

// Helper Image Download
function ws_process_featured_image($object_id, $image_url, $is_thumbnail = true, $is_taxonomy = false) {
    if(empty($image_url) || !filter_var($image_url, FILTER_VALIDATE_URL)) return false;
    require_once(ABSPATH . 'wp-admin/includes/media.php'); require_once(ABSPATH . 'wp-admin/includes/file.php'); require_once(ABSPATH . 'wp-admin/includes/image.php');

    $meta_func_get = $is_taxonomy ? 'get_term_meta' : 'get_post_meta';
    $meta_func_update = $is_taxonomy ? 'update_term_meta' : 'update_post_meta';

    $existing_url = $meta_func_get($object_id, '_ws_source_image_url_' . md5($image_url), true);
    if($existing_url && !$is_taxonomy && has_post_thumbnail($object_id) && $is_thumbnail) return true; 

    $tmp = download_url($image_url);
    if(is_wp_error($tmp)) return $tmp;

    $file_array = ['name' => basename(parse_url($image_url, PHP_URL_PATH)), 'tmp_name' => $tmp];
    if(empty(pathinfo($file_array['name'], PATHINFO_EXTENSION))) $file_array['name'] .= '.jpg';

    // Para taxonomías le pasamos 0 a media_handle_sideload
    $attach_parent = $is_taxonomy ? 0 : $object_id;
    $id = media_handle_sideload($file_array, $attach_parent);
    if(is_wp_error($id)) { @unlink($file_array['tmp_name']); return $id; }

    if($is_thumbnail && !$is_taxonomy) set_post_thumbnail($object_id, $id);
    $meta_func_update($object_id, '_ws_source_image_url_' . md5($image_url), $id);

    return $id;
}

add_action('wp_ajax_wpsheets_sync_batch', function() {
    check_ajax_referer('wpsheets_ajax_nonce', 'nonce');
    $obj_id = sanitize_text_field($_POST['object_id']);
    $obj_type = sanitize_text_field($_POST['object_type']); // 'cpt' or 'tax'
    $sheet = sanitize_text_field($_POST['sheet']);
    $offset = intval($_POST['offset']) + 2; 
    $batch_size = intval($_POST['batch_size']);
    $sid = get_option('wpsheets_spreadsheet_id');
    $mapping = isset($_POST['mapping']) ? $_POST['mapping'] : [];
    $headers = isset($_POST['headers']) ? $_POST['headers'] : [];

    $end_row = $offset + $batch_size - 1;
    $range = "'" . $sheet . "'!A{$offset}:ZZ{$end_row}";
    $data = WPSheets_Google_API::get_sheet_data($sid, $range);
    if (is_wp_error($data)) wp_send_json_error('Error al leer el lote desde Google.');

    $logs = []; $processed = 0;

    foreach($data as $index => $row) {
        $row_data = [];
        foreach($headers as $i => $h) {
            $safe_h = strtolower(preg_replace('/[^a-zA-Z0-9_]/', '_', $h));
            $row_data[$safe_h] = isset($row[$i]) ? $row[$i] : '';
        }

        $id_col = ''; $item_id = '';
        foreach($mapping as $col_key => $config) { if($config['type'] === 'id') { $id_col = $col_key; break; } }
        if($id_col && !empty($row_data[$id_col])) { $item_id = $row_data[$id_col]; } 
        else { $item_id = uniqid('ws_'); $logs[] = "<span class='ws-log-warn'>Fila ".($offset+$index).": Sin ID, generado: $item_id</span>"; }

        $meta_input = [];
        $image_processing = [];

        // ---- RUTA A: SINCRONIZANDO TAXONOMÍA (Ej: tipo_menu) ----
        if($obj_type === 'tax') {
            $actual_tax_slug = str_replace('tax_', '', $obj_id); // e.g. "tipo_alimento"
            $term_name = "Término - " . $item_id;
            $term_desc = "";
            $term_slug = "";

            foreach($mapping as $col_key => $config) {
                $val = isset($row_data[$col_key]) ? $row_data[$col_key] : '';
                if($config['type'] === 'tax_name' && !empty($val)) $term_name = $val;
                elseif($config['type'] === 'tax_desc') $term_desc = $val;
                elseif($config['type'] === 'tax_slug' && !empty($val)) $term_slug = sanitize_title($val);
                elseif($config['type'] === 'id') $meta_input['_ws_import_id'] = $item_id;
                elseif($config['type'] === 'image_url' && !empty($val)) {
                    $image_processing[] = ['val' => $val, 'is_thumbnail' => false, 'meta_key' => $col_key];
                }
                else { $meta_input[$col_key] = $val; }
            }

            // Buscar si ya existe por Meta (ID importado) o por Slug
            $existing_terms = get_terms([
                'taxonomy' => $actual_tax_slug,
                'hide_empty' => false,
                'meta_query' => [['key' => '_ws_import_id', 'value' => $item_id]]
            ]);

            $term_db_id = 0;

            if(!empty($existing_terms) && !is_wp_error($existing_terms)) {
                // Actualizar
                $term_db_id = $existing_terms[0]->term_id;
                $args = ['name' => $term_name, 'description' => $term_desc];
                if($term_slug) $args['slug'] = $term_slug;
                wp_update_term($term_db_id, $actual_tax_slug, $args);
                $logs[] = "Actualizada Taxonomía: <strong style='color:#fff;'>{$term_name}</strong>";
            } else {
                // Si no se encuentra por ID, probamos por nombre directo (por si lo crearon manual)
                $term_exists = term_exists($term_name, $actual_tax_slug);
                if($term_exists) {
                    $term_db_id = is_array($term_exists) ? $term_exists['term_id'] : $term_exists;
                    $args = ['description' => $term_desc];
                    if($term_slug) $args['slug'] = $term_slug;
                    wp_update_term($term_db_id, $actual_tax_slug, $args);
                    $logs[] = "Vinculada Taxonomía existente: <strong style='color:#fff;'>{$term_name}</strong>";
                } else {
                    // Crear nuevo
                    $args = ['description' => $term_desc];
                    if($term_slug) $args['slug'] = $term_slug;
                    $inserted = wp_insert_term($term_name, $actual_tax_slug, $args);
                    if(is_wp_error($inserted)) {
                        $logs[] = "<span class='ws-log-error'>x Error creando {$term_name}: " . $inserted->get_error_message() . "</span>";
                        continue;
                    }
                    $term_db_id = $inserted['term_id'];
                    $logs[] = "Creada Taxonomía: <strong style='color:#fff;'>{$term_name}</strong>";
                }
            }

            // Procesar imágenes de la Taxonomía
            foreach($image_processing as $img) {
                $img_res = ws_process_featured_image($term_db_id, $img['val'], false, true);
                if(is_wp_error($img_res)) $logs[] = "<span class='ws-log-error'>&nbsp;x Error Imagen: " . $img_res->get_error_message() . "</span>";
                elseif(is_numeric($img_res)) { $meta_input[$img['meta_key']] = $img_res; $logs[] = "<span class='ws-log-info'>&nbsp;+ Imagen asignada a taxonomía.</span>"; }
            }

            foreach($meta_input as $mk => $mv) update_term_meta($term_db_id, $mk, $mv);
        }

        // ---- RUTA B: SINCRONIZANDO POST TYPE (Omitted for brevity in string, keeping logic) ----
        else {
            // Reusing the CPT sync logic from V11
            $post_title = "Sin Título - " . $item_id; $post_content = ''; $tax_processing = [];
            foreach($mapping as $col_key => $config) {
                $val = isset($row_data[$col_key]) ? $row_data[$col_key] : '';
                if($config['type'] === 'wp_title' && !empty($val)) { $post_title = $val; }
                elseif($config['type'] === 'wp_content') { $post_content = $val; }
                elseif($config['type'] === 'id') { $meta_input['_ws_import_id'] = $item_id; }
                elseif($config['type'] === 'taxonomy') { 
                    // Cuando sincroniza el Platillo, le asigna los términos (que en la RUTA A ya fueron creados nativamente)
                    $tax_processing[] = ['val' => $val, 'target' => $config['options']['tax_target'] ?? '', 'autocreate' => ($config['options']['tax_autocreate'] ?? '0') === '1'];
                }
                elseif($config['type'] === 'wp_thumbnail' && !empty($val)) { $image_processing[] = ['val' => $val, 'is_thumbnail' => true, 'meta_key' => $col_key]; }
                elseif($config['type'] === 'image_url' && !empty($val)) { $image_processing[] = ['val' => $val, 'is_thumbnail' => false, 'meta_key' => $col_key]; }
                else { $meta_input[$col_key] = $val; }
            }

            $existing_post = get_posts(['post_type' => $obj_id, 'meta_key' => '_ws_import_id', 'meta_value' => $item_id, 'posts_per_page' => 1, 'post_status' => 'any']);
            $post_data = ['post_title' => $post_title, 'post_content' => $post_content, 'post_status' => 'publish', 'post_type' => $obj_id];

            if(!empty($existing_post)) {
                $post_data['ID'] = $existing_post[0]->ID; wp_update_post($post_data); $pid = $post_data['ID'];
                $logs[] = "Actualizado CPT: <strong style='color:#fff;'>{$post_title}</strong>";
            } else {
                $pid = wp_insert_post($post_data);
                $logs[] = "Creado CPT: <strong style='color:#fff;'>{$post_title}</strong>";
            }

            // Asignar Taxonomías (Aquí asignará el platillo a la categoría 'Te', por ejemplo)
            foreach($tax_processing as $tax) {
                if(!empty($tax['val']) && !empty($tax['target'])) {
                    // Limpieza igual a V11
                    $terms_array = array_filter(array_map('trim', explode(',', $tax['val'])));
                    if(empty($terms_array)) continue;

                    if($tax['autocreate']) {
                        $res = wp_set_object_terms($pid, $terms_array, $tax['target'], false);
                    } else {
                        $term_ids = [];
                        foreach($terms_array as $term_name) {
                            $term_exists = term_exists($term_name, $tax['target']);
                            if($term_exists) $term_ids[] = (int) (is_array($term_exists) ? $term_exists['term_id'] : $term_exists);
                        }
                        if(!empty($term_ids)) $res = wp_set_object_terms($pid, $term_ids, $tax['target'], false);
                    }
                    $logs[] = "<span class='ws-log-info'>&nbsp;+ Taxonomía [{$tax['target']}] vinculada a '{$tax['val']}'.</span>";
                }
            }

            foreach($image_processing as $img) {
                $img_res = ws_process_featured_image($pid, $img['val'], $img['is_thumbnail'], false);
                if(is_wp_error($img_res)) $logs[] = "<span class='ws-log-error'>&nbsp;x Error Imagen: " . $img_res->get_error_message() . "</span>";
                elseif(is_numeric($img_res)) {
                    if($img['is_thumbnail']) $logs[] = "<span class='ws-log-info'>&nbsp;+ Imagen Destacada descargada.</span>";
                    else { $meta_input[$img['meta_key']] = $img_res; $logs[] = "<span class='ws-log-info'>&nbsp;+ Imagen en campo ACF guardada.</span>"; }
                }
            }

            foreach($meta_input as $mk => $mv) update_post_meta($pid, $mk, $mv);
        }

        $processed++;
    }

    wp_send_json_success(['processed' => $processed, 'logs' => $logs]);
});
