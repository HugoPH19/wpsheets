jQuery(document).ready(function($) {
    /* TEST API FIX */
    $('#wpsheets-test-btn').on('click', function(e) {
        e.preventDefault(); var $btn = $(this); $btn.text('Probando...').prop('disabled', true); $('#wpsheets-test-result').hide();
        $.post(wpSheets.ajax_url, { action: 'wpsheets_test_connection', nonce: wpSheets.nonce }, function(res) {
            $btn.text('Probar Conexión').prop('disabled', false); var $alert = $('#wpsheets-test-result');
            if(res.success) { $alert.removeClass('ws-alert-error').addClass('ws-alert-success').html('✅ ' + res.data).show(); } 
            else { $alert.removeClass('ws-alert-success').addClass('ws-alert-error').html('❌ ' + res.data).show(); }
        }).fail(function() {
            $btn.text('Probar Conexión').prop('disabled', false); $('#wpsheets-test-result').removeClass('ws-alert-success').addClass('ws-alert-error').html('❌ Error interno.').show();
        });
    });

    // CPT & TAX Edit Logic
    $('.edit-cpt-btn').on('click', function(e) { e.preventDefault(); $('#cpt-form-title').text('Editar Post Type'); $('#cpt_id').val($(this).data('id')); $('#cpt_plural').val($(this).data('plural')); $('#cpt_singular').val($(this).data('singular')); $('#cpt_slug').val($(this).data('slug')); $('#cpt_icon').val($(this).data('icon')); $('#cpt_sheet').val($(this).data('sheet')); $('#form-container').show(); window.scrollTo(0, 0); });
    $('.edit-tax-btn').on('click', function(e) { e.preventDefault(); $('#tax-form-title').text('Editar Taxonomía'); $('#tax_id').val($(this).data('id')); $('#tax_plural').val($(this).data('plural')); $('#tax_singular').val($(this).data('singular')); $('#tax_slug').val($(this).data('slug')); $('#tax_sheet').val($(this).data('sheet')); $('.tax-pt-checkbox').prop('checked', false); var pts = $(this).data('pts'); if(pts && pts.length) { pts.forEach(function(pt) { $('.tax-pt-checkbox[value="'+pt+'"]').prop('checked', true); }); } $('#form-container').show(); window.scrollTo(0, 0); });

    /* DATA GRID LOGIC (NOW WITH TWO-WAY EDITING) */
    var gridHeaders = [], gridAllRows = [], gridFilteredRows = [], currentPage = 1, pageSize = 50;
    var sortCol = -1, sortAsc = true;
    var activeTab = '';

    var $activeCell = null;

    function getColLetter(n) {
        var s = '';
        while (n >= 0) { s = String.fromCharCode(n % 26 + 65) + s; n = Math.floor(n / 26) - 1; }
        return s;
    }

    var formulaDict = {
        'VLOOKUP':    { title:'BUSCARV / VLOOKUP',   desc:'Busca un valor en la primera columna y devuelve el valor de otra columna.', syntax:'=VLOOKUP(valor, rango, indice, [0])' },
        'BUSCARV':    { title:'BUSCARV / VLOOKUP',   desc:'Busca un valor en la primera columna y devuelve el valor de otra columna.', syntax:'=VLOOKUP(valor, rango, indice, [0])' },
        'HLOOKUP':    { title:'BUSCARH / HLOOKUP',   desc:'Busca en la primera fila y devuelve el valor de otra fila.',                syntax:'=HLOOKUP(valor, rango, indice, [0])' },
        'XLOOKUP':    { title:'BUSCARX / XLOOKUP',   desc:'Busca en un rango y devuelve un elemento de un segundo rango.',             syntax:'=XLOOKUP(valor, rango_busqueda, rango_resultado)' },
        'SUM':        { title:'SUMA / SUM',           desc:'Suma una serie de números o celdas.',                                      syntax:'=SUM(A1:A10)' },
        'SUMA':       { title:'SUMA / SUM',           desc:'Suma una serie de números o celdas.',                                      syntax:'=SUM(A1:A10)' },
        'IF':         { title:'SI / IF',              desc:'Devuelve un valor si la condición es verdadera y otro si es falsa.',        syntax:'=IF(condicion, valor_si_verdadero, valor_si_falso)' },
        'QUERY':      { title:'QUERY',                desc:'Ejecuta una consulta SQL-like sobre un rango.',                            syntax:"=QUERY(datos, \"SELECT A,B WHERE C='valor'\", 1)" },
        'IMPORTRANGE':{ title:'IMPORTRANGE',          desc:'Importa un rango desde otra hoja de cálculo.',                             syntax:'=IMPORTRANGE("url", "Hoja1!A1:D10")' }
    };

    function showFormulaHelper(val) {
        var v = val.toUpperCase().replace(/^=/, '');
        for (var key in formulaDict) {
            if (v.indexOf(key) === 0 || v.indexOf(key) > 0) {
                $('#ws-helper-title').text('💡 ' + formulaDict[key].title);
                $('#ws-helper-desc').text(formulaDict[key].desc);
                $('#ws-helper-syntax').text(formulaDict[key].syntax);
                $('#ws-formula-helper').show();
                return;
            }
        }
        $('#ws-helper-title').text('💡 Modo Fórmula');
        $('#ws-helper-desc').text('Escribe funciones de Google Sheets (=SUM, =VLOOKUP, =IF…). Haz clic en el nombre de una hoja para insertarla.');
        $('#ws-helper-syntax').text('');
        $('#ws-formula-helper').show();
    }

    function saveActiveCell(newValue) {
        if (!$activeCell) return;
        var originalValue = $activeCell.attr('data-original-value') || '';
        if (newValue === originalValue) {
            if ($activeCell.hasClass('ws-editing-cell')) {
                var dv = originalValue.match(/\.(jpeg|jpg|gif|png)$/i) ? '<a href="'+originalValue+'" target="_blank" style="color:var(--ws-accent);">[Ver Imagen]</a>' : originalValue;
                $activeCell.removeClass('ws-editing-cell').html(dv);
            }
            return;
        }
        var rowIndex = $activeCell.closest('tr').data('row-index');
        var colIndex = $activeCell.data('col-index');
        var $td = $activeCell;

        $td.removeClass('ws-selected-cell ws-editing-cell').addClass('ws-saving-cell').html('Guardando...');
        $('#ws-grid-formula-input').prop('disabled', true);
        var isFormula = newValue.toString().trim().startsWith('=');
        $('#ws-grid-save-alert').text(isFormula ? '⏳ Guardando fórmula en Google Sheets...' : '⏳ Guardando...').removeClass('ws-alert-success ws-alert-error').css({'background':'#FEF3C7','color':'#92400E','border':'1px solid #FCD34D'}).show();

        $.post(wpSheets.ajax_url, { action:'wpsheets_update_cell', nonce:wpSheets.nonce, tab:activeTab, row_index:rowIndex, col_index:colIndex, value:newValue }, function(res) {
            $('#ws-grid-formula-input').prop('disabled', false);
            if (res.success) {
                var calculatedVal = res.data && res.data.calculated !== undefined ? res.data.calculated : newValue;
                var savedOriginal = res.data && res.data.original !== undefined ? res.data.original : newValue;

                if (!gridAllRows[rowIndex]) gridAllRows[rowIndex] = [];
                gridAllRows[rowIndex][colIndex] = savedOriginal;
                $td.attr('data-original-value', savedOriginal);

                var dv = calculatedVal;
                if (dv.toString().match(/\.(jpeg|jpg|gif|png)$/i)) {
                    dv = '<a href="'+dv+'" target="_blank" style="color:var(--ws-accent);">[Ver Imagen]</a>';
                }

                $td.removeClass('ws-saving-cell').addClass('ws-success-cell').html(dv);
                $('#ws-grid-save-alert').text('✅ Guardado exitosamente.').css({'background':'#D1FAE5','color':'#065F46','border':'1px solid #A7F3D0'});
                setTimeout(function() { $td.removeClass('ws-success-cell'); $('#ws-grid-save-alert').fadeOut(); }, 3000);
            } else {
                var dv2 = originalValue.match(/\.(jpeg|jpg|gif|png)$/i) ? '<a href="'+originalValue+'" target="_blank" style="color:var(--ws-accent);">[Ver Imagen]</a>' : originalValue;
                $td.removeClass('ws-saving-cell').html(dv2);
                $('#ws-grid-save-alert').text('❌ Error: ' + res.data).css({'background':'#FEF2F2','color':'#991B1B','border':'1px solid #FECACA'});
            }
        }).fail(function() {
            var dv3 = originalValue.match(/\.(jpeg|jpg|gif|png)$/i) ? '<a href="'+originalValue+'" target="_blank" style="color:var(--ws-accent);">[Ver Imagen]</a>' : originalValue;
            $td.removeClass('ws-saving-cell').html(dv3);
            $('#ws-grid-formula-input').prop('disabled', false);
            $('#ws-grid-save-alert').text('❌ Error de conexión.').css({'background':'#FEF2F2','color':'#991B1B','border':'1px solid #FECACA'});
        });
    }

    // SINGLE CLICK
    $('#ws-grid-table').on('click', 'td', function(e) { if ($(this).hasClass('ws-row-header')) return;
        if ($(this).hasClass('ws-row-header')) return;
        if ($(this).hasClass('ws-editing-cell') || $(this).hasClass('ws-saving-cell')) return;
        $('#ws-grid-table td').removeClass('ws-selected-cell');
        $(this).addClass('ws-selected-cell');
        $activeCell = $(this);
        var val = $(this).attr('data-original-value') || '';
        var ci = $(this).data('col-index');
        var ri = $(this).closest('tr').data('row-index') + 2;
        $('#ws-grid-cell-ref').text(getColLetter(ci) + ri);
        $('#ws-grid-formula-input').val(val).prop('disabled', false).focus();
        $('#ws-grid-formula-save').show();
        if (val.toString().trim().startsWith('=')) showFormulaHelper(val);
        else $('#ws-formula-helper').hide();
    });

    $('#ws-grid-formula-input').on('input', function() {
        var v = $(this).val();
        if (v.trim().startsWith('=')) showFormulaHelper(v);
        else $('#ws-formula-helper').hide();
    });

    $('#ws-grid-formula-input').on('keydown', function(e) { if (e.key === 'Enter') { e.preventDefault(); saveActiveCell($(this).val()); } });
    $('#ws-grid-formula-save').on('click', function(e) { e.preventDefault(); saveActiveCell($('#ws-grid-formula-input').val()); });

    $(document).on('click', '.ws-helper-tab-btn', function() {
        var t = $(this).data('tab');
        var $inp = $('#ws-grid-formula-input');
        $inp.val($inp.val() + "'" + t + "'!").focus();
    });

    // DOUBLE CLICK
    $('#ws-grid-table').on('dblclick', 'td', function() { if ($(this).hasClass('ws-row-header')) return;
        if ($(this).hasClass('ws-row-header')) return;
        if ($(this).hasClass('ws-editing-cell') || $(this).hasClass('ws-saving-cell')) return;
        var originalValue = $(this).attr('data-original-value') || '';
        var $input = $('<input type="text" class="ws-edit-input">').val(originalValue);
        $(this).addClass('ws-editing-cell ws-selected-cell').html('').append($input);
        $activeCell = $(this);
        var ci = $(this).data('col-index');
        var ri = $(this).closest('tr').data('row-index') + 2;
        $('#ws-grid-cell-ref').text(getColLetter(ci) + ri);
        $('#ws-grid-formula-input').val(originalValue).prop('disabled', false);
        $('#ws-grid-formula-save').show();
        $input.focus();

        $input.on('blur keydown', function(e) {
            if (e.type === 'keydown' && e.key !== 'Enter' && e.key !== 'Escape') return;
            if (e.type === 'keydown' && e.key === 'Escape') {
                var dv = originalValue.match(/\.(jpeg|jpg|gif|png)$/i) ? '<a href="'+originalValue+'" target="_blank" style="color:var(--ws-accent);">[Ver Imagen]</a>' : originalValue;
                $activeCell.removeClass('ws-editing-cell').html(dv);
                return;
            }
            saveActiveCell($(this).val());
        });
    });


    function renderGrid() { 
        var $tbody = $('#ws-grid-body'); $tbody.empty(); 
        var totalPages = pageSize === 'all' ? 1 : Math.ceil(gridFilteredRows.length / pageSize) || 1; 
        if(currentPage > totalPages) currentPage = totalPages; if(currentPage < 1) currentPage = 1; 

        var pageRows = []; 
        var startIndex = 0;

        if(pageSize === 'all') { 
            pageRows = gridFilteredRows; 
            startIndex = 0;
        } else { 
            startIndex = (currentPage - 1) * pageSize; 
            var end = startIndex + parseInt(pageSize); 
            pageRows = gridFilteredRows.slice(startIndex, end); 
        }

        if(pageRows.length === 0) { 
            $tbody.html('<tr><td colspan="'+(gridHeaders.length+1)+'" style="text-align:center;">No se encontraron registros.</td></tr>'); 
        } else { 
            var html = ''; 
            pageRows.forEach(function(row, idxInPage) { 
                var originalGlobalIndex = gridAllRows.indexOf(row); // Important to find exactly which row in Google Sheets this is

                
                html += '<tr data-row-index="'+originalGlobalIndex+'">'; 
                html += '<td class="ws-row-header ws-relative" style="background:#f1f5f9; color:#64748b; text-align:center; font-family:monospace; font-size:12px; border-right:1px solid #cbd5e1; font-weight:600; user-select:none; border-bottom:1px solid #cbd5e1; cursor:default; position:relative;">' + (originalGlobalIndex + 2) + '<button class="ws-del-btn ws-del-row-btn" data-row="'+originalGlobalIndex+'" title="Borrar Fila">×</button></td>';
                gridHeaders.forEach(function(h, i) { 
 
                    var val = row[i] !== undefined ? row[i] : ''; 
                    var displayVal = val;
                    if(val.toString().match(/\.(jpeg|jpg|gif|png)$/i)) { displayVal = '<a href="'+val+'" target="_blank" style="color:var(--ws-accent);">[Ver Imagen]</a>'; } 

                    html += '<td data-col-index="'+i+'" data-original-value="'+val+'">' + displayVal + '</td>'; 
                }); 
                html += '</tr>'; 
            }); 
            $tbody.html(html); 
        } 

        $('#ws-grid-page-current').text(currentPage); $('#ws-grid-page-total').text(totalPages); $('#ws-grid-total-rows').text(gridFilteredRows.length); $('#ws-grid-prev').prop('disabled', currentPage === 1); $('#ws-grid-next').prop('disabled', currentPage === totalPages);
        $activeCell = null; $('#ws-grid-formula-input').val('').prop('disabled', true); $('#ws-grid-cell-ref').text('—'); $('#ws-grid-formula-save').hide(); $('#ws-grid-media-btn').show(); $('#ws-formula-helper').hide(); 
    }

    $('#ws-grid-per-page').on('change', function() { pageSize = $(this).val() === 'all' ? 'all' : parseInt($(this).val()); currentPage = 1; renderGrid(); });

    $('#ws-grid-table').on('click', 'th', function() {
        var colIndex = $(this).index(); if(sortCol === colIndex) { sortAsc = !sortAsc; } else { sortCol = colIndex; sortAsc = true; }
        $('#ws-grid-table th').find('.ws-sort-icon').remove(); $(this).append('<span class="ws-sort-icon">' + (sortAsc ? ' ↑' : ' ↓') + '</span>');
        gridFilteredRows.sort(function(a, b) {
            var valA = a[colIndex] !== undefined ? a[colIndex].toString().toLowerCase() : ''; var valB = b[colIndex] !== undefined ? b[colIndex].toString().toLowerCase() : '';
            var numA = parseFloat(valA.replace(/[^0-9.-]+/g,"")); var numB = parseFloat(valB.replace(/[^0-9.-]+/g,""));
            if(!isNaN(numA) && !isNaN(numB) && valA.match(/^[0-9.,$ -]+$/) && valB.match(/^[0-9.,$ -]+$/)) { return sortAsc ? numA - numB : numB - numA; }
            if(valA < valB) return sortAsc ? -1 : 1; if(valA > valB) return sortAsc ? 1 : -1; return 0;
        }); currentPage = 1; renderGrid();
    });

    $('#ws-grid-load-btn').on('click', function(e) { 
        e.preventDefault(); activeTab = $('#ws-grid-tab-select').val(); if(!activeTab) return alert('Selecciona una pestaña.'); 
        var $btn = $(this); $btn.prop('disabled', true).text('Cargando...'); 
        $('#ws-grid-search-container, #ws-grid-per-page-container').hide(); $('#ws-grid-table-container').show(); $('#ws-grid-headers').html('<th>Cargando datos...</th>'); $('#ws-grid-body').html('<tr><td><div class="ws-skeleton"></div></td></tr><tr><td><div class="ws-skeleton"></div></td></tr>'); 
        $.post(wpSheets.ajax_url, { action: 'wpsheets_load_grid', nonce: wpSheets.nonce, tab: activeTab }, function(res) { 
            $btn.prop('disabled', false).text('Cargar / Refrescar Datos'); 
            if(!res.success) { $('#ws-grid-headers').html('<th>Error</th>'); $('#ws-grid-body').html('<tr><td style="color:red;">' + res.data + '</td></tr>'); return; } 
            gridHeaders = res.data.headers; gridAllRows = res.data.rows; gridFilteredRows = gridAllRows; currentPage = 1; sortCol = -1;
            
            var hhtml = '<th style="width:45px; background:#f1f5f9; border-right:1px solid #cbd5e1; border-bottom:1px solid #cbd5e1; text-align:center;"></th>'; 
            gridHeaders.forEach(function(h, i) { 
                hhtml += '<th style="text-align:center; background:#f8fafc; border-right:1px solid #cbd5e1; border-bottom:1px solid #cbd5e1; min-width:120px; padding:0;">' +
                         '<div style="font-size:12px; color:#64748b; padding:4px 0; border-bottom:1px solid #e2e8f0; font-family:monospace; background:#f1f5f9;">' + getColLetter(i) + '</div>' +
                         '<div style="padding:8px 12px; color:#1e293b; position:relative;" class="ws-relative-th">' + h + '<button class="ws-del-btn ws-del-col-btn" data-col="'+i+'" title="Borrar Columna">×</button></div>' + 
                         '</th>'; 
            }); 
            $('#ws-grid-headers').html(hhtml);
 $('#ws-grid-search-container, #ws-grid-per-page-container').css('display', 'flex');
                $('#ws-grid-formula-bar').css('display', 'flex'); $('#ws-grid-search').val(''); renderGrid(); 
        }); 
    });

    $('#ws-grid-search').on('input', function() { var query = $(this).val().toLowerCase(); if(query === '') { gridFilteredRows = gridAllRows; } else { gridFilteredRows = gridAllRows.filter(function(row) { return row.some(function(col) { return (col !== undefined && col !== null) ? col.toString().toLowerCase().indexOf(query) > -1 : false; }); }); } currentPage = 1; renderGrid(); });
    $('#ws-grid-prev').on('click', function(e) { e.preventDefault(); if(currentPage > 1) { currentPage--; renderGrid(); } });
    $('#ws-grid-next').on('click', function(e) { e.preventDefault(); var total = pageSize==='all' ? 1 : Math.ceil(gridFilteredRows.length / pageSize); if(currentPage < total) { currentPage++; renderGrid(); } });

    // --- TWO-WAY INLINE EDITING LOGIC ---

    /* FIELDS BUILDER & SYNC (Omitted unchanged code, merged successfully below) */

    var availableTaxonomies = [];
    var availablePostTypes = [];
    var cptTypeGroups = { '🌟 Conexión Nativa WordPress': { 'wp_title': '[WP Nativo] Título del Post', 'wp_content': '[WP Nativo] Contenido (Editor)', 'wp_thumbnail': '[WP Nativo] Imagen Destacada' }, '🔑 Identificadores': { 'id': 'ID Único (Llave Primaria - Autogenera)' }, '📝 Texto & Básicos': { 'text': 'Texto', 'textarea': 'Área de Texto', 'number': 'Número / Precio', 'email': 'Email', 'url': 'URL Simple' }, '🖼️ Medios & Archivos': { 'image_url': 'Imagen (URL Sheets -> Sube a WP)', 'image_wp': 'Imagen (Seleccionar ID/URL)', 'gallery': 'Galería de Imágenes' }, '🔘 Selección / Booleanos': { 'select': 'Seleccionar (Select)', 'checkbox': 'Casilla (Checkbox)', 'boolean': 'Verdadero / Falso (Sí/No)' }, '🔗 Relacional & Taxonomías': { 'taxonomy': 'Taxonomía (Categorías/Etiquetas)', 'post_object': 'Objeto Post / Relación' }, '⚙️ Avanzado': { 'date_picker': 'Selector de Fecha' } };
    var taxTypeGroups = { '🌟 Conexión Nativa de Taxonomía': { 'tax_name': '[WP Nativo] Nombre de Categoría/Etiqueta', 'tax_desc': '[WP Nativo] Descripción', 'tax_slug': '[WP Nativo] Slug (URL)' }, '🔑 Identificadores': { 'id': 'ID Único (Llave Primaria - Autogenera)' }, '📝 Campos Personalizados (ACF)': { 'text': 'Texto', 'textarea': 'Área de Texto', 'number': 'Número' }, '🖼️ Medios (ACF)': { 'image_url': 'Imagen (URL Sheets -> Sube a WP)', 'image_wp': 'Imagen (Seleccionar ID/URL)' }, '🔘 Selección (ACF)': { 'select': 'Seleccionar (Select)', 'boolean': 'Verdadero / Falso (Sí/No)' } };

    function renderIntelligentOptions(type, safeCol, currentOptions) {
        var html = ''; var opts = currentOptions || {};
        if (type === 'taxonomy') { html += '<div style="background:#F1F5F9; padding:15px; border-radius:6px; margin-top:10px; border-left: 3px solid var(--ws-accent);"><h4 style="margin-top:0; margin-bottom:10px; font-size:13px; color:var(--ws-primary);">⚙️ Configuración de Taxonomía</h4><div style="margin-bottom:10px;"><label class="ws-label" style="font-size:12px;">¿A qué taxonomía pertenece?</label><select name="fields['+safeCol+'][options][tax_target]" class="ws-select" style="font-size:13px; max-width:300px;">'; availableTaxonomies.forEach(function(tax) { var sel = (opts.tax_target === tax.slug) ? 'selected' : ''; html += '<option value="'+tax.slug+'" '+sel+'>'+tax.label+' ('+tax.slug+')</option>'; }); html += '</select></div><div style="margin-bottom:10px;"><label class="ws-label" style="font-size:12px;">Apariencia UI</label><select name="fields['+safeCol+'][options][tax_ui]" class="ws-select" style="font-size:13px; max-width:300px;">'; var uiOpts = {'checkbox': 'Casillas (Múltiple)', 'multi_select': 'Selector Múltiple', 'radio': 'Radio Button (Único)', 'select': 'Selector Desplegable (Único)'}; $.each(uiOpts, function(k, v) { var sel = (opts.tax_ui === k) ? 'selected' : ''; html += '<option value="'+k+'" '+sel+'>'+v+'</option>'; }); html += '</select></div>'; var acCheck = (opts.tax_autocreate == '1') ? 'checked' : ''; html += '<label style="font-size:12px; display:flex; align-items:center; gap:5px;"><input type="checkbox" name="fields['+safeCol+'][options][tax_autocreate]" value="1" '+acCheck+'> Auto-crear términos al sincronizar</label></div>'; }
        else if (type === 'post_object') { html += '<div style="background:#F1F5F9; padding:15px; border-radius:6px; margin-top:10px; border-left: 3px solid var(--ws-accent);"><h4 style="margin-top:0; margin-bottom:10px; font-size:13px; color:var(--ws-primary);">⚙️ Relación de Post</h4><div style="margin-bottom:10px;"><label class="ws-label" style="font-size:12px;">Post Type Relacionado</label><select name="fields['+safeCol+'][options][pt_target]" class="ws-select" style="font-size:13px; max-width:300px;">'; availablePostTypes.forEach(function(pt) { var sel = (opts.pt_target === pt.slug) ? 'selected' : ''; html += '<option value="'+pt.slug+'" '+sel+'>'+pt.label+'</option>'; }); html += '</select></div>'; var multiCheck = (opts.pt_multiple == '1') ? 'checked' : ''; html += '<label style="font-size:12px; display:flex; align-items:center; gap:5px;"><input type="checkbox" name="fields['+safeCol+'][options][pt_multiple]" value="1" '+multiCheck+'> Permitir selección múltiple</label></div>'; }
        else if (type === 'boolean') { html += '<div style="background:#F1F5F9; padding:15px; border-radius:6px; margin-top:10px; border-left: 3px solid var(--ws-accent);">'; var trueVal = opts.bool_true || 'Si, Yes, 1, True, Verdadero'; html += '<label class="ws-label" style="font-size:12px;">Valores Verdaderos</label><input type="text" name="fields['+safeCol+'][options][bool_true]" class="ws-input" style="font-size:13px; max-width:400px;" value="'+trueVal+'"></div>'; }
        return html;
    }

    $('#ws-field-object-select').on('change', function() {
        var obj_id = $(this).val(); var obj_type = $(this).find(':selected').data('type'); var sheet = $(this).find(':selected').data('sheet');
        if(!obj_id) { $('#ws-fields-container').hide(); return; }
        $('#ws-fields-container').show(); $('#ws-fields-loading').show(); $('#ws-fields-form').hide(); $('#ws-fields-save-status').text('');
        $.post(wpSheets.ajax_url, { action: 'wpsheets_get_object_columns', nonce: wpSheets.nonce, object_id: obj_id, sheet: sheet }, function(res) {
            $('#ws-fields-loading').hide(); if(!res.success) { alert(res.data); return; }
            availableTaxonomies = res.data.taxonomies || []; availablePostTypes = res.data.post_types || [];
            $('#ws-fields-object-id').val(obj_id); $('#ws-fields-object-type').val(obj_type);
            var cols = res.data.columns; var mapping = res.data.mapping || {}; var $tbody = $('#ws-fields-body'); $tbody.empty();
            var activeTypeGroups = (obj_type === 'tax') ? taxTypeGroups : cptTypeGroups;
            cols.forEach(function(col) {
                var safeCol = col.replace(/[^a-zA-Z0-9_]/g, '_').toLowerCase(); if(!safeCol) return; 
                var currentData = mapping[safeCol] || { type: 'text', required: 0, options: {} };
                var html = '<tr><td><strong style="font-size:15px;">' + col + '</strong><br><small style="color:var(--ws-text-light);">key: ' + safeCol + '</small></td><td><select name="fields['+safeCol+'][type]" class="ws-select ws-type-selector" data-col="'+safeCol+'" style="margin-bottom:10px; max-width: 400px;">';
                $.each(activeTypeGroups, function(groupName, options) { html += '<optgroup label="'+groupName+'">'; $.each(options, function(k, v) { var sel = (currentData.type === k) ? 'selected' : ''; html += '<option value="'+k+'" '+sel+'>'+v+'</option>'; }); html += '</optgroup>'; });
                html += '</select><div class="ws-opts-container" id="ws-opts-'+safeCol+'"></div><textarea class="ws-hidden-opts" style="display:none;">' + JSON.stringify(currentData.options) + '</textarea></td></tr>';
                $tbody.append($(html));
            });
            $('.ws-type-selector').on('change', function() { var newType = $(this).val(); var colKey = $(this).data('col'); var $tr = $(this).closest('tr'); var $optsContainer = $tr.find('.ws-opts-container'); var savedOpts = JSON.parse($tr.find('.ws-hidden-opts').val() || '{}'); $optsContainer.html(renderIntelligentOptions(newType, colKey, savedOpts)); }).trigger('change');
            $('#ws-fields-form').show();
        });
    });

    $('#ws-fields-form').on('submit', function(e) {
        e.preventDefault(); var $btn = $(this).find('button[type="submit"]'); $btn.prop('disabled', true).text('Guardando...'); $('#ws-fields-save-status').text('');
        $.post(wpSheets.ajax_url, $(this).serialize() + '&action=wpsheets_save_field_mapping&nonce=' + wpSheets.nonce, function(res) {
            $btn.prop('disabled', false).text('Guardar Configuración Completa');
            if(res.success) { $('#ws-fields-save-status').css('color', 'var(--ws-success)').text('✅ ' + res.data); setTimeout(function() { $('#ws-fields-save-status').fadeOut(function(){ $(this).text('').show(); }); }, 3000); } 
            else { $('#ws-fields-save-status').css('color', 'var(--ws-danger)').text('❌ Error al guardar.'); }
        });
    });

    var syncObjId = '', syncObjType = '', syncSheet = '', syncTotal = 0, syncOffset = 0, syncBatchSize = 5; 
    var syncMapping = {}, syncHeaders = []; var isSyncing = false;
    $('#ws-sync-object').on('change', function() { if($(this).val()) { $('#ws-sync-start-btn').prop('disabled', false); } else { $('#ws-sync-start-btn').prop('disabled', true); } });
    function logSync(msg) { var time = new Date().toLocaleTimeString(); $('#ws-sync-log').append('<div class="ws-log-line"><span style="color:#64748B;">['+time+']</span> ' + msg + '</div>'); $('#ws-sync-log').scrollTop($('#ws-sync-log')[0].scrollHeight); }
    $('#ws-sync-start-btn').on('click', function(e) {
        e.preventDefault(); if(!confirm('¿Estás seguro de iniciar la sincronización?')) return;
        syncObjId = $('#ws-sync-object').val(); syncObjType = $('#ws-sync-object').find(':selected').data('type'); syncSheet = $('#ws-sync-object').find(':selected').data('sheet');
        $('#ws-sync-start-btn').hide(); $('#ws-sync-stop-btn').show(); $('#ws-sync-object').prop('disabled', true); $('#ws-sync-progress-bg, #ws-sync-log, #ws-sync-status-text').show(); $('#ws-sync-progress-bar').css('width', '0%'); $('#ws-sync-log').empty(); logSync('<span class="ws-log-info">INICIALIZANDO MOTOR...</span>');
        isSyncing = true; syncOffset = 0;
        $.post(wpSheets.ajax_url, { action: 'wpsheets_sync_prepare', nonce: wpSheets.nonce, object_id: syncObjId, sheet: syncSheet }, function(res) {
            if(!res.success) { logSync('<span class="ws-log-error">Error Crítico: ' + res.data + '</span>'); stopSyncUI(); return; }
            syncTotal = res.data.total_rows; syncHeaders = res.data.headers; syncMapping = res.data.mapping; logSync('<span style="color:#fff;">✓ Preparación completada. Registros: ' + syncTotal + '</span>'); processNextBatch();
        });
    });
    $('#ws-sync-stop-btn').on('click', function(e) { e.preventDefault(); isSyncing = false; logSync('<span class="ws-log-warn">⚠️ DETENIDO.</span>'); stopSyncUI(); });
    function processNextBatch() {
        if(!isSyncing) return;
        if(syncOffset >= syncTotal) { logSync('<br><span style="color:#10B981; font-weight:bold;">🚀 ¡COMPLETADO!</span>'); $('#ws-sync-progress-bar').css('width', '100%'); $('#ws-sync-status-text').text('100% Completado'); stopSyncUI(); return; }
        var currentBatch = Math.min(syncBatchSize, syncTotal - syncOffset); logSync('<br><span class="ws-log-info">>> Lote: ' + (syncOffset + 1) + ' a ' + (syncOffset + currentBatch) + '...</span>');
        $.post(wpSheets.ajax_url, { action: 'wpsheets_sync_batch', nonce: wpSheets.nonce, object_id: syncObjId, object_type: syncObjType, sheet: syncSheet, offset: syncOffset, batch_size: currentBatch, headers: syncHeaders, mapping: syncMapping }, function(res) {
            if(!res.success) { logSync('<span class="ws-log-error">Error en lote: ' + res.data + '</span>'); stopSyncUI(); return; }
            res.data.logs.forEach(function(l) { logSync('&nbsp;&nbsp;&nbsp;↳ ' + l); }); syncOffset += currentBatch;
            var pct = Math.round((syncOffset / syncTotal) * 100); $('#ws-sync-progress-bar').css('width', pct + '%'); $('#ws-sync-status-text').text('Sincronizando: ' + pct + '%'); setTimeout(processNextBatch, 800); 
        });
    }
    function stopSyncUI() { $('#ws-sync-start-btn').show().text('Reiniciar / Continuar'); $('#ws-sync-stop-btn').hide(); $('#ws-sync-object').prop('disabled', false); }
});
