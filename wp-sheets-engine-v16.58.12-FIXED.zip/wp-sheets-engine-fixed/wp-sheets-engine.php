<?php
/**
 * Plugin Name: WP Sheets Engine (Fase 6A - Data Grid Bidireccional (Two-Way Sync))
 * Description: Corrección del Motor de Sincronización (AJAX Trigger arreglado) e inclusión de procesadores avanzados (Taxonomías y Relaciones).
 * Version: 16.58.1
 * Author: AI Assistant
 */

if (!defined('ABSPATH')) exit;

define('WPSHEETS_DIR', plugin_dir_path(__FILE__));
define('WPSHEETS_URL', plugin_dir_url(__FILE__));

require_once WPSHEETS_DIR . 'includes/class-google-api.php';
require_once WPSHEETS_DIR . 'includes/registry.php';
require_once WPSHEETS_DIR . 'includes/admin-ui.php';
require_once WPSHEETS_DIR . 'includes/admin-cpts.php';
require_once WPSHEETS_DIR . 'includes/admin-taxonomies.php';
require_once WPSHEETS_DIR . 'includes/admin-datagrid.php';
require_once WPSHEETS_DIR . 'includes/admin-fields.php';
require_once WPSHEETS_DIR . 'includes/admin-sync.php';
require_once WPSHEETS_DIR . 'includes/admin-autosync.php';
require_once WPSHEETS_DIR . 'includes/api-webhook.php';
require_once WPSHEETS_DIR . 'includes/api-outbound.php';
require_once WPSHEETS_DIR . 'includes/admin-woo.php';

// Agregar intervalos de tiempo personalizados para el Auto-Sync
add_filter('cron_schedules', 'wpsheets_custom_cron_schedules');
function wpsheets_custom_cron_schedules($schedules) {
    $schedules['every_minute'] = array(
        'interval' => 60,
        'display'  => 'Cada Minuto (Pruebas)'
    );
    $schedules['every_five_minutes'] = array(
        'interval' => 300,
        'display'  => 'Cada 5 Minutos'
    );
    return $schedules;
}

require_once WPSHEETS_DIR . 'includes/frontend-metaboxes.php';
require_once WPSHEETS_DIR . 'includes/frontend-shortcodes.php';
require_once WPSHEETS_DIR . 'includes/class-divi-module.php';

add_action('admin_enqueue_scripts', function($hook) {
    if (strpos($hook, 'wpsheets') !== false) {
        wp_enqueue_media();
        wp_enqueue_script('wpsheets-admin-js', WPSHEETS_URL . 'assets/admin.js', ['jquery'], '16.58.1', true);
        wp_enqueue_style('wpsheets-admin-css', WPSHEETS_URL . 'assets/admin.css', [], '16.58.1');
        wp_enqueue_style('google-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap', [], null);
        wp_localize_script('wpsheets-admin-js', 'wpSheets', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('wpsheets_ajax_nonce')
        ]);
    }
});

add_action('in_admin_header', function() {
    if (isset($_GET['page']) && strpos($_GET['page'], 'wpsheets') !== false) {
        remove_all_actions('admin_notices');
        remove_all_actions('all_admin_notices');
    }
});
