<?php
if (!defined('ABSPATH')) exit;

/**
 * Función principal para exportar un post individual a Google Sheets.
 */
function wpsheets_export_post_to_google($post_id) {
    if (wp_is_post_revision($post_id) || wp_is_post_autosave($post_id)) return;
    $post = get_post($post_id);
    if (!$post || $post->post_status === 'auto-draft') return;

    // Identificar si el post_type está mapeado
    $cpts = get_option('wpsheets_cpts', []);
    if (!is_array($cpts)) $cpts = [];
    if (class_exists('WooCommerce')) {
        $cpts[] = ['slug' => 'product', 'sheet' => 'Productos_WooCommerce'];
    }

    $tab = ''; $obj_slug = $post->post_type;
    foreach($cpts as $c) {
        if(isset($c['slug']) && $c['slug'] === $obj_slug) {
            $tab = $c['sheet'] ?? ''; break;
        }
    }
    if (empty($tab)) return;

    $mapping_all = get_option('wpsheets_fields_mapping', []);
    $mapping = $mapping_all[$obj_slug] ?? [];
    if (empty($mapping)) return;

    $sid = get_option('wpsheets_spreadsheet_id');
    if (empty($sid)) return;

    // Obtener o crear ID de importación
    $item_id = get_post_meta($post_id, '_ws_import_id', true);
    if (empty($item_id)) {
        $item_id = strtoupper($obj_slug) . '-' . $post_id . '-' . rand(100,999);
        update_post_meta($post_id, '_ws_import_id', $item_id);
    }

    // 1. Obtener los encabezados de la hoja (A1:Z1)
    $headers_raw = WPSheets_Google_API::get_sheet_data($sid, $tab . '!1:1');
    if (is_wp_error($headers_raw) || empty($headers_raw[0])) return;
    $headers = $headers_raw[0];

    // 2. Mapear los datos de WP a la estructura de Google Sheets
    $row_values = array_fill(0, count($headers), '');

    // Helper object logic for WooCommerce
    $product = null;
    if ($obj_slug === 'product' && function_exists('wc_get_product')) {
        $product = wc_get_product($post_id);
    }

    
    // Construir los valores a insertar
    $mapped_data = [];
    foreach($mapping as $safeCol => $config) {
        $type = $config['type'];
        $opts = $config['options'] ?? [];
        $val = '';

        if ($type === 'id') { $val = $item_id; }
        elseif ($type === 'wp_title') { $val = $post->post_title; }
        elseif ($type === 'wp_content') { $val = $post->post_content; }
        elseif ($type === 'wp_excerpt') { $val = $post->post_excerpt; }
        elseif ($type === 'wp_status') { $val = $post->post_status; }
        elseif ($type === 'wp_slug') { $val = $post->post_name; }
        elseif ($type === 'taxonomy') {
            $tax_slug = $opts['tax_slug'] ?? '';
            if ($tax_slug) {
                $terms = get_the_terms($post_id, $tax_slug);
                if (!empty($terms) && !is_wp_error($terms)) {
                    $term_names = [];
                    foreach($terms as $term) {
                        $term_names[] = $term->name;
                    }
                    $val = implode(', ', $term_names);
                }
            }
        }
        elseif ($type === 'meta' || $type === 'acf') {
            $meta_key = $opts['meta_key'] ?? '';
            if ($meta_key) {
                // Woo getters si es posible
                if ($product) {
                    if ($meta_key === '_price') $val = $product->get_price();
                    elseif ($meta_key === '_regular_price') $val = $product->get_regular_price();
                    elseif ($meta_key === '_sale_price') $val = $product->get_sale_price();
                    elseif ($meta_key === '_stock') $val = $product->get_stock_quantity();
                    elseif ($meta_key === '_stock_status') $val = $product->get_stock_status();
                    elseif ($meta_key === '_sku') $val = $product->get_sku();
                    elseif ($meta_key === '_weight') $val = $product->get_weight();
                    else $val = get_post_meta($post_id, $meta_key, true);
                } else {
                    $val = get_post_meta($post_id, $meta_key, true);
                }
            }
        }
        $mapped_data[$safeCol] = $val;
    }


    // Colocar los valores en el orden de las columnas de Google
    $id_col_index = -1;
    foreach ($headers as $index => $raw_header) {
        $safeHeader = strtolower(preg_replace('/[^a-zA-Z0-9_]/', '_', $raw_header));
        if (isset($mapped_data[$safeHeader])) {
            $row_values[$index] = $mapped_data[$safeHeader];
        }
        if ($index === 0) { // Asumimos que A es el ID
            $id_col_index = 0;
            $row_values[0] = $item_id; // Forzar ID en la primera col
        }
    }

    // 3. Buscar si la fila ya existe (Solo buscar en columna A)
    $all_ids_raw = WPSheets_Google_API::get_sheet_data($sid, $tab . '!A:A');
    $row_to_update = -1;

    if (!is_wp_error($all_ids_raw) && !empty($all_ids_raw)) {
        foreach($all_ids_raw as $i => $row) {
            if (isset($row[0]) && trim($row[0]) === $item_id) {
                $row_to_update = $i + 1; // +1 porque sheets usa 1-index
                break;
            }
        }
    }

    // 4. Escribir en Google Sheets
    if ($row_to_update > 0) {
        // Actualizar fila existente
        WPSheets_Google_API::update_sheet_data($sid, $tab . '!A' . $row_to_update, [$row_values]);
    } else {
        // Añadir nueva fila
        WPSheets_Google_API::append_sheet_data($sid, $tab . '!A1', [$row_values]);
    }
}

// Enganchar al Guardar Post (Pero evitar loops infinitos)
add_action('save_post', function($post_id, $post, $update) {
    // Evitar que el webhook dispare un save_post de vuelta a Google Sheets
    if (defined('WPSHEETS_IS_WEBHOOK') && WPSHEETS_IS_WEBHOOK) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    // Evitar loop si la petición viene del cron o del grid sync
    if (isset($_POST['action']) && $_POST['action'] === 'wpsheets_sync_process') return;

    wpsheets_export_post_to_google($post_id);
}, 10, 3);

// Enganchar a ventas de WooCommerce
if (class_exists('WooCommerce')) {
    add_action('woocommerce_reduce_order_stock', function($order) {
        if (defined('WPSHEETS_IS_WEBHOOK') && WPSHEETS_IS_WEBHOOK) return;
        foreach ($order->get_items() as $item) {
            $product_id = $item->get_product_id();
            if ($product_id) wpsheets_export_post_to_google($product_id);
        }
    });
}
