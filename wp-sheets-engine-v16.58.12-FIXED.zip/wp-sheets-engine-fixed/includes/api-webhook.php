<?php
if (!defined('ABSPATH')) exit;

add_action('rest_api_init', function () {
    register_rest_route('wpsheets/v1', '/webhook', [
        'methods' => 'POST',
        'callback' => 'wpsheets_handle_webhook',
        'permission_callback' => '__return_true'
    ]);
});

function wpsheets_handle_webhook(WP_REST_Request $request) {
    if(!defined('WPSHEETS_IS_WEBHOOK')) define('WPSHEETS_IS_WEBHOOK', true);
    $params = $request->get_json_params();
    $log_msg = "[" . current_time('mysql') . "] Webhook recibido. ";

    if (empty($params['secret']) || empty($params['tab_name']) || empty($params['row_data'])) {
        update_option('wpsheets_last_webhook_error', $log_msg . "Faltan parámetros.");
        return new WP_Error('missing_data', 'Faltan parámetros requeridos', ['status' => 400]);
    }

    $stored_secret = get_option('wpsheets_webhook_secret');
    if (empty($stored_secret) || $params['secret'] !== $stored_secret) {
        update_option('wpsheets_last_webhook_error', $log_msg . "Token inválido.");
        return new WP_Error('invalid_secret', 'Token de seguridad inválido', ['status' => 401]);
    }

    
    $tab = sanitize_text_field($params['tab_name']);
    $raw_row_data = $params['row_data'];
    $id_column_raw = isset($params['id_column']) ? $params['id_column'] : '';

    // Limpiar todos los encabezados de Google Sheets a `safeCol`
    $row_data = [];
    $safe_id_column = '';

    if (is_array($raw_row_data)) {
        foreach ($raw_row_data as $raw_header => $value) {
            $safeCol = strtolower(preg_replace('/[^a-zA-Z0-9_]/', '_', $raw_header));
            if (!empty($safeCol)) {
                $row_data[$safeCol] = $value;
                if ($raw_header === $id_column_raw) {
                    $safe_id_column = $safeCol;
                }
            }
        }
    }

    // Fallback: si no mandó id_column, intentar _ws_import_id
    if (empty($safe_id_column) && isset($row_data['_ws_import_id'])) {
        $safe_id_column = '_ws_import_id';
    }

    $item_id = !empty($safe_id_column) && isset($row_data[$safe_id_column]) ? sanitize_text_field($row_data[$safe_id_column]) : '';


    if (empty($item_id)) {
        update_option('wpsheets_last_webhook_error', $log_msg . "La fila editada no tiene un '_ws_import_id'.");
        return new WP_Error('missing_id', 'La fila no tiene _ws_import_id', ['status' => 400]);
    }

    $cpts = get_option('wpsheets_cpts', []);
    $taxs = get_option('wpsheets_taxonomies', []);
    if (!is_array($cpts)) $cpts = [];
    if (!is_array($taxs)) $taxs = [];

    if (class_exists('WooCommerce')) {
        $cpts[] = ['slug' => 'product', 'sheet' => 'Productos_WooCommerce'];
        $taxs[] = ['slug' => 'product_cat', 'sheet' => 'Productos_WooCommerce'];
        $taxs[] = ['slug' => 'product_tag', 'sheet' => 'Productos_WooCommerce'];
    }

    $obj_id = ''; $obj_type = '';
    foreach($cpts as $c) { if(isset($c['sheet']) && $c['sheet'] === $tab) { $obj_id = $c['slug']; $obj_type = 'cpt'; break; } }
    if(!$obj_type) {
        foreach($taxs as $t) { if(isset($t['sheet']) && $t['sheet'] === $tab) { $obj_id = $t['slug']; $obj_type = 'tax'; break; } }
    }

    if (!$obj_type) {
        update_option('wpsheets_last_webhook_error', $log_msg . "La pestaña '{$tab}' no está en la configuración del plugin.");
        return new WP_Error('unmapped_tab', 'Pestaña no mapeada', ['status' => 400]);
    }

    $mapping_all = get_option('wpsheets_fields_mapping', []);
    $mapping = isset($mapping_all[$obj_id]) ? $mapping_all[$obj_id] : [];
    if (empty($mapping)) {
        update_option('wpsheets_last_webhook_error', $log_msg . "No hay columnas mapeadas para '{$tab}'.");
        return new WP_Error('no_mapping', 'No hay mapeo', ['status' => 400]);
    }

    if ($obj_type === 'cpt') {
        $existing_post = get_posts(['post_type' => $obj_id, 'meta_key' => '_ws_import_id', 'meta_value' => $item_id, 'posts_per_page' => 1, 'post_status' => 'any']);
        $post_title = $item_id; $post_content = ''; $post_excerpt = ''; $meta_input = [];

        foreach($mapping as $col_key => $config) {
            $val = isset($row_data[$col_key]) ? $row_data[$col_key] : '';
            if($config['type'] === 'wp_title' && !empty($val)) $post_title = $val;
            elseif($config['type'] === 'wp_content') $post_content = $val;
            elseif($config['type'] === 'wp_excerpt') $post_excerpt = $val;
            elseif($config['type'] !== 'taxonomy' && $config['type'] !== 'id') {
                $meta_input[$col_key] = $val;
            }
        }

        $post_data = ['post_title' => $post_title, 'post_content' => $post_content, 'post_excerpt' => $post_excerpt, 'post_status' => 'publish', 'post_type' => $obj_id];

        if(!empty($existing_post)) {
            $post_data['ID'] = $existing_post[0]->ID;
            wp_update_post($post_data);
            $pid = $post_data['ID'];
        } else {
            $pid = wp_insert_post($post_data);
            update_post_meta($pid, '_ws_import_id', $item_id);
        }

        foreach($meta_input as $mk => $mv) update_post_meta($pid, $mk, $mv);

        if ($obj_id === 'product' && function_exists('wc_get_product')) {
            $product = wc_get_product($pid);
            if ($product) $product->save();
        }

    } else {
        $term_name = $item_id; $term_desc = ''; $meta_input = [];
        foreach($mapping as $col_key => $config) {
            $val = isset($row_data[$col_key]) ? $row_data[$col_key] : '';
            if($config['type'] === 'tax_name' && !empty($val)) $term_name = $val;
            elseif($config['type'] === 'tax_desc') $term_desc = $val;
            elseif($config['type'] !== 'id') $meta_input[$col_key] = $val;
        }

        $existing_terms = get_terms(['taxonomy' => $obj_id, 'hide_empty' => false, 'meta_query' => [['key' => '_ws_import_id', 'value' => $item_id]]]);
        if(!empty($existing_terms) && !is_wp_error($existing_terms)) {
            $term_db_id = $existing_terms[0]->term_id;
            wp_update_term($term_db_id, $obj_id, ['name' => $term_name, 'description' => $term_desc]);
        } else {
            $inserted = wp_insert_term($term_name, $obj_id, ['description' => $term_desc]);
            if(!is_wp_error($inserted)) {
                $term_db_id = $inserted['term_id'];
                update_term_meta($term_db_id, '_ws_import_id', $item_id);
            }
        }
        if(isset($term_db_id)) {
            foreach($meta_input as $mk => $mv) update_term_meta($term_db_id, $mk, $mv);
        }
    }

    update_option('wpsheets_last_webhook_error', $log_msg . '¡Éxito! ID procesado: ' . $item_id);
    return rest_ensure_response(['success' => true, 'message' => 'Sincronización en tiempo real completada.']);
}
