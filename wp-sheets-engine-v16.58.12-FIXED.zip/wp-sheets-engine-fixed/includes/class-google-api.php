<?php
if (!defined('ABSPATH')) exit;

class WPSheets_Google_API {
    public static function get_access_token() {
        $json = get_option('wpsheets_service_account_json');
        if (empty($json)) return new WP_Error('no_credentials', 'Faltan credenciales');
        $key = json_decode($json, true);
        if (!$key || !isset($key['client_email']) || !isset($key['private_key'])) return new WP_Error('invalid_json', 'JSON inválido');

        $transient_key = 'wpsheets_google_token_' . md5($key['client_email']);
        $token = get_transient($transient_key);
        if ($token) return $token;

        $header = ['alg' => 'RS256', 'typ' => 'JWT'];
        $now = time();
        $claim = [
            'iss' => $key['client_email'],
            'scope' => 'https://www.googleapis.com/auth/spreadsheets',
            'aud' => 'https://oauth2.googleapis.com/token',
            'exp' => $now + 3600,
            'iat' => $now
        ];

        $base64_header = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode(json_encode($header)));
        $base64_claim = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode(json_encode($claim)));
        $signature_input = $base64_header . '.' . $base64_claim;

        $signature = '';
        openssl_sign($signature_input, $signature, $key['private_key'], 'SHA256');
        $base64_signature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signature));

        $jwt = $signature_input . '.' . $base64_signature;

        $response = wp_remote_post('https://oauth2.googleapis.com/token', [
            'body' => ['grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer', 'assertion' => $jwt]
        ]);

        if (is_wp_error($response)) return $response;
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if (isset($body['access_token'])) {
            set_transient($transient_key, $body['access_token'], 3500);
            return $body['access_token'];
        }
        return new WP_Error('api_error', 'Error al obtener token');
    }

    public static function get_sheet_data($spreadsheet_id, $range) {
        $token = self::get_access_token();
        if (is_wp_error($token)) return $token;
        // Se codifica el rango para evitar problemas con acentos y espacios
        $encoded_range = rawurlencode($range);
        $response = wp_remote_get("https://sheets.googleapis.com/v4/spreadsheets/{$spreadsheet_id}/values/{$encoded_range}", ['headers' => ['Authorization' => 'Bearer ' . $token]]);
        if (is_wp_error($response)) return $response;
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if (isset($body['error'])) return new WP_Error('google_error', $body['error']['message']);
        return isset($body['values']) ? $body['values'] : [];
    }

    public static function get_spreadsheet_tabs($spreadsheet_id) {
        $token = self::get_access_token();
        if (is_wp_error($token)) return [];
        $response = wp_remote_get("https://sheets.googleapis.com/v4/spreadsheets/{$spreadsheet_id}?fields=sheets.properties.title", ['headers' => ['Authorization' => 'Bearer ' . $token]]);
        if (is_wp_error($response)) return [];
        $body = json_decode(wp_remote_retrieve_body($response), true);
        $tabs = [];
        if (!empty($body['sheets'])) foreach($body['sheets'] as $sheet) $tabs[] = $sheet['properties']['title'];
        return $tabs;
    }

    public static function clear_sheet($spreadsheet_id, $range) {
        $token = self::get_access_token();
        if (is_wp_error($token)) return $token;
        $encoded_range = rawurlencode($range);
        $url = "https://sheets.googleapis.com/v4/spreadsheets/{$spreadsheet_id}/values/{$encoded_range}:clear";
        $args = [
            'headers' => ['Authorization' => 'Bearer ' . $token, 'Content-Type' => 'application/json'],
            'body' => '{}',
            'method' => 'POST'
        ];
        return wp_remote_request($url, $args);
    }

    public static function update_sheet_data($spreadsheet_id, $range, $values) {
        $token = self::get_access_token();
        if (is_wp_error($token)) return $token;
        $encoded_range = rawurlencode($range);
        $body = ['range' => $range, 'majorDimension' => 'ROWS', 'values' => $values];
        $response = wp_remote_request("https://sheets.googleapis.com/v4/spreadsheets/{$spreadsheet_id}/values/{$encoded_range}?valueInputOption=USER_ENTERED", [
            'method' => 'PUT',
            'headers' => ['Authorization' => 'Bearer ' . $token, 'Content-Type' => 'application/json'],
            'body' => json_encode($body)
        ]);
        if (is_wp_error($response)) return $response;
        $response_code = wp_remote_retrieve_response_code($response);
        if ($response_code !== 200) {
            $error_body = json_decode(wp_remote_retrieve_body($response), true);
            return new WP_Error('google_api_error', 'Error ' . $response_code . ': ' . ($error_body['error']['message'] ?? 'Desconocido'));
        }
        return true;
    }

    public static function append_row($spreadsheet_id, $range, $values) {
        $token = self::get_access_token();
        if (is_wp_error($token)) return $token;
        $encoded_range = rawurlencode($range);
        $url = "https://sheets.googleapis.com/v4/spreadsheets/{$spreadsheet_id}/values/{$encoded_range}:append?valueInputOption=USER_ENTERED";
        $body = json_encode(['values' => [$values]]);
        $response = wp_remote_post($url, ['headers' => ['Authorization' => 'Bearer ' . $token, 'Content-Type' => 'application/json'], 'body' => $body]);
        if (is_wp_error($response)) return $response;
        return true;
    }

    public static function add_sheet_with_headers($spreadsheet_id, $sheet_title, $headers) {
        $token = self::get_access_token();
        if (is_wp_error($token)) return $token;
        $url = "https://sheets.googleapis.com/v4/spreadsheets/{$spreadsheet_id}:batchUpdate";
        $request_body = ['requests' => [['addSheet' => ['properties' => ['title' => $sheet_title]]]]];
        $args = [
            'headers' => ['Authorization' => 'Bearer ' . $token, 'Content-Type' => 'application/json'],
            'body' => json_encode($request_body),
            'method' => 'POST'
        ];
        wp_remote_request($url, $args);
        // We write the headers
        $res = self::update_sheet_data($spreadsheet_id, "'" . $sheet_title . "'!A1", [$headers]);
        return $res;
    }

    public static function delete_dimension($spreadsheet_id, $sheet_id, $dimension, $start_index) {
        $token = self::get_access_token();
        if (is_wp_error($token)) return $token;
        $url = "https://sheets.googleapis.com/v4/spreadsheets/{$spreadsheet_id}:batchUpdate";
        $request = [
            'deleteDimension' => [
                'range' => ['sheetId' => intval($sheet_id), 'dimension' => $dimension, 'startIndex' => intval($start_index), 'endIndex' => intval($start_index) + 1]
            ]
        ];
        $args = ['headers' => ['Authorization' => 'Bearer ' . $token, 'Content-Type' => 'application/json'], 'body' => json_encode(['requests' => [$request]]), 'method' => 'POST'];
        return wp_remote_request($url, $args);
    }
}
