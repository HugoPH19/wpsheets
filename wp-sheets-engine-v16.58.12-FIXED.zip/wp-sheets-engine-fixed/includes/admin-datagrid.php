<?php
if (!defined('ABSPATH')) exit;
function wpsheets_page_datagrid() {
    $sid = get_option('wpsheets_spreadsheet_id');
    $tabs = $sid ? WPSheets_Google_API::get_spreadsheet_tabs($sid) : [];
    ?>
    <div class="wpsheets-wrap" style="max-width: 100%;">
        <div class="wpsheets-header">
            <div class="wpsheets-header-title">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#2563EB" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><line x1="3" y1="9" x2="21" y2="9"></line><line x1="9" y1="21" x2="9" y2="9"></line></svg>
                <div>
                    <h1>Data Grid (Edición Bidireccional)</h1>
                    <div class="wpsheets-subtitle">Doble clic en cualquier celda para editar. Los cambios se guardarán automáticamente en Google Sheets.</div>
                </div>
            </div>
        </div>

        <?php if(empty($tabs) || is_wp_error($tabs)): ?>
            <div class="ws-alert ws-alert-error">⚠️ API no conectada. Ve a "Conexión API" primero.</div>
        <?php else: ?>
            <div class="ws-datagrid-toolbar">
                <div style="flex:1; max-width: 300px;">
                    <select id="ws-grid-tab-select" class="ws-select" style="max-width: 400px;">
<?php echo wpsheets_get_grouped_options_html(); ?>
</select>
                </div>
                <button id="ws-grid-add-row-btn" class="ws-btn" style="margin-right:10px; background:#10B981; color:#fff;">+ Agregar Fila</button>
                <button id="ws-grid-add-col-btn" class="ws-btn" style="margin-right:10px; background:#3B82F6; color:#fff;">+ Agregar Columna</button>
                <button id="ws-grid-load-btn"  class="ws-btn ws-btn-primary">Cargar / Refrescar Datos</button>

                <div style="margin-left: 20px; display:none; align-items:center; gap: 10px;" id="ws-grid-per-page-container">
                    <label class="ws-label" style="margin:0;">Ver:</label>
                    <select id="ws-grid-per-page" class="ws-select" style="width: 80px; padding: 6px 10px;">
                        <option value="25">25</option>
                        <option value="50" selected>50</option>
                        <option value="100">100</option>
                        <option value="all">Todos</option>
                    </select>
                </div>

                <div style="flex:1; margin-left:20px; display:none;" id="ws-grid-search-container">
                    <input type="text" id="ws-grid-search" class="ws-input" placeholder="🔍 Buscar en todas las columnas...">
                </div>
            </div>

            
            <!-- BARRA DE FÓRMULAS fx -->
            <div id="ws-grid-formula-bar" style="display:none;flex-direction:column;background:#fff;border:1px solid #CBD5E1;border-radius:6px;margin-bottom:15px;box-shadow:0 1px 3px rgba(0,0,0,.05);">
                <div style="display:flex;align-items:center;padding:8px 15px;border-bottom:1px solid #f1f5f9;gap:12px;">
                    <span style="font-family:monospace;font-size:20px;font-weight:700;color:#94A3B8;user-select:none;">fx</span>
                    <button id="ws-grid-media-btn" type="button" class="ws-btn" style="padding:4px 10px; font-size:12px; background:#8B5CF6; color:white; border:none; border-radius:4px; cursor:pointer; margin-right:10px; display:none;" title="Subir o Seleccionar Imágenes">📷 Medios</button>
                    <span id="ws-grid-cell-ref" style="background:#F1F5F9;color:#475569;padding:4px 10px;border-radius:4px;font-size:12px;font-weight:700;min-width:44px;text-align:center;">—</span>
                    <input type="text" id="ws-grid-formula-input" style="flex:1;border:none;outline:none;font-size:15px;background:transparent;color:#1e293b;" placeholder="Selecciona una celda para ver o editar su contenido..." disabled>
                    <button id="ws-grid-formula-save" class="ws-btn ws-btn-primary" style="display:none;padding:4px 14px;font-size:12px;">✔ Guardar (Enter)</button>
                </div>
                <div id="ws-formula-helper" style="display:none;padding:8px 15px;background:#F8FAFC;font-size:12px;color:#475569;border-radius:0 0 6px 6px;">
                    <strong id="ws-helper-title" style="color:#2563EB;display:block;margin-bottom:3px;"></strong>
                    <span id="ws-helper-desc"></span><br>
                    <code id="ws-helper-syntax" style="background:#E2E8F0;padding:2px 6px;border-radius:3px;font-family:monospace;margin-top:4px;display:inline-block;"></code>
                    <div style="margin-top:8px;padding-top:8px;border-top:1px dashed #CBD5E1;">
                        <strong>Tus hojas (clic para insertar):</strong>
                        <?php foreach($tabs as $t): ?>
                        <span class="ws-helper-tab-btn" data-tab="<?php echo esc_attr($t); ?>" style="cursor:pointer;color:#2563EB;text-decoration:underline;margin-right:8px;">'<?php echo esc_html($t); ?>'!</span>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <div id="ws-grid-save-alert" class="ws-alert ws-alert-success" style="display:none; padding: 10px; margin-bottom: 15px;">
                Guardando cambios en Google Sheets...
            </div>

            <div class="ws-card" style="padding: 0; display:none;" id="ws-grid-table-container">
                <div class="ws-table-wrapper ws-datagrid-container">
                    <table class="ws-table ws-datagrid-table ws-editable-table" id="ws-grid-table">
                        <thead><tr id="ws-grid-headers"></tr></thead>
                        <tbody id="ws-grid-body"></tbody>
                    </table>
                </div>
                <div class="ws-pagination" id="ws-grid-pagination">
                    <button class="ws-btn ws-btn-secondary" id="ws-grid-prev">Anterior</button>
                    <span style="font-size:14px; color:var(--ws-text-light);">Página <strong id="ws-grid-page-current">1</strong> de <strong id="ws-grid-page-total">1</strong> (<span id="ws-grid-total-rows">0</span> registros)</span>
                    <button class="ws-btn ws-btn-secondary" id="ws-grid-next">Siguiente</button>
                </div>
            </div>

            <!-- Estilos inline temporales para la edición -->
            <style>
                .ws-editable-table td { position: relative; cursor: cell; transition: background 0.2s; }
                .ws-editable-table td:hover { background: #F8FAFC; }
                .ws-selected-cell { background:#EFF6FF !important; outline:2px solid #2563EB; outline-offset:-2px; z-index:10; }
                .ws-editing-cell { padding: 0 !important; }
                .ws-edit-input { width: 100%; height: 100%; border: 2px solid var(--ws-accent); padding: 14px; box-sizing: border-box; outline: none; font-family: inherit; font-size: inherit; background: #fff; }
                .ws-saving-cell { background: #FEF3C7 !important; color: #92400E; }
                .ws-success-cell { background: #D1FAE5 !important; transition: background 1s; }
            </style>
        <?php endif; ?>
    </div>
    <?php
}

// Endpoint AJAX ya existente para cargar
add_action('wp_ajax_wpsheets_load_grid', function() { 
    check_ajax_referer('wpsheets_ajax_nonce', 'nonce'); 
    $tab = sanitize_text_field($_POST['tab']); 
    $sid = get_option('wpsheets_spreadsheet_id'); 
    $data = WPSheets_Google_API::get_sheet_data($sid, "'" . $tab . "'!A1:ZZ"); 
    if (is_wp_error($data)) wp_send_json_error('Error al leer de Google Sheets.'); 
    if (empty($data)) wp_send_json_success(['headers' => [], 'rows' => []]); 
    $headers = array_shift($data); 
    wp_send_json_success(['headers' => $headers, 'rows' => $data]); 
});

// NUEVO: Endpoint AJAX para guardar una celda editada
add_action('wp_ajax_wpsheets_update_cell', function() {
    check_ajax_referer('wpsheets_ajax_nonce', 'nonce');
    $tab = sanitize_text_field($_POST['tab']);
    $row_index = intval($_POST['row_index']) + 2; // +2 porque índice 0 es fila 2 en Google (fila 1 es header)
    $col_index = intval($_POST['col_index']); // Índice 0 = Columna A
    $new_value = sanitize_text_field($_POST['value']);
    $sid = get_option('wpsheets_spreadsheet_id');

    // Convertir índice numérico a Letra de Columna (0->A, 1->B, 26->AA)
    $col_letter = '';
    $temp_col = $col_index;
    while ($temp_col >= 0) {
        $col_letter = chr($temp_col % 26 + 65) . $col_letter;
        $temp_col = intval($temp_col / 26) - 1;
    }

    $range = "'" . $tab . "'!" . $col_letter . $row_index;

    // Llamar a la API de escritura
    $result = WPSheets_Google_API::update_sheet_data($sid, $range, [[$new_value]]);

    if (is_wp_error($result)) {
        wp_send_json_error($result->get_error_message());
    }

    // Leer la celda de nuevo para obtener el valor calculado si fue una fórmula
    $read_back = WPSheets_Google_API::get_sheet_data($sid, $range);
    $calculated = (is_array($read_back) && isset($read_back[0][0])) ? $read_back[0][0] : $new_value;

    wp_send_json_success([
        'message' => 'Celda actualizada correctamente.',
        'calculated' => $calculated,
        'original' => $new_value
    ]);
});


add_action('wp_ajax_wpsheets_append_row', function() {
    check_ajax_referer('wpsheets_ajax_nonce', 'nonce');
    $tab = sanitize_text_field($_POST['tab']);
    $values = isset($_POST['values']) ? array_map('sanitize_text_field', $_POST['values']) : [];
    $sid = get_option('wpsheets_spreadsheet_id');

    $result = WPSheets_Google_API::append_row($sid, "'" . $tab . "'!A:A", $values);
    if (is_wp_error($result)) wp_send_json_error($result->get_error_message());
    wp_send_json_success('Fila agregada correctamente.');
});


add_action('wp_ajax_wpsheets_add_col', function() {
    check_ajax_referer('wpsheets_ajax_nonce', 'nonce');
    $tab = sanitize_text_field($_POST['tab']);
    $col_index = intval($_POST['col_index']);
    $col_name = sanitize_text_field($_POST['col_name']);
    $sid = get_option('wpsheets_spreadsheet_id');

    // Calculate column letter
    $col_letter = '';
    $temp_col = $col_index;
    while ($temp_col >= 0) {
        $col_letter = chr($temp_col % 26 + 65) . $col_letter;
        $temp_col = intval($temp_col / 26) - 1;
    }

    $range = "'" . $tab . "'!" . $col_letter . "1"; // Escribir en la primera fila, siguiente columna
    $result = WPSheets_Google_API::update_sheet_data($sid, $range, [[$col_name]]);

    if (is_wp_error($result)) { wp_send_json_error($result->get_error_message()); }
    wp_send_json_success('Columna agregada');
});


add_action('wp_ajax_wpsheets_delete_dim', function() {
    check_ajax_referer('wpsheets_ajax_nonce', 'nonce');
    $tab = sanitize_text_field($_POST['tab']);
    $dim = sanitize_text_field($_POST['dim']); // 'ROWS' or 'COLUMNS'
    $index = intval($_POST['index']); // 0-based for columns, +1 for rows since header is 0 here
    $sid = get_option('wpsheets_spreadsheet_id');

    // Mapear nombre de hoja a sheetId
    $tabs = WPSheets_Google_API::get_spreadsheet_tabs($sid);
    // API v4 doesn't easily expose sheetId in our current method without a full get.
    // So we fetch the full spreadsheet metadata
    $token = WPSheets_Google_API::get_access_token();
    $meta_response = wp_remote_get("https://sheets.googleapis.com/v4/spreadsheets/{$sid}?fields=sheets.properties", [
        'headers' => ['Authorization' => 'Bearer ' . $token]
    ]);
    if (is_wp_error($meta_response)) wp_send_json_error("Error API Meta");

    $meta = json_decode(wp_remote_retrieve_body($meta_response), true);
    $real_sheet_id = -1;
    if(isset($meta['sheets'])) {
        foreach($meta['sheets'] as $s) {
            if($s['properties']['title'] === $tab) {
                $real_sheet_id = $s['properties']['sheetId'];
                break;
            }
        }
    }

    if ($real_sheet_id === -1) wp_send_json_error('Hoja no encontrada en Google Sheets.');

    $start_index = $dim === 'ROWS' ? ($index + 1) : $index; // Fila 2 en Google = Index 1 en API

    $result = WPSheets_Google_API::delete_dimension($sid, $real_sheet_id, $dim, $start_index);
    if (is_wp_error($result)) { wp_send_json_error($result->get_error_message()); }
    wp_send_json_success('Borrado correctamente');
});


add_action('admin_footer', function() {
    if (isset($_GET['page']) && $_GET['page'] === 'wpsheets-datagrid') {
        ?>
        <script>
        jQuery(document).ready(function($) {
            // Hover and Delete Styles
            $('<style>')
                .prop('type', 'text/css')
                .html(`
                    #ws-grid-table th { position: relative; }
                    #ws-grid-table td.ws-row-header { position: relative; width: 40px; text-align: center; background: #f8fafc; font-weight: bold; border-right: 1px solid #e2e8f0; color: #64748b; }
                    .ws-del-btn { position: absolute; right: 2px; top: 50%; transform: translateY(-50%); background: #ef4444; color: white; border: none; border-radius: 50%; width: 18px; height: 18px; font-size: 10px; cursor: pointer; display: none; line-height: 1; text-align: center; padding: 0; box-shadow: 0 1px 2px rgba(0,0,0,0.2); }
                    .ws-del-btn:hover { background: #dc2626; }
                    #ws-grid-table th:hover .ws-del-btn { display: block; }
                    #ws-grid-table tr:hover .ws-del-row-btn { display: block; }
                `)
                .appendTo('head');

            // Overriding the grid load success completely from here using AJAX global complete
            
            // Action Buttons
            $('#ws-grid-add-row-btn').off('click').on('click', function(e) {
                e.preventDefault();
                var tab = $('#ws-grid-tab-select').val();
                if(!tab) { alert('Selecciona una hoja primero.'); return; }
                var headers = $('#ws-grid-table th');
                if(headers.length <= 1) { alert('Carga los datos de la hoja primero.'); return; }

                var newRowData = [];
                for(var i=0; i<headers.length - 1; i++) {
                    newRowData.push(i === 0 ? 'NUEVO_ID_' + Math.floor(Math.random()*10000) : '');
                }

                var btn = $(this);
                btn.text('Guardando...').prop('disabled', true);

                $.post(wpSheets.ajax_url, {
                    action: 'wpsheets_append_row',
                    nonce: wpSheets.nonce,
                    tab: tab,
                    values: newRowData
                }, function(res) {
                    btn.text('+ Agregar Fila').prop('disabled', false);
                    if(res.success) $('#ws-grid-load-btn').click(); 
                    else alert(res.data);
                }).fail(function() {
                    btn.text('+ Agregar Fila').prop('disabled', false);
                    alert("Error AJAX");
                });
            });

            $('#ws-grid-add-col-btn').off('click').on('click', function(e) {
                e.preventDefault();
                var tab = $('#ws-grid-tab-select').val();
                if(!tab) { alert('Selecciona una hoja primero.'); return; }
                var numCols = $('#ws-grid-table th').length;
                if(numCols <= 1) { alert('Carga los datos primero.'); return; }

                var colName = prompt('Nombre de la nueva columna (sin espacios ni acentos, ej: calorias):');
                if(!colName) return;

                var btn = $(this);
                btn.text('Agregando...').prop('disabled', true);

                $.post(wpSheets.ajax_url, {
                    action: 'wpsheets_add_col',
                    nonce: wpSheets.nonce,
                    tab: tab,
                    col_index: numCols - 1, // minus 1 because we added a row-number header
                    col_name: colName
                }, function(res) {
                    btn.text('+ Agregar Columna').prop('disabled', false);
                    if(res.success) $('#ws-grid-load-btn').click();
                    else alert(res.data);
                }).fail(function() {
                    btn.text('+ Agregar Columna').prop('disabled', false);
                    alert("Error AJAX");
                });
            });

            $(document).on('click', '.ws-del-col-btn', function(e) {
                e.stopPropagation();
                if(!confirm('¿Seguro que quieres borrar TODA esta columna en Google Sheets? Esto no se puede deshacer.')) return;
                var col = $(this).data('col');
                var tab = $('#ws-grid-tab-select').val();
                $(this).text('...').prop('disabled', true);

                $.post(wpSheets.ajax_url, { action: 'wpsheets_delete_dim', nonce: wpSheets.nonce, tab: tab, dim: 'COLUMNS', index: col }, function(res) {
                    if(res.success) $('#ws-grid-load-btn').click();
                    else { alert(res.data); $('.ws-del-col-btn').text('×').prop('disabled', false); }
                }).fail(function() { alert('Error del servidor al intentar borrar la columna.'); $('.ws-del-col-btn').text('×').prop('disabled', false); });
            });

            $(document).on('click', '.ws-del-row-btn', function(e) {
                e.stopPropagation();
                if(!confirm('¿Seguro que quieres borrar esta Fila completa?')) return;
                var row = $(this).data('row');
                var tab = $('#ws-grid-tab-select').val();
                $(this).text('...').prop('disabled', true);

                $.post(wpSheets.ajax_url, { action: 'wpsheets_delete_dim', nonce: wpSheets.nonce, tab: tab, dim: 'ROWS', index: row }, function(res) {
                    if(res.success) $('#ws-grid-load-btn').click();
                    else { alert(res.data); $('.ws-del-row-btn').text('×').prop('disabled', false); }
                }).fail(function() { alert('Error del servidor al intentar borrar la fila. (Ver consola)'); $('.ws-del-row-btn').text('×').prop('disabled', false); });
            });
        
            // Control del botón de Medios
            var mediaFrame;
            $('#ws-grid-media-btn').on('click', function(e) {
                e.preventDefault();
                if (mediaFrame) { mediaFrame.open(); return; }
                mediaFrame = wp.media({
                    title: 'Seleccionar Imágenes para la Galería',
                    button: { text: 'Usar estas imágenes' },
                    multiple: 'add'
                });
                mediaFrame.on('select', function() {
                    var selection = mediaFrame.state().get('selection');
                    var urls = [];
                    selection.map(function(attachment) {
                        attachment = attachment.toJSON();
                        urls.push(attachment.url);
                    });
                    var currentVal = $('#ws-grid-formula-input').val();
                    var newVal = urls.join(', ');
                    if(currentVal && currentVal.trim() !== '') {
                        newVal = currentVal + ', ' + newVal;
                    }
                    $('#ws-grid-formula-input').val(newVal);
                    $('#ws-grid-formula-save').show().click();
                });
                mediaFrame.open();
            });

});
        </script>
        <?php
    }
});
