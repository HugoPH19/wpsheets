<?php
if (!defined('ABSPATH')) exit;

function wpsheets_get_grouped_options_html($selected_val = '') {
    $html = '<option value="">-- Elegir Opción --</option>';

    // 1. Sheets Engine (Custom CPTs & Taxonomies created via the plugin)
    $cpts = get_option('wpsheets_cpts', []);
    $taxs = get_option('wpsheets_taxonomies', []);

    if (!empty($cpts)) {
        $html .= '<optgroup label="🚀 Sheets Engine">';
        foreach ($cpts as $cpt) {
            $sel = ($selected_val === $cpt['slug']) ? 'selected' : '';
            $html .= sprintf('<option value="%s" data-type="cpt" data-sheet="%s" %s>-- %s (Post-type)</option>', esc_attr($cpt['slug']), esc_attr($cpt['sheet'] ?? ''), $sel, esc_html($cpt['plural']));

            foreach ($taxs as $tax) {
                if (isset($tax['cpt']) && $tax['cpt'] === $cpt['slug']) {
                    $t_val = 'tax_' . $tax['slug'];
                    $sel_t = ($selected_val === $t_val) ? 'selected' : '';
                    $html .= sprintf('<option value="%s" data-type="tax" data-sheet="%s" %s>&nbsp;&nbsp;&nbsp;--- %s (Taxonomía)</option>', esc_attr($t_val), esc_attr($tax['sheet'] ?? ''), $sel_t, esc_html($tax['plural']));
                }
            }
        }
        $html .= '</optgroup>';
    }

    // 2. WooCommerce
    if (class_exists('WooCommerce')) {
        $html .= '<optgroup label="🛒 WooCommerce">';

        $w_cpts = [
            'product' => ['label' => 'Products', 'sheet' => 'Products_Woo'],
            'shop_order' => ['label' => 'Orders', 'sheet' => 'Orders_Woo'],
            'shop_coupon' => ['label' => 'Coupons', 'sheet' => 'Coupons_Woo']
        ];

        foreach ($w_cpts as $slug => $data) {
            $sel = ($selected_val === $slug) ? 'selected' : '';
            $html .= sprintf('<option value="%s" data-type="cpt" data-sheet="%s" %s>-- %s (Post-type)</option>', esc_attr($slug), esc_attr($data['sheet']), $sel, esc_html($data['label']));

            if ($slug === 'product') {
                $w_tax = [
                    'product_cat' => ['label' => 'Categories', 'sheet' => 'Categories_Woo'],
                    'product_tag' => ['label' => 'Tags', 'sheet' => 'Tags_Woo']
                ];
                foreach ($w_tax as $tslug => $tdata) {
                    $t_val = 'tax_' . $tslug;
                    $sel_t = ($selected_val === $t_val) ? 'selected' : '';
                    $html .= sprintf('<option value="%s" data-type="tax" data-sheet="%s" %s>&nbsp;&nbsp;&nbsp;--- %s (Taxonomy)</option>', esc_attr($t_val), esc_attr($tdata['sheet']), $sel_t, esc_html($tdata['label']));
                }

                // Detectar Marcas (Brands)
                $all_tax = get_taxonomies([], 'objects');
                foreach ($all_tax as $t) {
                    if (strpos($t->name, 'pwb-brand') !== false || strpos($t->name, 'yith_product_brand') !== false || strpos($t->name, 'product_brand') !== false) {
                        $t_val = 'tax_' . $t->name;
                        $sel_t = ($selected_val === $t_val) ? 'selected' : '';
                        $html .= sprintf('<option value="%s" data-type="tax" data-sheet="%s" %s>&nbsp;&nbsp;&nbsp;--- Brands (Taxonomy)</option>', esc_attr($t_val), esc_attr('Brands_Woo'), $sel_t);
                        break;
                    }
                }

                // Detectar Atributos (Attributes)
                $detected_attrs = [];
                if (function_exists('wc_get_attribute_taxonomies')) {
                    $attribute_taxonomies = wc_get_attribute_taxonomies();
                    if (!empty($attribute_taxonomies)) {
                        foreach ($attribute_taxonomies as $tax) {
                            $tax_name = 'pa_' . $tax->attribute_name;
                            $t_val = 'tax_' . $tax_name;
                            $sel_t = ($selected_val === $t_val) ? 'selected' : '';
                            $sheet_name = 'Attribute_' . ucfirst($tax->attribute_name) . '_Woo';
                            $html .= sprintf('<option value="%s" data-type="tax" data-sheet="%s" %s>&nbsp;&nbsp;&nbsp;--- 🎨 Attribute: %s (Taxonomy)</option>', esc_attr($t_val), esc_attr($sheet_name), $sel_t, esc_html($tax->attribute_label));
                            $detected_attrs[$tax_name] = true;
                        }
                    }
                }

                // Fallback para atributos que quizás no estén en wc_get_attribute_taxonomies
                $all_tax = get_taxonomies([], 'objects');
                foreach ($all_tax as $t) {
                    if (strpos($t->name, 'pa_') === 0 && !isset($detected_attrs[$t->name])) {
                        $t_val = 'tax_' . $t->name;
                        $sel_t = ($selected_val === $t_val) ? 'selected' : '';
                        $attr_name = str_replace('pa_', '', $t->name);
                        $sheet_name = 'Attribute_' . ucfirst($attr_name) . '_Woo';
                        $html .= sprintf('<option value="%s" data-type="tax" data-sheet="%s" %s>&nbsp;&nbsp;&nbsp;--- 🎨 Attribute: %s (Taxonomy)</option>', esc_attr($t_val), esc_attr($sheet_name), $sel_t, esc_html($t->label));
                    }
                }
            }
        }
        $html .= '</optgroup>';
    }

    // 3. Sistema WordPress
    $html .= '<optgroup label="⚙️ Sistema WordPress">';
    $html .= sprintf('<option value="post" data-type="cpt" data-sheet="" disabled>-- Blog Entradas (Próximamente)</option>');
    $html .= sprintf('<option value="tax_category" data-type="tax" data-sheet="" disabled>&nbsp;&nbsp;&nbsp;--- Categorías Blog (Próximamente)</option>');
    $html .= sprintf('<option value="tax_post_tag" data-type="tax" data-sheet="" disabled>&nbsp;&nbsp;&nbsp;--- Etiquetas Blog (Próximamente)</option>');

    if (post_type_exists('project')) {
        $html .= sprintf('<option value="project" data-type="cpt" data-sheet="" disabled>-- Proyectos Divi (Próximamente)</option>');
        $html .= sprintf('<option value="tax_project_category" data-type="tax" data-sheet="" disabled>&nbsp;&nbsp;&nbsp;--- Categorías Proyecto (Próximamente)</option>');
    }
    $html .= '</optgroup>';

    // 4. Advanced Custom Fields / Otros
    $all_cpts = get_post_types(['public' => true, '_builtin' => false], 'objects');
    $skip_cpts = ['product', 'project', 'shop_order', 'shop_coupon'];
    if (!empty($cpts)) foreach($cpts as $c) $skip_cpts[] = $c['slug'];

    $acf_cpts = [];
    foreach ($all_cpts as $cpt) {
        if (!in_array($cpt->name, $skip_cpts)) {
            $acf_cpts[] = $cpt;
        }
    }

    if (!empty($acf_cpts)) {
        $html .= '<optgroup label="🔧 Advanced Custom Fields / Otros CPT">';
        foreach ($acf_cpts as $acpt) {
            $html .= sprintf('<option value="%s" data-type="cpt" data-sheet="" disabled>-- %s (Próximamente)</option>', esc_attr($acpt->name), esc_html($acpt->label));
            $pt_taxs = get_object_taxonomies($acpt->name, 'objects');
            foreach ($pt_taxs as $pt_tax_name) {
                $pt_tax = get_taxonomy($pt_tax_name);
                if ($pt_tax && $pt_tax->public) {
                    $html .= sprintf('<option value="tax_%s" data-type="tax" data-sheet="" disabled>&nbsp;&nbsp;&nbsp;--- %s (Próximamente)</option>', esc_attr($pt_tax->name), esc_html($pt_tax->label));
                }
            }
        }
        $html .= '</optgroup>';
    }

    return $html;
}
